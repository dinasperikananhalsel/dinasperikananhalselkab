<?php
// ============================================================================
// Endpoint foto survei — melayani foto barang dari kolom BLOB tabel survei.
// CATATAN platform: file statis yang dibuat saat runtime TIDAK dilayani oleh
// platform (selalu fallback HTML 200), sehingga foto survei disimpan di
// database SQLite dan disajikan melalui skrip ini.
// Hanya dapat diakses pengguna yang sudah login (admin/operator).
// ============================================================================
session_start();
require_once __DIR__ . '/lib/config.php';
require_once __DIR__ . '/lib/helpers.php';
require_once __DIR__ . '/lib/db.php';

if (!is_auth()) {
    http_response_code(404);
    exit('Not found');
}

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { http_response_code(404); exit('Not found'); }

$db = db();
$st = $db->prepare('SELECT s.foto FROM survei s WHERE s.id = ?');
$st->execute([$id]);
$foto = $st->fetchColumn();

if (!$foto || !is_string($foto) || $foto === '') {
    http_response_code(404);
    exit('Not found');
}

// Deteksi tipe MIME dari magic bytes
$mime = 'application/octet-stream';
$head = substr($foto, 0, 12);
if (str_starts_with($foto, "\xFF\xD8\xFF")) {
    $mime = 'image/jpeg';
} elseif (str_starts_with($foto, "\x89PNG")) {
    $mime = 'image/png';
} elseif (str_starts_with($foto, 'GIF8')) {
    $mime = 'image/gif';
} elseif (str_starts_with($head, 'RIFF') && substr($head, 8, 4) === 'WEBP') {
    $mime = 'image/webp';
}

header('Content-Type: ' . $mime);
header('Cache-Control: public, max-age=3600');
header('Content-Length: ' . strlen($foto));
echo $foto;
exit;
