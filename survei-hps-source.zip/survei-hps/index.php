<?php
// Root aplikasi — aplikasi internal, arahkan ke panel admin
header('Location: admin/');
exit;
