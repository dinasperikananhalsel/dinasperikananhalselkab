# Aplikasi Survei Harga Barang — Dinas Perikanan Halsel

Aplikasi internal untuk **mencatat hasil survei harga barang / jasa** pengadaan
Dinas Perikanan Kabupaten Halmahera Selatan, lengkap dengan ringkasan, rekap
siap cetak, dan berita acara survei. Paket dikelompokkan per **bidang**, dan
setiap bidang memiliki **operator** yang mengelola datanya sendiri.

> Catatan: fitur perhitungan HPS (Harga Perkiraan Sendiri) telah dihapus dari
> aplikasi ini — aplikasi kini murni mencatat hasil survei harga.

## Bidang & pengguna

- Paket dikelompokkan ke salah satu dari 4 bidang:
  1. Bidang Perikanan Tangkap
  2. Bidang Perikanan Budidaya
  3. Bidang Pengolahan, Pemasaran dan SDP
  4. Sekretariat
- **Administrator** (`admin`) melihat seluruh paket, mengelola semua pengguna,
  dan bisa memfilter paket per bidang.
- **Operator** hanya melihat & mengelola paket pada bidangnya sendiri (dibuatkan
  oleh admin lewat menu **Kelola Pengguna**). Saat operator menambah paket,
  bidangnya otomatis terisi sesuai bidang operator.

## Cara kerja

1. **Paket Pengadaan** — buat paket (tahun anggaran, bidang, sumber dana, PPK).
2. **Barang / Jasa** — isi daftar barang yang akan disurvei: uraian, spesifikasi,
   satuan, jumlah/volume.
3. **Data survei harga** — masukkan harga satuan dari berbagai sumber (toko,
   penyedia, situs belanja) untuk setiap barang, lengkap dengan kontak, tanggal,
   keterangan, dan **foto barang** (foto saat survei di penyedia/toko tersebut;
   format JPG/PNG/WebP/GIF maks. 2 MB, tampil sebagai thumbnail di daftar dan
   bisa diganti/dihapus).
4. **Ringkasan otomatis** — jumlah sumber, harga terendah, harga tertinggi, dan
   rata-rata harga per barang (dan rata-rata per paket).
5. **Berita Acara Survei (cetak/PDF)** — klik "Cetak Berita Acara" untuk membuka
   dokumen Berita Acara Survei Harga dalam mode cetak (format resmi: kop
   instansi, nomor & tanggal BA, tabel hasil survei, kesimpulan, tanda tangan
   tim survei dan PPK). Simpan sebagai PDF melalui menu Cetak / Simpan sebagai
   PDF pada peramban — ukuran kertas (A4) dan margin dapat diatur rapi di
   dialog cetak. Isi nomor/tanggal BA dan nama tim survei pada form Edit Paket.
6. **Cetak rekap** — halaman "Cetak Rekap" menghasilkan dokumen rekap hasil
   survei (kop instansi, info paket termasuk bidang, ringkasan per barang,
   rincian sumber survei), siap dicetak / disimpan PDF.

## Login

- URL: `/<slug>/admin/`
- Default administrator: **admin / admin123** (ganti segera setelah login pertama).
- Operator dibuat oleh admin melalui menu **Kelola Pengguna**.

## Struktur

- `admin/` — seluruh halaman (login, dashboard, paket, barang, survei, rekap cetak, berita acara cetak, kelola pengguna, ganti password)
- `lib/` — config, db (skema + seed contoh), helpers, ikon, ringkasan survei (`survei.php`)
- `assets/` — CSS (tema navy+gold), logo & favicon

Database: `data.sqlite` (SQLite via PDO). Tabel: `admin` (role, bidang),
`paket` (bidang, ba_*), `item`, `survei` (termasuk kolom `foto` BLOB untuk foto
barang per penyedia). Ada 1 paket contoh berisi 3 barang × 3
sumber survei untuk memperagakan pencatatan — bisa dihapus/diedit.
