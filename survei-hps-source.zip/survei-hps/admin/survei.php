<?php
// ============================================================
// Admin — Kelola Data Survei Harga per Barang
// ============================================================
$pageTitle = 'Data Survei Harga';
$activeAdmin = 'paket';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../lib/survei.php';

$pdo = db();

$itemId = (int)get('item_id', 0);
$st = $pdo->prepare('SELECT i.*, p.nama AS paket_nama, p.tahun, p.bidang FROM item i JOIN paket p ON p.id = i.paket_id WHERE i.id = ?');
$st->execute([$itemId]);
$item = $st->fetch();
if (!$item) {
    flash('Barang tidak ditemukan.', 'error');
    redirect('paket.php');
}
$paketId = (int)$item['paket_id'];
// Lingkup: operator hanya boleh mengelola barang bidangnya sendiri
if (!is_admin() && $item['bidang'] !== user_bidang()) {
    flash('Anda hanya dapat mengelola paket pada bidang Anda.', 'error');
    redirect('paket.php');
}

$aksi = (string)get('aksi', 'list');
$id   = (int)get('id', 0);
$formErr = '';
$old = null;

// ---------- Hapus survei ----------
if ($aksi === 'hapus') {
    csrf_check_q();
    $st = $pdo->prepare('SELECT sumber FROM survei WHERE id = ? AND item_id = ?');
    $st->execute([$id, $itemId]);
    $sumber = $st->fetchColumn();
    if ($sumber) {
        $pdo->prepare('DELETE FROM survei WHERE id = ? AND item_id = ?')->execute([$id, $itemId]);
        flash('Data survei "' . potong($sumber, 40) . '" telah dihapus.');
    } else {
        flash('Data survei tidak ditemukan.', 'error');
    }
    redirect('survei.php?item_id=' . $itemId);
}

// ---------- Simpan survei ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $sumber  = trim((string)post('sumber'));
    $telepon = trim((string)post('telepon'));
    $tanggal = trim((string)post('tanggal'));
    $harga   = angka_post('harga');
    $ket     = trim((string)post('keterangan'));
    $id      = (int)post('id', 0);

    $err = [];
    if ($sumber === '') $err[] = 'Sumber survei (toko/penyedia/website) wajib diisi.';
    if ($harga === null || $harga <= 0) $err[] = 'Harga satuan harus lebih dari 0.';
    if ($tanggal !== '' && strtotime($tanggal) === false) $err[] = 'Tanggal survei tidak valid.';

    // Foto barang dari penyedia/toko (opsional, disimpan sebagai BLOB).
    $fotoErr = '';
    $fotoBaru = baca_foto_upload($_FILES['foto'] ?? [], $fotoErr);
    if ($fotoErr !== '') $err[] = $fotoErr;

    // Foto lama (saat edit) agar tidak hilang bila tanpa unggahan baru.
    $fotoLama = '';
    if ($id > 0) {
        $st = $pdo->prepare('SELECT foto FROM survei WHERE id = ? AND item_id = ?');
        $st->execute([$id, $itemId]);
        $fotoLama = (string)$st->fetchColumn();
    }
    $fotoAkhir = $fotoBaru !== '' ? $fotoBaru : ($fotoLama !== '' && !isset($_POST['hapus_foto']) ? $fotoLama : '');

    if ($err) {
        $formErr = implode(' ', $err);
        $old = ['id' => $id, 'sumber' => $sumber, 'telepon' => $telepon,
                'tanggal' => $tanggal, 'harga' => $harga, 'keterangan' => $ket,
                'foto_ada' => $fotoLama !== ''];
    } else {
        if ($tanggal === '') $tanggal = date('Y-m-d');
        if ($id > 0) {
            $st = $pdo->prepare('UPDATE survei SET sumber = ?, telepon = ?, tanggal = ?, harga = ?, keterangan = ?, foto = ? WHERE id = ? AND item_id = ?');
            $st->bindValue(1, $sumber);
            $st->bindValue(2, $telepon);
            $st->bindValue(3, $tanggal);
            $st->bindValue(4, $harga);
            $st->bindValue(5, $ket);
            $st->bindValue(6, $fotoAkhir, $fotoAkhir === '' ? PDO::PARAM_STR : PDO::PARAM_LOB);
            $st->bindValue(7, $id, PDO::PARAM_INT);
            $st->bindValue(8, $itemId, PDO::PARAM_INT);
            $st->execute();
            flash('Data survei "' . potong($sumber, 40) . '" berhasil diperbarui.');
        } else {
            $st = $pdo->prepare('INSERT INTO survei (item_id, sumber, telepon, tanggal, harga, keterangan, foto) VALUES (?, ?, ?, ?, ?, ?, ?)');
            $st->bindValue(1, $itemId, PDO::PARAM_INT);
            $st->bindValue(2, $sumber);
            $st->bindValue(3, $telepon);
            $st->bindValue(4, $tanggal);
            $st->bindValue(5, $harga);
            $st->bindValue(6, $ket);
            $st->bindValue(7, $fotoAkhir, $fotoAkhir === '' ? PDO::PARAM_STR : PDO::PARAM_LOB);
            $st->execute();
            flash('Data survei "' . potong($sumber, 40) . '" ditambahkan.');
        }
        redirect('survei.php?item_id=' . $itemId);
    }
}

// ---------- Siapkan data form ----------
$editSurvei = null;
if (isset($old)) {
    $editSurvei = $old;
} elseif ($aksi === 'edit' && $id > 0) {
    $st = $pdo->prepare('SELECT * FROM survei WHERE id = ? AND item_id = ?');
    $st->execute([$id, $itemId]);
    $editSurvei = $st->fetch();
    if (!$editSurvei) redirect('survei.php?item_id=' . $itemId);
}

// ---------- Data ----------
$stats = survei_stats($pdo, $itemId);

$st = $pdo->prepare('SELECT * FROM survei WHERE item_id = ? ORDER BY id DESC');
$st->execute([$itemId]);
$rows = $st->fetchAll();
?>

<div class="admin-card paket-head">
  <div class="paket-head-top">
    <div>
      <span class="badge badge-tahun">TA <?= (int)$item['tahun'] ?></span>
      <span class="badge badge-bidang"><?= e($item['bidang'] ?: '—') ?></span>
      <h3 style="margin:8px 0 4px;"><?= e($item['uraian']) ?></h3>
      <p class="muted small">
        Satuan: <strong><?= e($item['satuan']) ?></strong> ·
        Jumlah: <strong><?= fmt_angka($item['jumlah']) ?></strong>
      </p>
    </div>
    <div class="row-actions paket-head-actions">
      <a href="item.php?paket_id=<?= (int)$paketId ?>" class="btn btn-outline-navy btn-sm" style="text-decoration:none;"><?= icon('chevron-left', 15) ?> Kembali ke Daftar Barang</a>
    </div>
  </div>
</div>

<div class="sum-grid">
  <div class="sum-card">
    <span class="sum-label"><?= icon('store', 15) ?> Sumber Survei</span>
    <span class="sum-val"><?= angka($stats['jml']) ?></span>
  </div>
  <div class="sum-card">
    <span class="sum-label"><?= icon('tag', 15) ?> Harga Terendah</span>
    <span class="sum-val"><?= $stats['min'] !== null ? rp_angka($stats['min']) : '—' ?></span>
  </div>
  <div class="sum-card">
    <span class="sum-label"><?= icon('tag', 15) ?> Harga Tertinggi</span>
    <span class="sum-val"><?= $stats['max'] !== null ? rp_angka($stats['max']) : '—' ?></span>
  </div>
  <div class="sum-card highlight">
    <span class="sum-label"><?= icon('chart', 15) ?> Rata-rata Harga</span>
    <span class="sum-val"><?= $stats['avg'] !== null ? rp_angka($stats['avg']) : '—' ?></span>
  </div>
</div>

<?php if ($aksi === 'tambah' || $editSurvei !== null):
    $isEdit = $aksi === 'edit' || (int)($editSurvei['id'] ?? 0) > 0;
    $f = $editSurvei !== null ? $editSurvei : ['id' => 0, 'sumber' => '', 'telepon' => '',
                        'tanggal' => date('Y-m-d'), 'harga' => null, 'keterangan' => ''];
?>
<div class="admin-card">
  <div class="admin-tools" style="margin-bottom:6px;">
    <h3 style="margin-bottom:0;"><?= $isEdit ? icon('edit', 17) . ' Edit Data Survei' : icon('plus', 17) . ' Tambah Data Survei Harga' ?></h3>
    <a class="btn btn-outline-navy btn-sm" href="survei.php?item_id=<?= (int)$itemId ?>">← Batal</a>
  </div>
  <?php if ($formErr !== ''): ?>
    <div class="alert alert-error"><?= icon('alert', 20) ?> <span><?= e($formErr) ?></span></div>
  <?php endif; ?>
  <form method="post" action="survei.php?item_id=<?= (int)$itemId ?>" class="form-grid" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?= (int)$f['id'] ?>">
    <?= csrf_field() ?>
    <div class="field full">
      <label for="sumber">Sumber Survei <span class="req">*</span></label>
      <input type="text" id="sumber" name="sumber" value="<?= e((string)$f['sumber']) ?>" placeholder="cth. Toko Mina Jaya, Labuha / CV. Bahari Supply / Website Ruparupa" required>
    </div>
    <div class="field">
      <label for="telepon">Kontak / Telepon</label>
      <input type="text" id="telepon" name="telepon" value="<?= e((string)$f['telepon']) ?>" placeholder="Opsional">
    </div>
    <div class="field">
      <label for="tanggal">Tanggal Survei</label>
      <input type="date" id="tanggal" name="tanggal" value="<?= e((string)$f['tanggal']) ?>">
    </div>
    <div class="field">
      <label for="harga">Harga Satuan (Rp) <span class="req">*</span></label>
      <input type="text" id="harga" name="harga" inputmode="decimal" value="<?= $f['harga'] !== null ? fmt_angka($f['harga']) : '' ?>" placeholder="cth. 325" required>
      <span class="form-note">Harga per <?= e($item['satuan']) ?> — angka tanpa titik/koma.</span>
    </div>
    <div class="field">
      <label for="keterangan">Keterangan</label>
      <input type="text" id="keterangan" name="keterangan" value="<?= e((string)$f['keterangan']) ?>" placeholder="cth. Termasuk ongkos kirim">
    </div>
    <div class="field full">
      <label for="foto">Foto Barang (opsional)</label>
      <input type="file" id="foto" name="foto" accept="image/jpeg,image/png,image/webp,image/gif">
      <span class="form-note">Foto barang saat survei di penyedia/toko ini. Maksimal 2 MB (JPG/PNG/WebP/GIF).</span>
      <?php if ($isEdit && (($f['foto_ada'] ?? false) || !empty($f['foto']))): ?>
        <div class="foto-preview">
          <img src="../foto-survei.php?id=<?= (int)$f['id'] ?>" alt="Foto barang saat ini">
          <label class="foto-hapus"><input type="checkbox" name="hapus_foto" value="1"> Hapus foto saat ini</label>
        </div>
      <?php endif; ?>
    </div>
    <div class="field full">
      <button type="submit" class="btn btn-primary"><?= $isEdit ? icon('edit', 16) . ' Simpan Perubahan' : icon('plus', 16) . ' Simpan Data Survei' ?></button>
    </div>
  </form>
</div>
<?php endif; ?>

<div class="admin-card">
  <div class="admin-tools">
    <h3 style="margin-bottom:0;"><?= icon('list', 18) ?> Daftar Sumber Survei</h3>
    <?php if ($aksi !== 'tambah' && $editSurvei === null): ?>
      <a class="btn btn-primary" href="survei.php?item_id=<?= (int)$itemId ?>&aksi=tambah"><?= icon('plus', 16) ?> Tambah Survei</a>
    <?php endif; ?>
  </div>

  <?php if (!$rows): ?>
    <div class="alert alert-info"><?= icon('search', 20) ?> <span>Belum ada data survei untuk barang ini. Klik "Tambah Survei" dan masukkan harga dari minimal satu sumber penawaran.</span></div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="tbl">
      <thead>
        <tr>
          <th>No</th>
          <th>Sumber</th>
          <th>Foto Barang</th>
          <th>Kontak</th>
          <th>Tanggal</th>
          <th class="num">Harga Satuan</th>
          <th>Keterangan</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $no = 0; foreach ($rows as $s): $no++; ?>
        <tr>
          <td><?= $no ?></td>
          <td><strong><?= e($s['sumber']) ?></strong></td>
          <td>
            <?php if (!empty($s['foto'])): ?>
              <a href="../foto-survei.php?id=<?= (int)$s['id'] ?>" target="_blank" title="Lihat foto">
                <img src="../foto-survei.php?id=<?= (int)$s['id'] ?>" alt="Foto barang" class="foto-thumb">
              </a>
            <?php else: ?>
              <span class="muted small">—</span>
            <?php endif; ?>
          </td>
          <td><?= e($s['telepon'] ?: '—') ?></td>
          <td><?= tanggal_id($s['tanggal']) ?></td>
          <td class="num money"><?= rp_angka($s['harga']) ?></td>
          <td class="small muted"><?= e($s['keterangan'] ?: '—') ?></td>
          <td>
            <div class="row-actions">
              <a href="survei.php?item_id=<?= (int)$itemId ?>&aksi=edit&id=<?= (int)$s['id'] ?>" title="Edit"><?= icon('edit', 15) ?></a>
              <a class="del" href="survei.php?item_id=<?= (int)$itemId ?>&aksi=hapus&id=<?= (int)$s['id'] ?>&csrf=<?= urlencode(csrf_token()) ?>"
                 title="Hapus" onclick="return confirm('Hapus data survei ini?')"><?= icon('trash', 15) ?></a>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/_footer.php'; ?>
