<?php
// ============================================================
// Admin — Kelola Paket Pengadaan (tambah, edit, hapus, daftar)
// ============================================================
$pageTitle = 'Paket Pengadaan';
$activeAdmin = 'paket';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../lib/survei.php';

$pdo = db();

$aksi = (string)get('aksi', 'list');
$id   = (int)get('id', 0);
$formErr = '';
$old = null;

// ---------- Hapus ----------
if ($aksi === 'hapus') {
    csrf_check_q();
    $st = $pdo->prepare('SELECT nama, bidang FROM paket WHERE id = ?');
    $st->execute([$id]);
    $rowHapus = $st->fetch();
    if ($rowHapus) {
        if (!is_admin() && $rowHapus['bidang'] !== user_bidang()) {
            flash('Anda hanya dapat menghapus paket pada bidang Anda.', 'error');
            redirect('paket.php');
        }
        $pdo->prepare('DELETE FROM survei WHERE item_id IN (SELECT id FROM item WHERE paket_id = ?)')->execute([$id]);
        $pdo->prepare('DELETE FROM item WHERE paket_id = ?')->execute([$id]);
        $pdo->prepare('DELETE FROM paket WHERE id = ?')->execute([$id]);
        flash('Paket "' . $rowHapus['nama'] . '" beserta barang dan data surveinya telah dihapus.');
    } else {
        flash('Paket tidak ditemukan.', 'error');
    }
    redirect('paket.php');
}

// ---------- Simpan (tambah / edit) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $tahun   = (int)post('tahun', 0);
    $nama    = trim((string)post('nama'));
    $bidang  = trim((string)post('bidang'));
    $nomor   = trim((string)post('nomor'));
    $tanggal = trim((string)post('tanggal'));
    $sumber  = trim((string)post('sumber_dana', 'APBD'));
    $ppk     = trim((string)post('ppk'));
    $ppk_nip = trim((string)post('ppk_nip'));
    $ket     = trim((string)post('keterangan'));
    $baNomor   = trim((string)post('ba_nomor'));
    $baTanggal = trim((string)post('ba_tanggal'));
    $baTim     = trim((string)post('ba_tim'));

    // Operator hanya boleh membuat/menyimpan paket pada bidangnya sendiri.
    if (!is_admin()) $bidang = user_bidang();

    $err = [];
    if ($tahun < TAHUN_MIN || $tahun > TAHUN_MAX) $err[] = 'Tahun anggaran harus antara ' . TAHUN_MIN . ' dan ' . TAHUN_MAX . '.';
    if ($nama === '') $err[] = 'Nama paket wajib diisi.';
    if (!in_array($bidang, BIDANG, true)) $err[] = 'Bidang paket wajib dipilih.';
    if ($tanggal !== '' && strtotime($tanggal) === false) $err[] = 'Tanggal dokumen tidak valid.';
    if ($baTanggal !== '' && strtotime($baTanggal) === false) $err[] = 'Tanggal berita acara tidak valid.';

    if ($err) {
        $formErr = implode(' ', $err);
        $old = ['id' => (int)post('id', 0), 'tahun' => $tahun, 'nama' => $nama, 'bidang' => $bidang,
                'nomor' => $nomor,
                'tanggal' => $tanggal, 'sumber_dana' => $sumber, 'ppk' => $ppk, 'ppk_nip' => $ppk_nip,
                'keterangan' => $ket, 'ba_nomor' => $baNomor, 'ba_tanggal' => $baTanggal, 'ba_tim' => $baTim];
    } else {
        $id = (int)post('id', 0);
        if ($tanggal === '') $tanggal = date('Y-m-d');
        if ($id > 0) {
            // Cek lingkup saat edit (operator)
            $st = $pdo->prepare('SELECT bidang FROM paket WHERE id = ?');
            $st->execute([$id]);
            $bidangLama = $st->fetchColumn();
            if (!is_admin() && $bidangLama !== user_bidang()) {
                flash('Anda hanya dapat mengubah paket pada bidang Anda.', 'error');
                redirect('paket.php');
            }
            $st = $pdo->prepare('UPDATE paket SET nama = ?, tahun = ?, bidang = ?, nomor = ?, tanggal = ?, sumber_dana = ?, ppk = ?, ppk_nip = ?, keterangan = ?, ba_nomor = ?, ba_tanggal = ?, ba_tim = ? WHERE id = ?');
            $st->execute([$nama, $tahun, $bidang, $nomor, $tanggal, $sumber, $ppk, $ppk_nip, $ket, $baNomor, $baTanggal, $baTim, $id]);
            flash('Paket "' . potong($nama, 60) . '" berhasil diperbarui.');
        } else {
            $st = $pdo->prepare('INSERT INTO paket (nama, tahun, bidang, nomor, tanggal, sumber_dana, ppk, ppk_nip, keterangan, ba_nomor, ba_tanggal, ba_tim) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $st->execute([$nama, $tahun, $bidang, $nomor, $tanggal, $sumber, $ppk, $ppk_nip, $ket, $baNomor, $baTanggal, $baTim]);
            $id = (int)$pdo->lastInsertId();
            flash('Paket "' . potong($nama, 60) . '" berhasil ditambahkan. Silakan isi barang dan data survei harganya.');
        }
        redirect('item.php?paket_id=' . $id);
    }
}

// ---------- Siapkan data form ----------
$editPaket = null;
if (isset($old)) {
    $editPaket = $old;
} elseif ($aksi === 'edit' && $id > 0) {
    $st = $pdo->prepare('SELECT * FROM paket WHERE id = ?');
    $st->execute([$id]);
    $editPaket = $st->fetch();
    if (!$editPaket) redirect('paket.php');
    if (!is_admin() && $editPaket['bidang'] !== user_bidang()) {
        flash('Anda hanya dapat mengubah paket pada bidang Anda.', 'error');
        redirect('paket.php');
    }
}

// ================= FORM TAMBAH / EDIT =================
if ($aksi === 'tambah' || $editPaket !== null):
    $isEdit = $aksi === 'edit' || (int)($editPaket['id'] ?? 0) > 0;
    $f = $editPaket !== null ? $editPaket : ['id' => 0, 'tahun' => (int)date('Y'), 'nama' => '', 'bidang' => (is_admin() ? '' : user_bidang()),
                        'nomor' => '',
                        'tanggal' => date('Y-m-d'), 'sumber_dana' => 'APBD', 'ppk' => '', 'ppk_nip' => '',
                        'keterangan' => '', 'ba_nomor' => '', 'ba_tanggal' => date('Y-m-d'), 'ba_tim' => ''];
?>
<div class="admin-card">
  <div class="admin-tools" style="margin-bottom:6px;">
    <h3 style="margin-bottom:0;"><?= $isEdit ? icon('edit', 17) . ' Edit Paket' : icon('plus', 17) . ' Tambah Paket Baru' ?></h3>
    <a class="btn btn-outline-navy btn-sm" href="paket.php">← Kembali ke Daftar</a>
  </div>
  <?php if ($formErr !== ''): ?>
    <div class="alert alert-error"><?= icon('alert', 20) ?> <span><?= e($formErr) ?></span></div>
  <?php endif; ?>
  <form method="post" action="paket.php" class="form-grid">
    <input type="hidden" name="id" value="<?= (int)$f['id'] ?>">
    <?= csrf_field() ?>
    <div class="field">
      <label for="tahun">Tahun Anggaran <span class="req">*</span></label>
      <input type="number" id="tahun" name="tahun" min="<?= TAHUN_MIN ?>" max="<?= TAHUN_MAX ?>" value="<?= (int)$f['tahun'] ?>" required>
    </div>
    <div class="field">
      <label for="bidang">Bidang <span class="req">*</span></label>
      <?php if (is_admin()): ?>
        <select id="bidang" name="bidang" required>
          <option value="">— Pilih Bidang —</option>
          <?php foreach (BIDANG as $b): ?>
            <option value="<?= e($b) ?>" <?= $f['bidang'] === $b ? 'selected' : '' ?>><?= e($b) ?></option>
          <?php endforeach; ?>
        </select>
      <?php else: ?>
        <input type="text" value="<?= e(user_bidang()) ?>" disabled>
        <input type="hidden" name="bidang" value="<?= e(user_bidang()) ?>">
        <span class="form-note">Bidang Anda — <?= e(user_bidang()) ?></span>
      <?php endif; ?>
    </div>
    <div class="field full">
      <label for="nama">Nama Paket <span class="req">*</span></label>
      <input type="text" id="nama" name="nama" value="<?= e((string)$f['nama']) ?>" placeholder="cth. Pengadaan Bibit Ikan Bandeng untuk Kelompok Pembudidaya" required>
    </div>
    <div class="field">
      <label for="nomor">Nomor Dokumen</label>
      <input type="text" id="nomor" name="nomor" value="<?= e((string)$f['nomor']) ?>" placeholder="cth. 600/…/2025/DINASPERIKANAN">
    </div>
    <div class="field">
      <label for="tanggal">Tanggal Survei</label>
      <input type="date" id="tanggal" name="tanggal" value="<?= e((string)$f['tanggal']) ?>">
    </div>
    <div class="field">
      <label for="sumber_dana">Sumber Dana</label>
      <input type="text" id="sumber_dana" name="sumber_dana" list="sumber-dana-list" value="<?= e((string)$f['sumber_dana']) ?>">
      <datalist id="sumber-dana-list">
        <?php foreach (SUMBER_DANA_UMUM as $s): ?><option value="<?= e($s) ?>"><?php endforeach; ?>
      </datalist>
    </div>
    <div class="field">
      <label for="ppk">Nama PPK</label>
      <input type="text" id="ppk" name="ppk" value="<?= e((string)$f['ppk']) ?>" placeholder="Pejabat Pembuat Komitmen">
    </div>
    <div class="field">
      <label for="ppk_nip">NIP PPK</label>
      <input type="text" id="ppk_nip" name="ppk_nip" value="<?= e((string)$f['ppk_nip']) ?>" placeholder="cth. 197501012000031001">
    </div>
    <div class="field full">
      <label for="keterangan">Keterangan Paket</label>
      <textarea id="keterangan" name="keterangan" rows="4" placeholder="Uraian singkat lingkup pengadaan…"><?= e((string)$f['keterangan']) ?></textarea>
    </div>
    <div class="field full" style="margin-top:4px;">
      <div class="divider"></div>
      <h3 style="margin-bottom:4px; color:var(--navy-900);"><?= icon('file-text', 16) ?> Berita Acara Survei</h3>
      <p class="form-note" style="margin-bottom:14px;">Digunakan untuk dokumen Berita Acara Survei Harga (PDF) yang dapat diunduh.</p>
    </div>
    <div class="field">
      <label for="ba_nomor">Nomor Berita Acara</label>
      <input type="text" id="ba_nomor" name="ba_nomor" value="<?= e((string)$f['ba_nomor']) ?>" placeholder="cth. 620/…/2025/DINASPERIKANAN">
    </div>
    <div class="field">
      <label for="ba_tanggal">Tanggal Berita Acara</label>
      <input type="date" id="ba_tanggal" name="ba_tanggal" value="<?= e((string)$f['ba_tanggal']) ?>">
    </div>
    <div class="field full">
      <label for="ba_tim">Tim Survei Harga (satu nama per baris)</label>
      <textarea id="ba_tim" name="ba_tim" rows="4" placeholder="1. Nama Anggota — Jabatan&#10;2. Nama Anggota — Jabatan"><?= e((string)$f['ba_tim']) ?></textarea>
      <span class="form-note">Format: <em>Nama — Jabatan</em>. Tiap baris menjadi satu penandatangan dalam dokumen BA.</span>
    </div>
    <div class="field full">
      <button type="submit" class="btn btn-primary"><?= $isEdit ? icon('edit', 16) . ' Simpan Perubahan' : icon('plus', 16) . ' Simpan & Lanjut Isi Barang' ?></button>
    </div>
  </form>
</div>

<?php else:
// ================= DAFTAR PAKET =================
$tahunF = (int)get('tahun', 0);
$qF = trim((string)get('q', ''));
$bidangF = trim((string)get('bidang', ''));
$where = [];
$params = [];

// Lingkup: operator hanya melihat bidangnya sendiri.
[$scopeSql, $scopeParams] = scope_where();
if ($scopeSql !== '') {
    $where[] = $scopeSql;
    $params = array_merge($params, $scopeParams);
    $bidangF = user_bidang();
} elseif ($bidangF !== '' && in_array($bidangF, BIDANG, true)) {
    $where[] = 'bidang = ?';
    $params[] = $bidangF;
}
if ($tahunF > 0) { $where[] = 'tahun = ?'; $params[] = $tahunF; }
if ($qF !== '') { $where[] = 'nama LIKE ?'; $params[] = "%$qF%"; }
$sqlWhere = $where ? ' WHERE ' . implode(' AND ', $where) : '';

$sql = "SELECT * FROM paket" . $sqlWhere . " ORDER BY tahun DESC, id DESC";
$st = $pdo->prepare($sql);
$st->execute($params);
$rows = $st->fetchAll();
$tahunList = $pdo->query('SELECT DISTINCT tahun FROM paket ORDER BY tahun DESC')->fetchAll(PDO::FETCH_COLUMN);

$paketRows = [];
foreach ($rows as $p) {
    [, $items, $jmlItemP, $jmlSurvP] = paket_items($pdo, (int)$p['id']);
    $paketRows[] = ['p' => $p, 'jml_item' => $jmlItemP, 'jml_survei' => $jmlSurvP];
}
?>

<div class="admin-card">
  <div class="admin-tools">
    <form method="get" action="paket.php" class="filter-bar filter-bar-inline">
      <select name="tahun" onchange="this.form.submit()">
        <option value="0">Semua Tahun</option>
        <?php foreach ($tahunList as $t): ?>
          <option value="<?= (int)$t ?>" <?= $tahunF === (int)$t ? 'selected' : '' ?>><?= (int)$t ?></option>
        <?php endforeach; ?>
      </select>
      <?php if (is_admin()): ?>
      <select name="bidang" onchange="this.form.submit()">
        <option value="">Semua Bidang</option>
        <?php foreach (BIDANG as $b): ?>
          <option value="<?= e($b) ?>" <?= $bidangF === $b ? 'selected' : '' ?>><?= e($b) ?></option>
        <?php endforeach; ?>
      </select>
      <?php endif; ?>
      <input type="search" name="q" value="<?= e($qF) ?>" placeholder="Cari nama paket…">
      <button type="submit" class="btn btn-outline-navy btn-sm"><?= icon('search', 15) ?> Cari</button>
    </form>
    <a class="btn btn-primary" href="paket.php?aksi=tambah"><?= icon('plus', 16) ?> Tambah Paket</a>
  </div>

  <?php if (!$paketRows): ?>
    <div class="alert alert-info"><?= icon('search', 20) ?> <span>Belum ada paket pengadaan. Klik "Tambah Paket" untuk memulai.</span></div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="tbl">
      <thead>
        <tr>
          <th>TA</th>
          <th>Nama Paket</th>
          <th>Bidang</th>
          <th>Sumber Dana</th>
          <th class="num">Barang</th>
          <th class="num">Data Survei</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($paketRows as $r): $p = $r['p']; ?>
        <tr>
          <td><span class="badge badge-tahun"><?= (int)$p['tahun'] ?></span></td>
          <td><a href="item.php?paket_id=<?= (int)$p['id'] ?>"><strong><?= e(potong($p['nama'], 60)) ?></strong></a></td>
          <td><span class="badge badge-bidang"><?= e($p['bidang'] ?: '—') ?></span></td>
          <td><?= e($p['sumber_dana'] ?: '—') ?></td>
          <td class="num"><?= (int)$r['jml_item'] ?></td>
          <td class="num"><?= (int)$r['jml_survei'] ?></td>
          <td>
            <div class="row-actions">
              <a href="item.php?paket_id=<?= (int)$p['id'] ?>" title="Kelola Barang & Survei Harga"><?= icon('box', 15) ?></a>
              <a href="berita-acara.php?paket_id=<?= (int)$p['id'] ?>" title="Cetak Berita Acara Survei (Print/PDF)"><?= icon('file-text', 15) ?></a>
              <a href="laporan.php?paket_id=<?= (int)$p['id'] ?>" title="Cetak Rekap Survei"><?= icon('printer', 15) ?></a>
              <a href="paket.php?aksi=edit&id=<?= (int)$p['id'] ?>" title="Edit"><?= icon('edit', 15) ?></a>
              <a class="del" href="paket.php?aksi=hapus&id=<?= (int)$p['id'] ?>&csrf=<?= urlencode(csrf_token()) ?>"
                 title="Hapus" onclick="return confirm('Hapus paket ini beserta seluruh barang dan data surveinya?')"><?= icon('trash', 15) ?></a>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php require __DIR__ . '/_footer.php'; ?>
