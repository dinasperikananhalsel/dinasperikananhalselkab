<?php
// ============================================================
// Admin — Ganti password
// ============================================================
$pageTitle = 'Ganti Password';
$activeAdmin = 'password';
require_once __DIR__ . '/_header.php'; // session + auth + buffer output
require_once __DIR__ . '/../lib/db.php';

$pdo = db();
$err = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $lama  = (string)post('password_lama');
    $baru  = (string)post('password_baru');
    $ulang = (string)post('password_ulang');

    $st = $pdo->prepare('SELECT password FROM admin WHERE id = ?');
    $st->execute([$_SESSION['admin_id']]);
    $hash = $st->fetchColumn();

    if (!password_verify($lama, (string)$hash)) {
        $err = 'Password lama tidak sesuai.';
    } elseif (u8len($baru) < 8) {
        $err = 'Password baru minimal 8 karakter.';
    } elseif ($baru !== $ulang) {
        $err = 'Konfirmasi password baru tidak sama.';
    } else {
        $st = $pdo->prepare('UPDATE admin SET password = ? WHERE id = ?');
        $st->execute([password_hash($baru, PASSWORD_DEFAULT), $_SESSION['admin_id']]);
        flash('Password berhasil diganti.');
        redirect('password.php');
    }
}
?>

<div class="admin-card" style="max-width:520px;">
  <h3><?= icon('shield', 17) ?> Ganti Password</h3>
  <?php if ($err): ?>
    <div class="alert alert-error"><?= icon('alert', 20) ?> <span><?= e($err) ?></span></div>
  <?php endif; ?>
  <form method="post" action="password.php">
    <?= csrf_field() ?>
    <div class="field mb-16">
      <label for="password_lama">Password Lama</label>
      <input type="password" id="password_lama" name="password_lama" required autocomplete="current-password">
    </div>
    <div class="field mb-16">
      <label for="password_baru">Password Baru (min. 8 karakter)</label>
      <input type="password" id="password_baru" name="password_baru" required minlength="8" autocomplete="new-password">
    </div>
    <div class="field mb-16">
      <label for="password_ulang">Ulangi Password Baru</label>
      <input type="password" id="password_ulang" name="password_ulang" required minlength="8" autocomplete="new-password">
    </div>
    <button type="submit" class="btn btn-primary"><?= icon('shield', 16) ?> Simpan Password Baru</button>
  </form>
</div>

<?php require __DIR__ . '/_footer.php'; ?>
