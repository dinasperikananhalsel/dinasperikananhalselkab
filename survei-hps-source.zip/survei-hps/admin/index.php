<?php
// ============================================================
// Admin — Dashboard (ringkasan paket & survei harga)
// ============================================================
$pageTitle = 'Dashboard';
$activeAdmin = 'dashboard';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../lib/survei.php';

$pdo = db();

$tahunIni = (int)date('Y');

// Lingkup: admin melihat semua, operator hanya bidangnya sendiri
[$scopeSql, $scopeParams] = scope_where();
$scopeWhere = $scopeSql !== '' ? ' WHERE ' . $scopeSql : '';

$stK = $pdo->prepare('SELECT COUNT(*) FROM paket' . $scopeWhere);
$stK->execute($scopeParams);
$jmlPaket = (int)$stK->fetchColumn();

$stK = $pdo->prepare('SELECT COUNT(*) FROM paket' . ($scopeWhere !== '' ? $scopeWhere . ' AND ' : ' WHERE ') . 'tahun = ' . $tahunIni);
$stK->execute($scopeParams);
$jmlPaketTh = (int)$stK->fetchColumn();

$stK = $pdo->prepare('SELECT COUNT(*) FROM item i JOIN paket p ON p.id = i.paket_id' . ($scopeSql !== '' ? ' WHERE ' . $scopeSql : ''));
$stK->execute($scopeParams);
$jmlItem = (int)$stK->fetchColumn();

$stK = $pdo->prepare('SELECT COUNT(*) FROM survei s JOIN item i ON i.id = s.item_id JOIN paket p ON p.id = i.paket_id' . ($scopeSql !== '' ? ' WHERE ' . $scopeSql : ''));
$stK->execute($scopeParams);
$jmlSurvei = (int)$stK->fetchColumn();

// Daftar paket terbaru (sesuai lingkup)
$st = $pdo->prepare('SELECT * FROM paket' . $scopeWhere . ' ORDER BY tahun DESC, id DESC LIMIT 50');
$st->execute($scopeParams);
$rows = $st->fetchAll();
$paketList = [];
foreach ($rows as $p) {
    [, $items, $jmlItemP, $jmlSurvP] = paket_items($pdo, (int)$p['id']);
    $paketList[] = [
        'id' => (int)$p['id'],
        'nama' => $p['nama'],
        'tahun' => (int)$p['tahun'],
        'bidang' => $p['bidang'],
        'sumber_dana' => $p['sumber_dana'],
        'jml_item' => $jmlItemP,
        'jml_survei' => $jmlSurvP,
    ];
}
$paketList = array_slice($paketList, 0, 8);
?>

<div class="kpi-grid">
  <div class="kpi">
    <div class="kpi-icon navy"><?= icon('file-text', 22) ?></div>
    <div>
      <div class="kpi-num"><?= angka($jmlPaket) ?></div>
      <div class="kpi-label">Paket Pengadaan</div>
    </div>
  </div>
  <div class="kpi">
    <div class="kpi-icon gold"><?= icon('calendar', 22) ?></div>
    <div>
      <div class="kpi-num"><?= angka($jmlPaketTh) ?></div>
      <div class="kpi-label">Paket TA <?= $tahunIni ?></div>
    </div>
  </div>
  <div class="kpi">
    <div class="kpi-icon teal"><?= icon('box', 22) ?></div>
    <div>
      <div class="kpi-num"><?= angka($jmlItem) ?></div>
      <div class="kpi-label">Barang / Jasa Disurvei</div>
    </div>
  </div>
  <div class="kpi">
    <div class="kpi-icon sky"><?= icon('store', 22) ?></div>
    <div>
      <div class="kpi-num"><?= angka($jmlSurvei) ?></div>
      <div class="kpi-label">Data Survei Harga</div>
    </div>
  </div>
</div>

<div class="admin-card">
  <div class="admin-tools">
    <h3 style="margin-bottom:0;"><?= icon('layers', 18) ?> Paket Terbaru <?php if (!is_admin()): ?><span class="muted small" style="font-weight:600;">— <?= e(user_bidang()) ?></span><?php endif; ?></h3>
    <a class="btn btn-primary" href="paket.php?aksi=tambah"><?= icon('plus', 16) ?> Tambah Paket</a>
  </div>

  <?php if (!$paketList): ?>
    <div class="alert alert-info"><?= icon('search', 20) ?> <span>Belum ada paket. Klik "Tambah Paket" untuk mulai mencatat survei harga, lalu isi barang dan data surveinya.</span></div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="tbl">
      <thead>
        <tr>
          <th>TA</th>
          <th>Nama Paket</th>
          <th>Bidang</th>
          <th>Sumber Dana</th>
          <th class="num">Barang</th>
          <th class="num">Data Survei</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($paketList as $p): ?>
        <tr>
          <td><span class="badge badge-tahun"><?= (int)$p['tahun'] ?></span></td>
          <td><a href="item.php?paket_id=<?= (int)$p['id'] ?>"><strong><?= e(potong($p['nama'], 55)) ?></strong></a></td>
          <td><span class="badge badge-bidang"><?= e($p['bidang'] ?: '—') ?></span></td>
          <td><?= e($p['sumber_dana'] ?: '—') ?></td>
          <td class="num"><?= (int)$p['jml_item'] ?></td>
          <td class="num"><?= (int)$p['jml_survei'] ?></td>
          <td>
            <div class="row-actions">
              <a href="item.php?paket_id=<?= (int)$p['id'] ?>" title="Kelola Barang & Survei"><?= icon('box', 15) ?></a>
              <a href="berita-acara.php?paket_id=<?= (int)$p['id'] ?>" title="Cetak Berita Acara Survei (Print/PDF)"><?= icon('file-text', 15) ?></a>
              <a href="laporan.php?paket_id=<?= (int)$p['id'] ?>" title="Cetak Rekap Survei"><?= icon('printer', 15) ?></a>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<div class="admin-card">
  <h3><?= icon('store', 18) ?> Cara Menggunakan Aplikasi</h3>
  <ol class="howto">
    <li>Buat <strong>Paket Pengadaan</strong> sebagai konteks survei (tahun anggaran, sumber dana, PPK).</li>
    <li>Isi <strong>Barang / Jasa</strong> yang akan disurvei: uraian, spesifikasi, satuan, dan jumlah.</li>
    <li>Masukkan <strong>data survei harga</strong> dari berbagai sumber (toko, penyedia, situs belanja) untuk setiap barang — lengkap dengan kontak dan tanggal survei.</li>
    <li>Aplikasi merangkum otomatis: jumlah sumber, harga terendah, harga tertinggi, dan rata-rata harga per barang.</li>
    <li>Cetak <strong>rekap hasil survei</strong> untuk arsip / bahan penyusunan harga.</li>
  </ol>
</div>

<?php require __DIR__ . '/_footer.php'; ?>
