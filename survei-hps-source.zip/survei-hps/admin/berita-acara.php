<?php
// ============================================================
// Berita Acara Survei Harga — mode cetak
// Ditampilkan sebagai halaman cetak; simpan PDF via menu
// Cetak/Simpan PDF pada peramban (kertas & margin dapat diatur).
// ============================================================
ob_start();
session_start();
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/icons.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/survei.php';
require_auth();

$pdo = db();
$paketId = (int)get('paket_id', 0);

[$paket, $items, , ] = paket_items($pdo, $paketId);
if (!$paket) {
    flash('Paket tidak ditemukan.', 'error');
    redirect('paket.php');
}
// Lingkup: operator hanya boleh mencetak dokumen bidangnya sendiri
if (!is_admin() && $paket['bidang'] !== user_bidang()) {
    flash('Anda hanya dapat mengakses paket pada bidang Anda.', 'error');
    redirect('paket.php');
}

// ---------- Statistik keseluruhan paket ----------
$st = $pdo->prepare('SELECT COUNT(*) AS jml, MIN(s.harga) AS min_h, MAX(s.harga) AS max_h
                     FROM survei s JOIN item i ON i.id = s.item_id WHERE i.paket_id = ?');
$st->execute([$paketId]);
$statPaket = $st->fetch();
$jmlSurveiPaket = (int)$statPaket['jml'];
$minPaket = $statPaket['min_h'] !== null ? (float)$statPaket['min_h'] : null;
$maxPaket = $statPaket['max_h'] !== null ? (float)$statPaket['max_h'] : null;
$avgPaket = paket_avg_harga($pdo, $paketId);

// ---------- Tanggal & tim ----------
$tglBA = $paket['ba_tanggal'] ?: ($paket['tanggal'] ?: date('Y-m-d'));
$hari = ['1' => 'Senin', '2' => 'Selasa', '3' => 'Rabu', '4' => 'Kamis',
         '5' => 'Jumat', '6' => 'Sabtu', '7' => 'Minggu'][date('N', strtotime($tglBA))] ?? '';
$tglBAId = tanggal_id($tglBA);
$nomorBA = trim((string)$paket['ba_nomor']);

$tim = [];
foreach (preg_split('/\r?\n/', (string)$paket['ba_tim']) as $baris) {
    $baris = trim($baris);
    if ($baris === '') continue;
    $baris = preg_replace('/^\d+[.)]\s*/', '', $baris); // buang nomor "1. "
    if (preg_match('/^(.+?)\s*[—-]\s*(.+)$/u', $baris, $m)) {
        $tim[] = [trim($m[1]), trim($m[2])];
    } else {
        $tim[] = [$baris, ''];
    }
}
if (!$tim) $tim = [['.........................', '']];

$survByItem = [];
foreach (paket_survei_rows($pdo, $paketId) as $r) {
    $survByItem[(int)$r['item_id']][] = $r;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex">
<title>Berita Acara Survei Harga — <?= e($paket['nama']) ?></title>
<link rel="icon" type="image/png" href="../assets/img/favicon-64.png">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
  /* Aturan kertas untuk cetak/PDF: A4, margin rapi */
  @page { size: A4; margin: 18mm 16mm 16mm; }
  @media print {
    .doc-doc { font-size: 12.5px; line-height: 1.55; }
    table.doc-tbl { page-break-inside: auto; }
    table.doc-tbl tr { page-break-inside: avoid; }
    table.doc-tbl thead { display: table-header-group; }
    .doc-ttd-grid, .doc-kesimpulan { page-break-inside: avoid; }
  }
</style>
</head>
<body class="doc-body">

<div class="no-print doc-toolbar">
  <div class="doc-toolbar-left">
    <a href="paket.php?aksi=edit&id=<?= (int)$paketId ?>" class="btn btn-outline-navy btn-sm" title="Atur nomor, tanggal, dan tim survei"><?= icon('edit', 15) ?> Atur Nomor &amp; Tim</a>
    <a href="item.php?paket_id=<?= (int)$paketId ?>" class="btn btn-outline-navy btn-sm"><?= icon('chevron-left', 15) ?> Barang &amp; Survei</a>
    <a href="paket.php" class="btn btn-outline-navy btn-sm"><?= icon('list', 15) ?> Daftar Paket</a>
  </div>
  <button onclick="window.print()" class="btn btn-gold btn-sm"><?= icon('printer', 16) ?> Cetak / Simpan PDF</button>
</div>

<div class="doc-doc">
  <!-- ======= KOP ======= -->
  <div class="doc-kop">
    <img src="../assets/img/logo-daerah.png" alt="Lambang Daerah" class="doc-logo">
    <div class="doc-kop-text">
      <div class="doc-wilayah">PEMERINTAH KABUPATEN HALMAHERA SELATAN</div>
      <div class="doc-instansi">DINAS PERIKANAN</div>
      <div class="doc-alamat"><?= e(ALAMAT_KANTOR) ?> — Telepon: <?= e(TELEPON) ?> — Email: <?= e(EMAIL_DINAS) ?></div>
    </div>
  </div>
  <hr class="doc-kop-line">

  <!-- ======= JUDUL ======= -->
  <div class="doc-title">BERITA ACARA SURVEI HARGA</div>
  <div class="doc-subtitle"><?= $nomorBA !== '' ? 'Nomor: ' . e($nomorBA) : 'Nomor: .............................' ?></div>

  <!-- ======= PEMBUKAAN ======= -->
  <div class="doc-pembukaan">
    <p>Pada hari ini, <?= e($hari) ?>, tanggal <?= e($tglBAId) ?>, bertempat di Kantor Dinas Perikanan Kabupaten Halmahera Selatan, telah dilaksanakan survei harga barang/jasa dalam rangka persiapan pengadaan: <strong>"<?= e($paket['nama']) ?>"</strong> (Tahun Anggaran <?= (int)$paket['tahun'] ?>, Bidang <?= e($paket['bidang'] ?: '-') ?>, Sumber Dana <?= e($paket['sumber_dana'] ?: '-') ?>).</p>
    <p>Hasil survei harga dari beberapa sumber penawaran adalah sebagai berikut:</p>
  </div>

  <!-- ======= TABEL HASIL SURVEI ======= -->
  <table class="doc-tbl">
    <thead>
      <tr>
        <th class="c" style="width:30px;">No</th>
        <th>Uraian / Spesifikasi</th>
        <th class="c" style="width:55px;">Satuan</th>
        <th class="c" style="width:65px;">Volume</th>
        <th>Sumber Survei (Harga Satuan)</th>
        <th class="r" style="width:100px;">Rata-rata</th>
      </tr>
    </thead>
    <tbody>
      <?php $no = 0; foreach ($items as $it): $no++;
          $stats = $it['stats'];
          $belum = $stats['jml'] === 0;
          $list  = $survByItem[(int)$it['id']] ?? [];
      ?>
      <tr>
        <td class="c"><?= $no ?></td>
        <td class="l">
          <strong><?= e($it['uraian']) ?></strong>
          <?php if ($it['spek'] !== ''): ?><br><span class="spek"><?= e($it['spek']) ?></span><?php endif; ?>
          <?php if ($belum): ?> <span class="spek">(belum ada data survei)</span><?php endif; ?>
        </td>
        <td class="c"><?= e($it['satuan']) ?></td>
        <td class="c"><?= fmt_angka($it['jumlah']) ?></td>
        <td class="l">
          <?php if ($belum): ?>—<?php else: ?>
            <?php $i = 0; foreach ($list as $s): $i++; ?>
              <span class="sumber-line"><?= $i ?>. <?= e($s['sumber']) ?> : Rp <?= angka($s['harga']) ?></span>
            <?php endforeach; ?>
          <?php endif; ?>
        </td>
        <td class="r"><?= $belum ? '—' : '<strong>Rp ' . fmt_angka($stats['avg']) . '</strong>' ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- ======= KESIMPULAN ======= -->
  <div class="doc-kesimpulan">
    <p class="k-title">KESIMPULAN</p>
    <?php if ($jmlSurveiPaket > 0): ?>
      <p>Dari hasil survei harga terhadap <?= count($items) ?> jenis barang/jasa dengan total <?= angka($jmlSurveiPaket) ?> sumber penawaran, diperoleh rata-rata harga survei secara keseluruhan sebesar <strong>Rp <?= fmt_angka($avgPaket) ?></strong>. Harga penawaran terendah yang ditemukan adalah <strong>Rp <?= angka($minPaket) ?></strong> dan tertinggi <strong>Rp <?= angka($maxPaket) ?></strong>. Hasil survei ini menjadi bahan acuan dalam penyusunan harga pengadaan dimaksud.</p>
    <?php else: ?>
      <p>Belum terdapat data hasil survei harga yang tercatat untuk paket ini.</p>
    <?php endif; ?>
    <p>Demikian Berita Acara ini dibuat dengan sebenarnya untuk dipergunakan sebagaimana mestinya.</p>
  </div>

  <!-- ======= TANDA TANGAN ======= -->
  <div class="doc-ttd">
    <div class="doc-ttd-right"><?= e(KODE_WILAYAH) ?>, <?= e($tglBAId) ?></div>
    <div class="doc-ttd-grid">
      <div class="doc-ttd-block">
        <p>Dibuat oleh,<br>Tim Survei Harga</p>
        <?php foreach ($tim as $t): ?>
          <div class="ba-sign">
            <div class="ba-sign-space"></div>
            <p class="doc-ttd-name"><strong><?= e($t[0]) ?></strong></p>
            <p><?= e($t[1] !== '' ? $t[1] : '.........................') ?></p>
          </div>
        <?php endforeach; ?>
      </div>
      <div class="doc-ttd-block">
        <p>Mengetahui,<br>Pejabat Pembuat Komitmen</p>
        <div class="ba-sign">
          <div class="ba-sign-space"></div>
          <p class="doc-ttd-name"><strong><?= e($paket['ppk'] ?: '……………………………………') ?></strong></p>
          <p>NIP. <?= e($paket['ppk_nip'] ?: '…………………………') ?></p>
        </div>
      </div>
    </div>
  </div>

  <p class="doc-note mt-16">Dokumen ini dibuat secara otomatis melalui Aplikasi Survei Harga Barang Dinas Perikanan Kabupaten Halmahera Selatan. Untuk menyimpan sebagai PDF, gunakan menu Cetak / Simpan sebagai PDF pada peramban.</p>
</div>

</body>
</html>
