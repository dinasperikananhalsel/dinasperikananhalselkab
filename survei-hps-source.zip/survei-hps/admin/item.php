<?php
// ============================================================
// Admin — Kelola Barang/Jasa Paket + ringkasan survei harga
// ============================================================
$pageTitle = 'Barang & Survei';
$activeAdmin = 'paket';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../lib/survei.php';

$pdo = db();

$paketId = (int)get('paket_id', 0);
$st = $pdo->prepare('SELECT * FROM paket WHERE id = ?');
$st->execute([$paketId]);
$paket = $st->fetch();
if (!$paket) {
    flash('Paket tidak ditemukan.', 'error');
    redirect('paket.php');
}
// Lingkup: operator hanya boleh mengelola paket bidangnya sendiri
if (!is_admin() && $paket['bidang'] !== user_bidang()) {
    flash('Anda hanya dapat mengelola paket pada bidang Anda.', 'error');
    redirect('paket.php');
}

$aksi = (string)get('aksi', 'list');
$id   = (int)get('id', 0);
$formErr = '';
$old = null;

// ---------- Hapus item ----------
if ($aksi === 'hapus') {
    csrf_check_q();
    $st = $pdo->prepare('SELECT uraian FROM item WHERE id = ? AND paket_id = ?');
    $st->execute([$id, $paketId]);
    $uraian = $st->fetchColumn();
    if ($uraian) {
        $pdo->prepare('DELETE FROM survei WHERE item_id = ?')->execute([$id]);
        $pdo->prepare('DELETE FROM item WHERE id = ? AND paket_id = ?')->execute([$id, $paketId]);
        flash('Barang "' . potong($uraian, 50) . '" beserta data surveinya telah dihapus.');
    } else {
        flash('Barang tidak ditemukan.', 'error');
    }
    redirect('item.php?paket_id=' . $paketId);
}

// ---------- Simpan item ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $uraian = trim((string)post('uraian'));
    $spek   = trim((string)post('spek'));
    $satuan = trim((string)post('satuan'));
    $jumlah = angka_post('jumlah');

    $err = [];
    if ($uraian === '') $err[] = 'Uraian barang wajib diisi.';
    if ($satuan === '') $err[] = 'Satuan wajib diisi.';
    if ($jumlah === null || $jumlah <= 0) $err[] = 'Jumlah/volume harus lebih dari 0.';

    if ($err) {
        $formErr = implode(' ', $err);
        $old = ['id' => (int)post('id', 0), 'uraian' => $uraian, 'spek' => $spek,
                'satuan' => $satuan, 'jumlah' => $jumlah ?? 1];
    } else {
        $id = (int)post('id', 0);
        if ($id > 0) {
            $st = $pdo->prepare('UPDATE item SET uraian = ?, spek = ?, satuan = ?, jumlah = ? WHERE id = ? AND paket_id = ?');
            $st->execute([$uraian, $spek, $satuan, $jumlah, $id, $paketId]);
            flash('Barang "' . potong($uraian, 50) . '" berhasil diperbarui.');
        } else {
            $urutan = (int)$pdo->query('SELECT COALESCE(MAX(urutan), 0) + 1 FROM item WHERE paket_id = ' . $paketId)->fetchColumn();
            $st = $pdo->prepare('INSERT INTO item (paket_id, uraian, spek, satuan, jumlah, urutan) VALUES (?, ?, ?, ?, ?, ?)');
            $st->execute([$paketId, $uraian, $spek, $satuan, $jumlah, $urutan]);
            flash('Barang "' . potong($uraian, 50) . '" ditambahkan. Masukkan data survei harganya.');
        }
        redirect('item.php?paket_id=' . $paketId);
    }
}

// ---------- Siapkan data form ----------
$editItem = null;
if (isset($old)) {
    $editItem = $old;
} elseif ($aksi === 'edit' && $id > 0) {
    $st = $pdo->prepare('SELECT * FROM item WHERE id = ? AND paket_id = ?');
    $st->execute([$id, $paketId]);
    $editItem = $st->fetch();
    if (!$editItem) redirect('item.php?paket_id=' . $paketId);
}

// ---------- Data list ----------
[$paket2, $items, $jmlItem, $jmlSurvei] = paket_items($pdo, $paketId);
$avgPaket = paket_avg_harga($pdo, $paketId);
?>

<div class="admin-card paket-head">
  <div class="paket-head-top">
    <div>
      <span class="badge badge-tahun">TA <?= (int)$paket['tahun'] ?></span>
      <span class="badge badge-bidang"><?= e($paket['bidang'] ?: '—') ?></span>
      <h3 style="margin:8px 0 4px;"><?= e($paket['nama']) ?></h3>
      <p class="muted small">
        Sumber dana: <strong><?= e($paket['sumber_dana'] ?: '—') ?></strong>
        <?php if ($paket['ppk'] !== ''): ?> · PPK: <strong><?= e($paket['ppk']) ?></strong><?php endif; ?>
      </p>
    </div>
    <div class="row-actions paket-head-actions">
      <a href="berita-acara.php?paket_id=<?= (int)$paketId ?>" title="Cetak Berita Acara Survei (Print/PDF)" class="btn btn-gold btn-sm" style="text-decoration:none;"><?= icon('file-text', 15) ?> Cetak Berita Acara</a>
      <a href="laporan.php?paket_id=<?= (int)$paketId ?>" title="Cetak Rekap Hasil Survei" class="btn btn-outline-navy btn-sm" style="text-decoration:none;"><?= icon('printer', 15) ?> Cetak Rekap</a>
      <a href="paket.php?aksi=edit&id=<?= (int)$paketId ?>" title="Edit Paket" class="btn btn-outline-navy btn-sm" style="text-decoration:none;"><?= icon('edit', 15) ?> Edit Paket</a>
      <a href="paket.php" title="Kembali ke Daftar" class="btn btn-outline-navy btn-sm" style="text-decoration:none;"><?= icon('chevron-left', 15) ?> Daftar</a>
    </div>
  </div>
</div>

<div class="sum-grid">
  <div class="sum-card">
    <span class="sum-label"><?= icon('box', 15) ?> Jumlah Barang</span>
    <span class="sum-val"><?= angka($jmlItem) ?></span>
  </div>
  <div class="sum-card">
    <span class="sum-label"><?= icon('store', 15) ?> Data Survei Harga</span>
    <span class="sum-val"><?= angka($jmlSurvei) ?></span>
  </div>
  <div class="sum-card highlight">
    <span class="sum-label"><?= icon('chart', 15) ?> Rata-rata Harga Survei</span>
    <span class="sum-val"><?= $avgPaket !== null ? rp_angka($avgPaket) : '—' ?></span>
  </div>
</div>

<?php if ($aksi === 'tambah' || $editItem !== null):
    $isEdit = $aksi === 'edit' || (int)($editItem['id'] ?? 0) > 0;
    $f = $editItem !== null ? $editItem : ['id' => 0, 'uraian' => '', 'spek' => '', 'satuan' => 'unit', 'jumlah' => 1];
?>
<div class="admin-card">
  <div class="admin-tools" style="margin-bottom:6px;">
    <h3 style="margin-bottom:0;"><?= $isEdit ? icon('edit', 17) . ' Edit Barang' : icon('plus', 17) . ' Tambah Barang Baru' ?></h3>
    <a class="btn btn-outline-navy btn-sm" href="item.php?paket_id=<?= (int)$paketId ?>">← Batal</a>
  </div>
  <?php if ($formErr !== ''): ?>
    <div class="alert alert-error"><?= icon('alert', 20) ?> <span><?= e($formErr) ?></span></div>
  <?php endif; ?>
  <form method="post" action="item.php?paket_id=<?= (int)$paketId ?>" class="form-grid">
    <input type="hidden" name="id" value="<?= (int)$f['id'] ?>">
    <?= csrf_field() ?>
    <div class="field full">
      <label for="uraian">Uraian Barang / Jasa <span class="req">*</span></label>
      <input type="text" id="uraian" name="uraian" value="<?= e((string)$f['uraian']) ?>" placeholder="cth. Bibit ikan bandeng ukuran 3–5 cm" required>
    </div>
    <div class="field full">
      <label for="spek">Spesifikasi (opsional)</label>
      <input type="text" id="spek" name="spek" value="<?= e((string)$f['spek']) ?>" placeholder="cth. Bibit sehat, ukuran 3–5 cm, siap tebar">
    </div>
    <div class="field">
      <label for="satuan">Satuan <span class="req">*</span></label>
      <input type="text" id="satuan" name="satuan" list="satuan-list" value="<?= e((string)$f['satuan']) ?>" required>
      <datalist id="satuan-list">
        <?php foreach (SATUAN_UMUM as $s): ?><option value="<?= e($s) ?>"><?php endforeach; ?>
      </datalist>
    </div>
    <div class="field">
      <label for="jumlah">Jumlah / Volume <span class="req">*</span></label>
      <input type="text" id="jumlah" name="jumlah" inputmode="decimal" value="<?= fmt_angka($f['jumlah']) ?>" placeholder="cth. 100000" required>
      <span class="form-note">Angka tanpa titik/koma (pecahan pakai koma, cth. 12,5).</span>
    </div>
    <div class="field full">
      <button type="submit" class="btn btn-primary"><?= $isEdit ? icon('edit', 16) . ' Simpan Perubahan' : icon('plus', 16) . ' Simpan Barang' ?></button>
    </div>
  </form>
</div>
<?php endif; ?>

<div class="admin-card">
  <div class="admin-tools">
    <h3 style="margin-bottom:0;"><?= icon('list', 18) ?> Daftar Barang & Hasil Survei</h3>
    <?php if ($aksi !== 'tambah' && $editItem === null): ?>
      <a class="btn btn-primary" href="item.php?paket_id=<?= (int)$paketId ?>&aksi=tambah"><?= icon('plus', 16) ?> Tambah Barang</a>
    <?php endif; ?>
  </div>

  <?php if (!$items): ?>
    <div class="alert alert-info"><?= icon('search', 20) ?> <span>Belum ada barang. Klik "Tambah Barang" untuk mengisi daftar barang/jasa yang akan disurvei pada paket ini.</span></div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="tbl">
      <thead>
        <tr>
          <th>No</th>
          <th>Uraian</th>
          <th class="num">Jumlah</th>
          <th class="num">Sumber</th>
          <th class="num">Rata-rata Harga</th>
          <th class="num">Rentang Harga</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $no = 0; foreach ($items as $it): $no++;
            $stats = $it['stats'];
            $belum = $stats['jml'] === 0;
        ?>
        <tr>
          <td><?= $no ?></td>
          <td>
            <strong><?= e($it['uraian']) ?></strong>
            <?php if ($it['spek'] !== ''): ?><br><span class="muted small"><?= e($it['spek']) ?></span><?php endif; ?>
            <br><span class="muted small"><?= icon('tag', 12) ?> <?= e($it['satuan']) ?> ·
              <?= $belum ? '<span class="status-pill baru">belum ada survei</span>' : icon('store', 12) . ' ' . $stats['jml'] . ' sumber' ?></span>
          </td>
          <td class="num"><?= fmt_angka($it['jumlah']) ?></td>
          <td class="num"><?= $belum ? '—' : $stats['jml'] ?></td>
          <td class="num money"><?= $belum ? '—' : rp_angka($stats['avg']) ?></td>
          <td class="num"><?= $belum ? '—' : rp_angka($stats['min']) . ' – ' . rp_angka($stats['max']) ?></td>
          <td>
            <div class="row-actions">
              <a href="survei.php?item_id=<?= (int)$it['id'] ?>" title="Input Data Survei Harga" class="<?= $belum ? '' : 'has-survei' ?>"><?= icon('store', 15) ?></a>
              <a href="item.php?paket_id=<?= (int)$paketId ?>&aksi=edit&id=<?= (int)$it['id'] ?>" title="Edit"><?= icon('edit', 15) ?></a>
              <a class="del" href="item.php?paket_id=<?= (int)$paketId ?>&aksi=hapus&id=<?= (int)$it['id'] ?>&csrf=<?= urlencode(csrf_token()) ?>"
                 title="Hapus" onclick="return confirm('Hapus barang ini beserta data surveinya?')"><?= icon('trash', 15) ?></a>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <p class="form-note mt-16">Rata-rata dan rentang harga dihitung dari seluruh data survei yang dimasukkan untuk barang tersebut.</p>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/_footer.php'; ?>
