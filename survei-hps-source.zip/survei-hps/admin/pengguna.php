<?php
// ============================================================
// Admin — Kelola Pengguna (operator per bidang & administrator)
// Khusus untuk akun dengan peran 'admin'.
// ============================================================
$pageTitle = 'Kelola Pengguna';
$activeAdmin = 'pengguna';
require_once __DIR__ . '/_header.php'; // session + auth + buffer output
require_once __DIR__ . '/../lib/db.php';

$pdo = db();
require_admin();

$aksi = (string)get('aksi', 'list');
$id   = (int)get('id', 0);
$formErr = '';
$old = null;

// ---------- Hapus ----------
if ($aksi === 'hapus') {
    csrf_check_q();
    $st = $pdo->prepare('SELECT username, role FROM admin WHERE id = ?');
    $st->execute([$id]);
    $u = $st->fetch();
    if (!$u) {
        flash('Pengguna tidak ditemukan.', 'error');
    } elseif ((int)$id === (int)$_SESSION['admin_id']) {
        flash('Tidak dapat menghapus akun yang sedang digunakan.', 'error');
    } elseif ($u['username'] === 'admin') {
        flash('Akun administrator utama tidak dapat dihapus.', 'error');
    } else {
        $pdo->prepare('DELETE FROM admin WHERE id = ?')->execute([$id]);
        flash('Pengguna "' . e($u['username']) . '" telah dihapus.');
    }
    redirect('pengguna.php');
}

// ---------- Simpan (tambah / edit) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $username = strtolower(trim((string)post('username')));
    $nama     = trim((string)post('nama'));
    $password = (string)post('password');
    $role     = (string)post('role', 'operator');
    $bidang   = trim((string)post('bidang'));
    $id       = (int)post('id', 0);

    $err = [];
    if (!preg_match('/^[a-z0-9._]{3,32}$/', $username)) {
        $err[] = 'Username 3–32 karakter, hanya huruf kecil, angka, titik, atau garis bawah.';
    }
    if ($nama === '') $err[] = 'Nama lengkap wajib diisi.';
    if (!in_array($role, ['admin', 'operator'], true)) $err[] = 'Peran tidak valid.';
    if ($role === 'operator' && !in_array($bidang, BIDANG, true)) {
        $err[] = 'Bidang wajib dipilih untuk operator.';
    }
    if ($role === 'admin') $bidang = '';
    if ($password !== '' && u8len($password) < 8) {
        $err[] = 'Password minimal 8 karakter.';
    }

    // Username unik (kecuali dirinya sendiri)
    $st = $pdo->prepare('SELECT id FROM admin WHERE username = ?');
    $st->execute([$username]);
    $dup = $st->fetchColumn();
    if ($dup && (int)$dup !== $id) $err[] = 'Username "' . e($username) . '" sudah dipakai.';

    if ($err) {
        $formErr = implode(' ', $err);
        $old = ['id' => $id, 'username' => $username, 'nama' => $nama, 'role' => $role, 'bidang' => $bidang];
    } else {
        if ($id > 0) {
            // Edit: cegah mengubah peran akun sendiri (menghindari admin terkunci).
            $st = $pdo->prepare('SELECT role, username FROM admin WHERE id = ?');
            $st->execute([$id]);
            $lama = $st->fetch();
            if (!$lama) {
                $err[] = 'Pengguna tidak ditemukan.';
            } elseif ((int)$id === (int)$_SESSION['admin_id'] && $role !== $lama['role']) {
                $err[] = 'Tidak dapat mengubah peran akun sendiri.';
            } else {
                if ($password !== '') {
                    $st = $pdo->prepare('UPDATE admin SET username = ?, nama = ?, password = ?, role = ?, bidang = ? WHERE id = ?');
                    $st->execute([$username, $nama, password_hash($password, PASSWORD_DEFAULT), $role, $bidang, $id]);
                } else {
                    $st = $pdo->prepare('UPDATE admin SET username = ?, nama = ?, role = ?, bidang = ? WHERE id = ?');
                    $st->execute([$username, $nama, $role, $bidang, $id]);
                }
                flash('Pengguna "' . e($username) . '" berhasil diperbarui.');
            }
        } else {
            if ($password === '') {
                $err[] = 'Password wajib diisi untuk pengguna baru (min. 8 karakter).';
            } else {
                $st = $pdo->prepare('INSERT INTO admin (username, password, nama, role, bidang) VALUES (?, ?, ?, ?, ?)');
                $st->execute([$username, password_hash($password, PASSWORD_DEFAULT), $nama, $role, $bidang]);
                flash('Pengguna "' . e($username) . '" berhasil ditambahkan.');
            }
        }
        if ($err) {
            $formErr = implode(' ', $err);
            $old = ['id' => $id, 'username' => $username, 'nama' => $nama, 'role' => $role, 'bidang' => $bidang];
        } else {
            redirect('pengguna.php');
        }
    }
}

// ---------- Siapkan data form ----------
$editUser = null;
if (isset($old)) {
    $editUser = $old;
} elseif ($aksi === 'edit' && $id > 0) {
    $st = $pdo->prepare('SELECT * FROM admin WHERE id = ?');
    $st->execute([$id]);
    $editUser = $st->fetch();
    if (!$editUser) redirect('pengguna.php');
}

// ---------- Daftar pengguna ----------
$rows = $pdo->query('SELECT * FROM admin ORDER BY id ASC')->fetchAll();

// ================= FORM TAMBAH / EDIT =================
if ($aksi === 'tambah' || $editUser !== null):
    $isEdit = $aksi === 'edit' || (int)($editUser['id'] ?? 0) > 0;
    $f = $editUser !== null ? $editUser : ['id' => 0, 'username' => '', 'nama' => '', 'role' => 'operator', 'bidang' => ''];
?>
<div class="admin-card">
  <div class="admin-tools" style="margin-bottom:6px;">
    <h3 style="margin-bottom:0;"><?= $isEdit ? icon('edit', 17) . ' Edit Pengguna' : icon('plus', 17) . ' Tambah Pengguna Baru' ?></h3>
    <a class="btn btn-outline-navy btn-sm" href="pengguna.php">← Kembali ke Daftar</a>
  </div>
  <?php if ($formErr !== ''): ?>
    <div class="alert alert-error"><?= icon('alert', 20) ?> <span><?= e($formErr) ?></span></div>
  <?php endif; ?>
  <form method="post" action="pengguna.php" class="form-grid">
    <input type="hidden" name="id" value="<?= (int)$f['id'] ?>">
    <?= csrf_field() ?>
    <div class="field">
      <label for="username">Username <span class="req">*</span></label>
      <input type="text" id="username" name="username" value="<?= e((string)$f['username']) ?>" placeholder="cth. operator_tangkap" required>
      <span class="form-note">Huruf kecil, angka, titik, garis bawah.</span>
    </div>
    <div class="field">
      <label for="nama">Nama Lengkap <span class="req">*</span></label>
      <input type="text" id="nama" name="nama" value="<?= e((string)$f['nama']) ?>" placeholder="cth. Andi Pratama" required>
    </div>
    <div class="field">
      <label for="password">Password <?= $isEdit ? '(kosongkan bila tetap)' : '<span class="req">*</span>' ?></label>
      <input type="password" id="password" name="password" <?= $isEdit ? '' : 'required' ?> minlength="8" autocomplete="new-password" placeholder="Min. 8 karakter">
    </div>
    <div class="field">
      <label for="role">Peran</label>
      <select id="role" name="role" onchange="toggleBidang(this.value)">
        <option value="operator" <?= $f['role'] === 'operator' ? 'selected' : '' ?>>Operator Bidang</option>
        <option value="admin" <?= $f['role'] === 'admin' ? 'selected' : '' ?>>Administrator</option>
      </select>
    </div>
    <div class="field full" id="field-bidang">
      <label for="bidang">Bidang (untuk operator) <span class="req">*</span></label>
      <select id="bidang" name="bidang">
        <option value="">— Pilih Bidang —</option>
        <?php foreach (BIDANG as $b): ?>
          <option value="<?= e($b) ?>" <?= ($f['bidang'] ?? '') === $b ? 'selected' : '' ?>><?= e($b) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="field full">
      <button type="submit" class="btn btn-primary"><?= $isEdit ? icon('edit', 16) . ' Simpan Perubahan' : icon('plus', 16) . ' Simpan Pengguna' ?></button>
    </div>
  </form>
</div>
<script>
function toggleBidang(role) {
  var el = document.getElementById('field-bidang');
  if (el) el.style.display = role === 'admin' ? 'none' : '';
}
</script>

<?php else:
// ================= DAFTAR PENGGUNA =================
?>
<div class="admin-card">
  <div class="admin-tools">
    <h3 style="margin-bottom:0;"><?= icon('users', 18) ?> Daftar Pengguna</h3>
    <a class="btn btn-primary" href="pengguna.php?aksi=tambah"><?= icon('plus', 16) ?> Tambah Pengguna</a>
  </div>

  <?php if (!$rows): ?>
    <div class="alert alert-info"><?= icon('search', 20) ?> <span>Belum ada pengguna.</span></div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="tbl">
      <thead>
        <tr>
          <th>Username</th>
          <th>Nama Lengkap</th>
          <th>Peran</th>
          <th>Bidang</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $u): ?>
        <tr>
          <td><strong><?= e($u['username']) ?></strong>
            <?php if ((int)$u['id'] === (int)$_SESSION['admin_id']): ?> <span class="badge badge-bidang">Anda</span><?php endif; ?>
          </td>
          <td><?= e($u['nama']) ?></td>
          <td><?= $u['role'] === 'admin'
                  ? '<span class="status-pill kontrak">Administrator</span>'
                  : '<span class="status-pill pemilihan">Operator</span>' ?></td>
          <td><?= e($u['bidang'] ?: '—') ?></td>
          <td>
            <div class="row-actions">
              <a href="pengguna.php?aksi=edit&id=<?= (int)$u['id'] ?>" title="Edit"><?= icon('edit', 15) ?></a>
              <?php if ((int)$u['id'] !== (int)$_SESSION['admin_id'] && $u['username'] !== 'admin'): ?>
              <a class="del" href="pengguna.php?aksi=hapus&id=<?= (int)$u['id'] ?>&csrf=<?= urlencode(csrf_token()) ?>"
                 title="Hapus" onclick="return confirm('Hapus pengguna ini?')"><?= icon('trash', 15) ?></a>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <p class="form-note mt-16">Operator hanya dapat melihat &amp; mengelola paket pada bidangnya sendiri. Administrator dapat melihat seluruh paket dan mengelola pengguna.</p>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php require __DIR__ . '/_footer.php'; ?>
