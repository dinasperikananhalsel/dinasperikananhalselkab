<?php
// Header bersama halaman admin (dengan sidebar).
ob_start(); // buffer output agar redirect() yang dipanggil setelah render tetap bisa mengirim header
session_start();
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/icons.php';
require_once __DIR__ . '/../lib/db.php';
require_auth();

$activeAdmin = $activeAdmin ?? '';
$pageTitle = $pageTitle ?? 'Dashboard';
$adminNama = $_SESSION['admin_nama'] ?? 'Administrator';
$adminUser = $_SESSION['admin_user'] ?? 'admin';
$inisial = inisial($adminNama);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex">
<title><?= e($pageTitle) ?> — Admin Survei Harga</title>
<link rel="icon" type="image/png" href="../assets/img/favicon-64.png">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin-body">
<div class="admin-shell">

  <aside class="admin-side">
    <div class="side-brand">
      <img src="../assets/img/logo-daerah.png" alt="Lambang Kabupaten Halmahera Selatan">
      <div><strong>Admin Survei Harga</strong><small>Dinas Perikanan Halsel</small></div>
    </div>
    <nav>
      <a class="<?= $activeAdmin === 'dashboard' ? 'active' : '' ?>" href="index.php"><?= icon('building', 18) ?> Dashboard</a>
      <a class="<?= $activeAdmin === 'paket' ? 'active' : '' ?>" href="paket.php"><?= icon('file-text', 18) ?> Paket Pengadaan</a>
      <?php if (is_admin()): ?>
      <a class="<?= $activeAdmin === 'pengguna' ? 'active' : '' ?>" href="pengguna.php"><?= icon('users', 18) ?> Kelola Pengguna</a>
      <?php endif; ?>
      <a class="<?= $activeAdmin === 'password' ? 'active' : '' ?>" href="password.php"><?= icon('shield', 18) ?> Ganti Password</a>
    </nav>
    <div class="side-foot">
      Login sebagai <strong style="color:#fff;"><?= e($adminUser) ?></strong>
      <br><span style="color:var(--gold);"><?= is_admin() ? 'Administrator' : e(user_bidang() ?: 'Operator') ?></span>
      <br><a href="logout.php" style="color:#c7d7e8;">Keluar</a>
    </div>
  </aside>

  <div class="admin-main">
    <div class="admin-topbar">
      <h2><?= e($pageTitle) ?></h2>
      <div class="who">
        <span><?= e($adminNama) ?></span>
        <span class="avatar"><?= e($inisial) ?></span>
      </div>
    </div>
    <div class="admin-content">
      <?= flash_out() ?>
