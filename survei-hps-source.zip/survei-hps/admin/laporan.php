<?php
// ============================================================
// Rekap Hasil Survei Harga Barang — tampilan cetak (print/PDF)
// ============================================================
ob_start();
session_start();
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/icons.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/survei.php';
require_auth();

$pdo = db();
$paketId = (int)get('paket_id', 0);

[$paket, $items, , ] = paket_items($pdo, $paketId);
if (!$paket) {
    flash('Paket tidak ditemukan.', 'error');
    redirect('paket.php');
}
// Lingkup: operator hanya boleh mencetak dokumen bidangnya sendiri
if (!is_admin() && $paket['bidang'] !== user_bidang()) {
    flash('Anda hanya dapat mengakses paket pada bidang Anda.', 'error');
    redirect('paket.php');
}

// Rekap sumber survei dikelompokkan per item
$survByItem = [];
foreach (paket_survei_rows($pdo, $paketId) as $r) {
    $survByItem[(int)$r['item_id']][] = $r;
}

$tanggalDok = $paket['tanggal'] ?: date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex">
<title>Rekap Survei Harga — <?= e($paket['nama']) ?></title>
<link rel="icon" type="image/png" href="../assets/img/favicon-64.png">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="doc-body">

<div class="no-print doc-toolbar">
  <div class="doc-toolbar-left">
    <a href="berita-acara.php?paket_id=<?= (int)$paketId ?>" class="btn btn-gold btn-sm"><?= icon('file-text', 15) ?> Cetak Berita Acara</a>
    <a href="item.php?paket_id=<?= (int)$paketId ?>" class="btn btn-outline-navy btn-sm"><?= icon('chevron-left', 15) ?> Barang &amp; Survei</a>
    <a href="paket.php" class="btn btn-outline-navy btn-sm"><?= icon('list', 15) ?> Daftar Paket</a>
  </div>
  <button onclick="window.print()" class="btn btn-gold btn-sm"><?= icon('printer', 16) ?> Cetak / Simpan PDF</button>
</div>

<div class="doc-doc">
  <!-- ======= KOP ======= -->
  <div class="doc-kop">
    <img src="../assets/img/logo-daerah.png" alt="Lambang Daerah" class="doc-logo">
    <div class="doc-kop-text">
      <div class="doc-wilayah">PEMERINTAH KABUPATEN HALMAHERA SELATAN</div>
      <div class="doc-instansi">DINAS PERIKANAN</div>
      <div class="doc-alamat"><?= e(ALAMAT_KANTOR) ?> — Telepon: <?= e(TELEPON) ?> — Email: <?= e(EMAIL_DINAS) ?></div>
    </div>
  </div>
  <hr class="doc-kop-line">

  <!-- ======= JUDUL ======= -->
  <div class="doc-title">REKAPITULASI HASIL SURVEI HARGA BARANG</div>
  <div class="doc-subtitle">PENGADAAN BARANG / JASA</div>

  <!-- ======= INFO PAKET ======= -->
  <table class="doc-info">
    <tr>
      <td class="k">Nama Paket</td>
      <td class="v">: <?= e($paket['nama']) ?></td>
      <td class="k">Nomor Dokumen</td>
      <td class="v">: <?= e($paket['nomor'] ?: '—') ?></td>
    </tr>
    <tr>
      <td class="k">Satuan Kerja</td>
      <td class="v">: <?= e(INSTANSI) ?></td>
      <td class="k">Tanggal</td>
      <td class="v">: <?= tanggal_id($tanggalDok) ?></td>
    </tr>
    <tr>
      <td class="k">Tahun Anggaran</td>
      <td class="v">: <?= (int)$paket['tahun'] ?></td>
      <td class="k">Sumber Dana</td>
      <td class="v">: <?= e($paket['sumber_dana'] ?: '—') ?></td>
    </tr>
    <tr>
      <td class="k">Bidang</td>
      <td class="v">: <?= e($paket['bidang'] ?: '—') ?></td>
      <td class="k">Pejabat Pembuat Komitmen</td>
      <td class="v">: <?= e($paket['ppk'] ?: '—') ?></td>
    </tr>
    <?php if ($paket['keterangan'] !== ''): ?>
    <tr>
      <td class="k">Keterangan</td>
      <td class="v" colspan="3">: <?= e($paket['keterangan']) ?></td>
    </tr>
    <?php endif; ?>
  </table>

  <!-- ======= RINGKASAN ======= -->
  <table class="doc-tbl">
    <thead>
      <tr>
        <th class="c" style="width:34px;">No</th>
        <th>Uraian / Spesifikasi</th>
        <th class="c" style="width:70px;">Satuan</th>
        <th class="c" style="width:80px;">Volume</th>
        <th class="c" style="width:70px;">Sumber</th>
        <th class="r" style="width:115px;">Harga Terendah (Rp)</th>
        <th class="r" style="width:115px;">Harga Tertinggi (Rp)</th>
        <th class="r" style="width:115px;">Rata-rata (Rp)</th>
      </tr>
    </thead>
    <tbody>
      <?php $no = 0; foreach ($items as $it): $no++;
          $stats = $it['stats'];
          $belum = $stats['jml'] === 0;
      ?>
      <tr>
        <td class="c"><?= $no ?></td>
        <td class="l">
          <strong><?= e($it['uraian']) ?></strong>
          <?php if ($it['spek'] !== ''): ?><br><span class="spek"><?= e($it['spek']) ?></span><?php endif; ?>
          <?php if ($belum): ?> <span class="spek">(belum ada data survei)</span><?php endif; ?>
        </td>
        <td class="c"><?= e($it['satuan']) ?></td>
        <td class="c"><?= fmt_angka($it['jumlah']) ?></td>
        <td class="c"><?= $belum ? '—' : $stats['jml'] ?></td>
        <td class="r"><?= $belum ? '—' : number_format((float)$stats['min'], 0, ',', '.') ?></td>
        <td class="r"><?= $belum ? '—' : number_format((float)$stats['max'], 0, ',', '.') ?></td>
        <td class="r"><?= $belum ? '—' : fmt_angka($stats['avg']) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- ======= TANDA TANGAN ======= -->
  <div class="doc-ttd">
    <div class="doc-ttd-right"><?= e(KODE_WILAYAH) ?>, <?= tanggal_id($tanggalDok) ?></div>
    <div class="doc-ttd-grid">
      <div class="doc-ttd-block">
        <p>Mengetahui,<br>Pejabat Pembuat Komitmen</p>
        <div class="doc-ttd-space"></div>
        <p class="doc-ttd-name"><strong><?= e($paket['ppk'] ?: '……………………………………') ?></strong></p>
        <p>NIP. <?= e($paket['ppk_nip'] ?: '…………………………') ?></p>
      </div>
      <div class="doc-ttd-block">
        <p>Dibuat oleh,<br>Pelaksana Survei Harga</p>
        <div class="doc-ttd-space"></div>
        <p class="doc-ttd-name"><strong>……………………………………</strong></p>
        <p>…………………………</p>
      </div>
    </div>
  </div>

  <!-- ======= RINCIAN SUMBER SURVEI (halaman baru saat cetak) ======= -->
  <div class="page-break"></div>
  <div class="doc-title doc-title-sm">RINCIAN SUMBER SURVEI HARGA</div>
  <p class="doc-note">Daftar sumber survei yang digunakan untuk setiap barang pada paket di atas.</p>

  <?php if ($items): ?>
    <?php $noItem = 0; foreach ($items as $it): $noItem++;
        $stats = $it['stats'];
        $list = $survByItem[(int)$it['id']] ?? [];
        if (!$list) continue;
    ?>
    <table class="doc-tbl doc-surv">
      <thead>
        <tr>
          <th colspan="6" class="l surv-item">
            <?= $noItem ?>. <?= e($it['uraian']) ?>
            <span class="spek"> — <?= e($it['satuan']) ?>, volume <?= fmt_angka($it['jumlah']) ?></span>
          </th>
        </tr>
        <tr>
          <th class="c" style="width:34px;">No</th>
          <th>Sumber Survei</th>
          <th class="c" style="width:120px;">Kontak</th>
          <th class="c" style="width:100px;">Tanggal</th>
          <th class="r" style="width:130px;">Harga Satuan (Rp)</th>
          <th>Keterangan</th>
        </tr>
      </thead>
      <tbody>
        <?php $noS = 0; foreach ($list as $s): $noS++; ?>
        <tr>
          <td class="c"><?= $noS ?></td>
          <td class="l"><?= e($s['sumber']) ?></td>
          <td class="c"><?= e($s['telepon'] ?: '—') ?></td>
          <td class="c"><?= tanggal_id($s['tanggal']) ?></td>
          <td class="r"><?= number_format((float)$s['harga'], 0, ',', '.') ?></td>
          <td class="l small"><?= e($s['keterangan'] ?: '—') ?></td>
        </tr>
        <?php endforeach; ?>
        <tr class="surv-avg">
          <td class="c" colspan="4">Rata-rata harga survei</td>
          <td class="r"><strong><?= fmt_angka($stats['avg']) ?></strong></td>
          <td class="l small">Rentang: <?= number_format((float)$stats['min'], 0, ',', '.') ?> – <?= number_format((float)$stats['max'], 0, ',', '.') ?></td>
        </tr>
      </tbody>
    </table>
    <?php endforeach; ?>
  <?php else: ?>
    <p class="doc-note">Belum ada data survei.</p>
  <?php endif; ?>

  <p class="doc-note mt-16">Dokumen ini dibuat secara otomatis melalui Aplikasi Survei Harga Barang Dinas Perikanan Kabupaten Halmahera Selatan. Hasil survei dapat digunakan sebagai bahan penyusunan harga pengadaan.</p>
</div>

</body>
</html>
