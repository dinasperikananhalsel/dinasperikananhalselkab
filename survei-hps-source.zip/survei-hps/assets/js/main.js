// ============================================================
// JS umum — menu mobile + konfirmasi hapus (via data-confirm)
// ============================================================
(function () {
  // Menu mobile
  var toggle = document.querySelector('.nav-toggle');
  var links = document.getElementById('navLinks');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      links.classList.toggle('open');
    });
  }
})();
