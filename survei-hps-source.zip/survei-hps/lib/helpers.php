<?php
// ============================================================================
// Fungsi bantu umum — Aplikasi Survei Harga Barang
// ============================================================================

/** Escape output HTML dengan aman. */
function e(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

/** Redirect lalu hentikan eksekusi. Membuang buffer output agar header Location selalu berfungsi. */
function redirect(string $url): never
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Location: ' . $url);
    exit;
}

/** Ambil nilai $_GET dengan default. */
function get(string $key, $default = null)
{
    return $_GET[$key] ?? $default;
}

/** Ambil nilai $_POST dengan default. */
function post(string $key, $default = null)
{
    return $_POST[$key] ?? $default;
}

/** Set pesan flash (session). */
function flash(string $msg, string $type = 'success'): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

/** Tampilkan & hapus pesan flash. */
function flash_out(): string
{
    if (empty($_SESSION['flash'])) return '';
    $f = $_SESSION['flash'];
    unset($_SESSION['flash']);
    $icon = $f['type'] === 'error' ? 'alert' : 'check-circle';
    return '<div class="alert alert-' . e($f['type']) . '">'
         . icon($icon, 20)
         . '<span>' . e($f['msg']) . '</span></div>';
}

/** Token CSRF untuk form admin. */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}

function csrf_check(): void
{
    $sent = $_POST['csrf'] ?? '';
    if (!is_string($sent) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $sent)) {
        http_response_code(419);
        exit('Sesi kedaluwarsa. Silakan muat ulang halaman dan coba lagi.');
    }
}

function csrf_check_q(): void
{
    $sent = $_GET['csrf'] ?? '';
    if (!is_string($sent) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $sent)) {
        http_response_code(419);
        exit('Sesi kedaluwarsa. Silakan muat ulang halaman dan coba lagi.');
    }
}

/** Status login admin. */
function is_auth(): bool
{
    return !empty($_SESSION['admin_id']);
}

function require_auth(): void
{
    if (!is_auth()) redirect('login.php');
}

/** Role pengguna yang login: 'admin' atau 'operator'. */
function user_role(): string
{
    return $_SESSION['admin_role'] ?? 'operator';
}

/** Bidang operator yang login ('' untuk admin / belum ditentukan). */
function user_bidang(): string
{
    return $_SESSION['admin_bidang'] ?? '';
}

/** True jika pengguna adalah administrator. */
function is_admin(): bool
{
    return user_role() === 'admin';
}

/** Wajib administrator (untuk halaman kelola pengguna). */
function require_admin(): void
{
    if (!is_admin()) {
        flash('Anda tidak memiliki hak akses ke halaman tersebut.', 'error');
        redirect('index.php');
    }
}

/**
 * Filter lingkup paket: admin melihat semua; operator hanya bidangnya sendiri.
 * Mengembalikan [sqlWhere, params] untuk dipakai pada query paket.
 */
function scope_where(): array
{
    if (is_admin()) return ['', []];
    return ['bidang = ?', [user_bidang()]];
}

/** Panjang string UTF-8 (tanpa mbstring). */
function u8len(string $s): int
{
    return preg_match_all('/./us', $s, $m);
}

/** Substring UTF-8 (tanpa mbstring). */
function u8sub(string $s, int $start, int $len = 0): string
{
    preg_match_all('/./us', $s, $m);
    return implode('', array_slice($m[0], $start, $len === 0 ? null : $len));
}

/** Karakter pertama UTF-8. */
function u8first(string $s): string
{
    preg_match('/./us', $s, $m);
    return $m[0] ?? '';
}

/** Potong teks tanpa merusak kata. */
function potong(string $s, int $max = 120): string
{
    $s = trim(preg_replace('/\s+/u', ' ', strip_tags($s)));
    if (u8len($s) <= $max) return $s;
    $cut = u8sub($s, 0, $max);
    $pos = strrpos($cut, ' ');
    if ($pos > 0) $cut = u8sub($cut, 0, $pos);
    return $cut . '…';
}

/** Format angka ribuan gaya Indonesia (1.234.567). */
function angka($n): string
{
    return number_format((float)$n, 0, ',', '.');
}

/** Format rupiah: Rp 1.234.567.890 */
function rp($n): string
{
    if ($n === null || $n === '') return '—';
    return 'Rp ' . number_format((float)$n, 0, ',', '.');
}

/**
 * Format angka: bilangan bulat tanpa desimal, selain itu 2 desimal.
 * Dipakai untuk jumlah/volume dan rata-rata harga survei.
 */
function fmt_angka($n): string
{
    if ($n === null || $n === '') return '—';
    $v = (float)$n;
    return number_format($v, ($v == floor($v)) ? 0 : 2, ',', '.');
}

/** Format rupiah untuk nilai survei (ikut fmt_angka). */
function rp_angka($n): string
{
    if ($n === null || $n === '') return '—';
    return 'Rp ' . fmt_angka($n);
}

/** Format tanggal YYYY-MM-DD -> "12 Februari 2025". */
function tanggal_id(?string $dt): string
{
    if (!$dt) return '—';
    $ts = strtotime($dt);
    if ($ts === false) return e($dt);
    $bulan = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
              'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    return date('j', $ts) . ' ' . $bulan[(int)date('n', $ts)] . ' ' . date('Y', $ts);
}

/** Inisial nama untuk avatar admin. */
function inisial(string $nama): string
{
    $trim = trim($nama);
    if ($trim === '') return 'A';
    return strtoupper(u8first($trim));
}

/** Bersihkan input angka agar aman untuk penyimpanan. */
function angka_post(string $key): ?float
{
    $v = trim((string)post($key));
    if ($v === '') return null;
    $v = str_replace(['.', ' '], '', $v); // hapus pemisah ribuan
    $v = str_replace(',', '.', $v);       // koma desimal -> titik
    if (!is_numeric($v)) return null;
    return (float)$v;
}

/** Ukuran maksimum foto survei (2 MB). */
const FOTO_SURVEI_MAX = 2 * 1024 * 1024;

/**
 * Baca & validasi unggahan foto survei barang.
 * Mengembalikan isi biner gambar ('' jika tidak ada file diunggah).
 * Foto disimpan sebagai BLOB di database (platform tidak melayani file runtime).
 */
function baca_foto_upload(array $file, &$err): string
{
    $file += ['error' => UPLOAD_ERR_NO_FILE, 'size' => 0, 'tmp_name' => ''];
    if ((int)$file['error'] === UPLOAD_ERR_NO_FILE) return '';
    if ((int)$file['error'] !== UPLOAD_ERR_OK) {
        $err = 'Gagal mengunggah foto (kode ' . (int)$file['error'] . ').';
        return '';
    }
    if ((int)$file['size'] > FOTO_SURVEI_MAX) { $err = 'Ukuran foto maksimal 2 MB.'; return ''; }
    $tmp = $file['tmp_name'] ?? '';
    if ($tmp === '' || !is_uploaded_file($tmp)) { $err = 'File foto tidak valid.'; return ''; }
    $info = @getimagesize($tmp);
    if ($info === false) { $err = 'File harus berupa gambar (JPG/PNG/WebP/GIF).'; return ''; }
    $extMap = ['image/jpeg' => true, 'image/png' => true, 'image/webp' => true, 'image/gif' => true];
    if (!isset($extMap[$info['mime']])) { $err = 'Format gambar tidak didukung (JPG/PNG/WebP/GIF).'; return ''; }
    $isi = file_get_contents($tmp);
    if ($isi === false || $isi === '') { $err = 'Gagal membaca foto.'; return ''; }
    return $isi;
}
