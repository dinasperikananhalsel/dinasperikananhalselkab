<?php
// ============================================================================
// Koneksi database SQLite + skema + data awal (idempoten)
// Database disimpan di data.sqlite di folder aplikasi.
// ============================================================================

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        // Hook tes: boleh ditimpa lewat env (mis. salinan DB di /tmp saat development).
        $file = getenv('SURVEI_DB') ?: __DIR__ . '/../data.sqlite';
        $pdo = new PDO('sqlite:' . $file, null, null, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $pdo->exec('PRAGMA journal_mode = WAL');
        $pdo->exec('PRAGMA busy_timeout = 5000');
        migrate($pdo);
    }
    return $pdo;
}

function migrate(PDO $pdo): void
{
    // Migrasi skema kecil di luar transaksi (SQLite membatasi sebagian ALTER TABLE
    // di dalam transaksi): hapus kolom toleransi — fitur HPS dihapus.
    // Aman untuk DB baru: PRAGMA pada tabel yang belum ada hanya mengembalikan kosong.
    $cols = $pdo->query('PRAGMA table_info(paket)')->fetchAll(PDO::FETCH_ASSOC);
    $hasTol = false;
    foreach ($cols as $c) {
        if (($c['name'] ?? '') === 'toleransi') { $hasTol = true; break; }
    }
    if ($hasTol) {
        try {
            $pdo->exec('ALTER TABLE paket DROP COLUMN toleransi');
        } catch (Throwable $e) {
            // Kolom tidak terhapus (versi SQLite lama) — kode tidak lagi memakainya.
        }
    }

    $pdo->exec('BEGIN');

    $pdo->exec("CREATE TABLE IF NOT EXISTS admin (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        nama TEXT NOT NULL DEFAULT 'Administrator',
        role TEXT NOT NULL DEFAULT 'operator',
        bidang TEXT NOT NULL DEFAULT ''
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS paket (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        tahun INTEGER NOT NULL,
        bidang TEXT NOT NULL DEFAULT '',
        nomor TEXT NOT NULL DEFAULT '',
        tanggal TEXT,
        sumber_dana TEXT NOT NULL DEFAULT 'APBD',
        ppk TEXT NOT NULL DEFAULT '',
        ppk_nip TEXT NOT NULL DEFAULT '',
        keterangan TEXT NOT NULL DEFAULT '',
        ba_nomor TEXT NOT NULL DEFAULT '',
        ba_tanggal TEXT,
        ba_tim TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS item (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        paket_id INTEGER NOT NULL,
        uraian TEXT NOT NULL,
        spek TEXT NOT NULL DEFAULT '',
        satuan TEXT NOT NULL DEFAULT 'unit',
        jumlah REAL NOT NULL DEFAULT 1,
        urutan INTEGER NOT NULL DEFAULT 0
    )");
    $pdo->exec('CREATE INDEX IF NOT EXISTS idx_item_paket ON item(paket_id)');

    $pdo->exec("CREATE TABLE IF NOT EXISTS survei (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        item_id INTEGER NOT NULL,
        sumber TEXT NOT NULL,
        telepon TEXT NOT NULL DEFAULT '',
        tanggal TEXT,
        harga REAL NOT NULL,
        keterangan TEXT NOT NULL DEFAULT '',
        foto BLOB
    )");
    $pdo->exec('CREATE INDEX IF NOT EXISTS idx_survei_item ON survei(item_id)');

    // ---- Migrasi kolom (tabel sudah ada) — tambah jika belum ada, aman untuk DB lama ----
    $paketCols = [];
    foreach ($pdo->query('PRAGMA table_info(paket)')->fetchAll(PDO::FETCH_ASSOC) as $c) {
        $paketCols[$c['name']] = true;
    }
    foreach ([
        'ba_nomor'   => "ALTER TABLE paket ADD COLUMN ba_nomor TEXT NOT NULL DEFAULT ''",
        'ba_tanggal' => 'ALTER TABLE paket ADD COLUMN ba_tanggal TEXT',
        'ba_tim'     => "ALTER TABLE paket ADD COLUMN ba_tim TEXT NOT NULL DEFAULT ''",
        'bidang'     => "ALTER TABLE paket ADD COLUMN bidang TEXT NOT NULL DEFAULT ''",
    ] as $col => $sql) {
        if (!isset($paketCols[$col])) $pdo->exec($sql);
    }

    $adminCols = [];
    foreach ($pdo->query('PRAGMA table_info(admin)')->fetchAll(PDO::FETCH_ASSOC) as $c) {
        $adminCols[$c['name']] = true;
    }
    if (!isset($adminCols['role'])) {
        $pdo->exec("ALTER TABLE admin ADD COLUMN role TEXT NOT NULL DEFAULT 'operator'");
        // Akun bawaan (username 'admin') menjadi administrator.
        $pdo->exec("UPDATE admin SET role = 'admin' WHERE username = 'admin'");
    }
    if (!isset($adminCols['bidang'])) {
        $pdo->exec("ALTER TABLE admin ADD COLUMN bidang TEXT NOT NULL DEFAULT ''");
    }

    // Kolom foto barang per survei (BLOB) — tambah jika belum ada.
    $surveiCols = [];
    foreach ($pdo->query('PRAGMA table_info(survei)')->fetchAll(PDO::FETCH_ASSOC) as $c) {
        $surveiCols[$c['name']] = true;
    }
    if (!isset($surveiCols['foto'])) {
        $pdo->exec('ALTER TABLE survei ADD COLUMN foto BLOB');
    }

    // ---- Perbaikan data lama (idempoten) ----
    $pdo->exec("UPDATE admin SET nama = 'Administrator Survei Harga' WHERE nama = 'Administrator Survei HPS'");
    $pdo->exec("UPDATE paket SET keterangan = 'Contoh paket untuk memperagakan pencatatan survei harga barang. Ubah atau hapus sesuai kebutuhan.'
                WHERE keterangan LIKE '%memperagakan perhitungan HPS%'");

    // ---- Seed: hanya jika belum ada ----
    $adminCount = (int)$pdo->query('SELECT COUNT(*) FROM admin')->fetchColumn();
    if ($adminCount === 0) {
        $st = $pdo->prepare('INSERT INTO admin (username, password, nama, role, bidang) VALUES (?, ?, ?, ?, ?)');
        $st->execute(['admin', password_hash('admin123', PASSWORD_DEFAULT), 'Administrator Survei Harga', 'admin', '']);
    }

    $paketCount = (int)$pdo->query('SELECT COUNT(*) FROM paket')->fetchColumn();
    if ($paketCount === 0) seed_contoh($pdo);

    $pdo->exec('COMMIT');
}

/**
 * Seed contoh: 1 paket + 3 item + 9 baris survei (3 sumber per item).
 * Dijalankan hanya saat tabel paket kosong; setiap baris dicek namanya agar
 * tidak ganda bila proses seed berjalan ulang.
 */
function seed_contoh(PDO $pdo): void
{
    // ---- Paket contoh ----
    $paket = [
        'nama'        => 'Pengadaan Bibit Ikan Bandeng untuk Kelompok Pembudidaya',
        'tahun'       => 2025,
        'bidang'      => 'Bidang Perikanan Budidaya',
        'nomor'       => '600/' . date('Y') . '/DINASPERIKANAN',
        'tanggal'     => date('Y-m-d'),
        'sumber_dana' => 'APBD',
        'ppk'         => '',
        'ppk_nip'     => '',
        'keterangan'  => 'Contoh paket untuk memperagakan pencatatan survei harga barang. Ubah atau hapus sesuai kebutuhan.',
        'ba_nomor'    => '',
        'ba_tanggal'  => date('Y-m-d'),
        'ba_tim'      => "1. Nama Anggota Tim 1 — Staf Bidang Umum\n2. Nama Anggota Tim 2 — Staf Bidang Perikanan",
    ];
    $st = $pdo->prepare('SELECT COUNT(*) FROM paket WHERE nama = ?');
    $st->execute([$paket['nama']]);
    $paketId = null;
    if ((int)$st->fetchColumn() === 0) {
        $st = $pdo->prepare('INSERT INTO paket (nama, tahun, bidang, nomor, tanggal, sumber_dana, ppk, ppk_nip, keterangan, ba_nomor, ba_tanggal, ba_tim)
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $st->execute([$paket['nama'], $paket['tahun'], $paket['bidang'], $paket['nomor'], $paket['tanggal'],
                      $paket['sumber_dana'], $paket['ppk'], $paket['ppk_nip'], $paket['keterangan'],
                      $paket['ba_nomor'], $paket['ba_tanggal'], $paket['ba_tim']]);
        $paketId = (int)$pdo->lastInsertId();
    }

    if ($paketId === null) return;

    // ---- Item + survei ----
    $items = [
        [
            'uraian'  => 'Bibit ikan bandeng ukuran 3–5 cm',
            'spek'    => 'Bibit sehat, ukuran 3–5 cm, siap tebar, kadar garam diadaptasi',
            'satuan'  => 'ekor',
            'jumlah'  => 100000,
            'survei'  => [ // sumber, telepon, tanggal, harga, keterangan
                ['Toko Mina Jaya, Labuha',     '(0922) 21212', '2025-02-10', 300,  'Harga per ekor, minimal 10.000 ekor'],
                ['CV. Bahari Supply, Ternate', '(0921) 342121', '2025-02-11', 325,  'Termasuk ongkos kirim ke Labuha'],
                ['Penangkar Mandiri, Sofifi',  '(0921) 715345', '2025-02-12', 350,  ''],
            ],
        ],
        [
            'uraian'  => 'Pakan ikan (pelet) apung protein 28–30%',
            'spek'    => 'Kemasan 10 kg, pelet apung, kadar protein 28–30%, sertifikat SNI',
            'satuan'  => 'sak',
            'jumlah'  => 60,
            'survei'  => [
                ['UD. Nelayan Mandiri, Bacan',   '(0922) 331010', '2025-02-10', 168000, 'Harga per sak 10 kg'],
                ['Toko Pakan Sentosa, Ternate',  '(0921) 221122', '2025-02-11', 172000, ''],
                ['PT. Sinar Pangan, Jakarta',    '(021) 5551234', '2025-02-12', 175000, 'Penawaran via email, ekspedisi ditanggung pembeli'],
            ],
        ],
        [
            'uraian'  => 'Timbangan duduk kapasitas 50 kg',
            'spek'    => 'Timbangan duduk mekanik, kapasitas 50 kg, kelipatan 50 gram',
            'satuan'  => 'unit',
            'jumlah'  => 10,
            'survei'  => [
                ['Toko Timbangan Bahari, Ternate', '(0921) 213456', '2025-02-10', 285000, ''],
                ['Kios Mitra Tani, Labuha',        '(0922) 219988', '2025-02-11', 290000, ''],
                ['Bukalapak — Toko Alat Ukur',     '',             '2025-02-12', 275000, 'Harga online termasuk ongkir'],
            ],
        ],
    ];

    $stItem = $pdo->prepare('INSERT INTO item (paket_id, uraian, spek, satuan, jumlah, urutan)
                             VALUES (?, ?, ?, ?, ?, ?)');
    $stSurv = $pdo->prepare('INSERT INTO survei (item_id, sumber, telepon, tanggal, harga, keterangan)
                             VALUES (?, ?, ?, ?, ?, ?)');
    foreach ($items as $i => $it) {
        $stItem->execute([$paketId, $it['uraian'], $it['spek'], $it['satuan'], $it['jumlah'], $i + 1]);
        $itemId = (int)$pdo->lastInsertId();
        foreach ($it['survei'] as $s) {
            $stSurv->execute([$itemId, $s[0], $s[1], $s[2], $s[3], $s[4]]);
        }
    }
}
