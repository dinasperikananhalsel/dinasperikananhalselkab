<?php
// ============================================================================
// KONFIGURASI APLIKASI — Survei Harga Barang
// Dinas Perikanan Kabupaten Halmahera Selatan
// ============================================================================

const SITE_NAME    = 'Survei Harga Barang';
const INSTANSI     = 'Dinas Perikanan Kabupaten Halmahera Selatan';
const KODE_WILAYAH = 'Kabupaten Halmahera Selatan';
const SITE_TAGLINE = 'Pencatatan dan rekap hasil survei harga barang / jasa pengadaan';

const ALAMAT_KANTOR = 'Jl. Raya Mandaong No. 5, Labuha, Kabupaten Halmahera Selatan, Maluku Utara 97791';
const TELEPON       = '(0922) 21000';
const EMAIL_DINAS   = 'dinasperikananhalsel@gmail.com';

const TAHUN_MIN = 2000;
const TAHUN_MAX = 2100;

// Bidang/unit kerja di lingkungan Dinas Perikanan — paket dikelompokkan per bidang,
// dan tiap bidang punya operatornya sendiri.
const BIDANG = [
    'Bidang Perikanan Tangkap',
    'Bidang Perikanan Budidaya',
    'Bidang Pengolahan, Pemasaran dan SDP',
    'Sekretariat',
];

// Satuan umum untuk saran (datalist) — tidak membatasi input
const SATUAN_UMUM = [
    'unit', 'buah', 'pasang', 'set', 'paket', 'kg', 'gram', 'liter', 'meter',
    'lembar', 'batang', 'karung', 'sak', 'rol', 'dus', 'box', 'rim', 'lusin',
    'galon', 'ekor', 'kantong', 'kotak',
];

// Sumber dana umum untuk saran (datalist)
const SUMBER_DANA_UMUM = ['APBD', 'APBN', 'DAK', 'BLUD', 'Bantuan Pemerintah'];
