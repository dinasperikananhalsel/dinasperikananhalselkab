<?php
// ============================================================================
// Ringkasan data survei harga barang
//
// Aplikasi mencatat hasil survei harga per barang dari beberapa sumber.
// Ringkasan yang disajikan: jumlah sumber, harga terendah/tertinggi, dan
// rata-rata harga survei. (Fitur perhitungan HPS telah dihapus.)
// ============================================================================

/** Ringkasan survei sebuah item: jumlah sumber, min, max, rata-rata. */
function survei_stats(PDO $pdo, int $item_id): array
{
    $st = $pdo->prepare('SELECT COUNT(*) AS jml, MIN(harga) AS min_h, MAX(harga) AS max_h, AVG(harga) AS avg_h
                         FROM survei WHERE item_id = ?');
    $st->execute([$item_id]);
    $r = $st->fetch();

    $jml = (int)$r['jml'];
    return [
        'jml' => $jml,
        'min' => $jml > 0 ? (float)$r['min_h'] : null,
        'max' => $jml > 0 ? (float)$r['max_h'] : null,
        'avg' => $jml > 0 ? (float)$r['avg_h'] : null,
    ];
}

/** Paket + seluruh item berikut ringkasan surveinya. */
function paket_items(PDO $pdo, int $paket_id): array
{
    $st = $pdo->prepare('SELECT * FROM paket WHERE id = ?');
    $st->execute([$paket_id]);
    $paket = $st->fetch();
    if (!$paket) return [null, [], 0, 0];

    $st = $pdo->prepare('SELECT * FROM item WHERE paket_id = ? ORDER BY urutan ASC, id ASC');
    $st->execute([$paket_id]);
    $rows = $st->fetchAll();

    $items = [];
    $jmlSurvei = 0;
    foreach ($rows as $row) {
        $row['stats'] = survei_stats($pdo, (int)$row['id']);
        $jmlSurvei += $row['stats']['jml'];
        $items[] = $row;
    }

    return [$paket, $items, count($rows), $jmlSurvei];
}

/** Rata-rata seluruh harga survei dalam sebuah paket (untuk kartu ringkasan). */
function paket_avg_harga(PDO $pdo, int $paket_id): ?float
{
    $st = $pdo->prepare('SELECT AVG(s.harga) FROM survei s JOIN item i ON i.id = s.item_id WHERE i.paket_id = ?');
    $st->execute([$paket_id]);
    $v = $st->fetchColumn();
    return $v !== null && $v !== false ? (float)$v : null;
}

/** Rekap sumber survei per paket: per item, daftar baris survei. */
function paket_survei_rows(PDO $pdo, int $paket_id): array
{
    $st = $pdo->prepare(
        'SELECT s.id AS sid, s.sumber, s.telepon, s.tanggal, s.harga, s.keterangan,
                i.id AS item_id, i.uraian, i.satuan, i.jumlah, i.urutan
         FROM survei s
         JOIN item i ON i.id = s.item_id
         WHERE i.paket_id = ?
         ORDER BY i.urutan ASC, i.id ASC, s.id ASC'
    );
    $st->execute([$paket_id]);
    return $st->fetchAll();
}

