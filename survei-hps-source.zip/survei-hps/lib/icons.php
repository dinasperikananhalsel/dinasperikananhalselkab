<?php
// ============================================================================
// Ikon SVG inline (stroke, currentColor) — tanpa dependensi eksternal
// ============================================================================

function icon(string $name, int $size = 24, string $class = ''): string
{
    static $paths = [
        'users'         => '<circle cx="9" cy="8" r="3.4"/><path d="M2.6 20c1.2-3.2 3.5-5 6.4-5s5.2 1.8 6.4 5"/><path d="M16 4.9a3.4 3.4 0 0 1 0 6.2"/><path d="M17.6 15.2c1.5 1 2.8 2.5 3.5 4.8"/>',
        'phone'         => '<path d="M5 4h4l2 5-2.6 1.6a12.4 12.4 0 0 0 4.9 4.9L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
        'mail'          => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7.5 9 6 9-6"/>',
        'clock'         => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.4 2"/>',
        'chart'         => '<path d="M4 20V10"/><path d="M10 20V4"/><path d="M16 20v-7"/><path d="M3 20.5h18"/>',
        'file-text'     => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6"/><path d="M9 17h4"/>',
        'shield'        => '<path d="M12 3l7 3v6c0 4.6-3 7.6-7 9-4-1.4-7-4.4-7-9V6z"/><path d="m9 12 2.2 2.2L15.5 9.5"/>',
        'award'         => '<circle cx="12" cy="9" r="5"/><path d="m8.8 13.4-1.6 7 4.8-2.4 4.8 2.4-1.6-7"/>',
        'check-circle'  => '<circle cx="12" cy="12" r="9"/><path d="m8.5 12.5 2.5 2.5 5-6"/>',
        'chevron-down'  => '<path d="m6 9 6 6 6-6"/>',
        'arrow-right'   => '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
        'calendar'      => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4"/><path d="M16 3v4"/><path d="M3 10h18"/>',
        'edit'          => '<path d="M17 3a2.85 2.85 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z"/>',
        'trash'         => '<path d="M4 7h16"/><path d="M9.5 7V5a2 2 0 0 1 2-2h1a2 2 0 0 1 2 2v2"/><path d="M6 7l1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13"/>',
        'plus'          => '<path d="M12 5v14"/><path d="M5 12h14"/>',
        'search'        => '<circle cx="11" cy="11" r="7"/><path d="m20.5 20.5-3.8-3.8"/>',
        'alert'         => '<path d="M12 3 2 20h20L12 3z"/><path d="M12 10v5"/><path d="M12 18h.01"/>',
        'building'      => '<rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M9 7h2"/><path d="M13 7h2"/><path d="M9 11h2"/><path d="M13 11h2"/><path d="M9 15h2"/><path d="M13 15h2"/><path d="M10 21v-3h4v3"/>',
        'layers'        => '<path d="m12 3 9 5-9 5-9-5 9-5z"/><path d="m3 13 9 5 9-5"/><path d="m3 17 9 5 9-5"/>',
        'list'          => '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3.5 6h.01"/><path d="M3.5 12h.01"/><path d="M3.5 18h.01"/>',
        'external'      => '<path d="M14 4h6v6"/><path d="M20 4 10 14"/><path d="M19 14v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h5"/>',
        'download'      => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
        'file'          => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
        'folder'        => '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
        'calculator'    => '<rect x="5" y="2.5" width="14" height="19" rx="2"/><path d="M9 2.5h6v4H9z"/><path d="M8.5 11h.01"/><path d="M12 11h.01"/><path d="M15.5 11h.01"/><path d="M8.5 15h.01"/><path d="M12 15h.01"/><path d="M15.5 15h.01"/><path d="M8.5 19h.01"/><path d="M12 19h.01"/><path d="M15.5 19h.01"/>',
        'store'         => '<path d="M4 9.5 5.4 4h13.2L20 9.5"/><path d="M4 9.5a2.8 2.8 0 0 0 5.6 0 2.8 2.8 0 0 0 5.6 0 2.8 2.8 0 0 0 5.6 0"/><path d="M5.5 11.5V20h13v-8.5"/><path d="M9.5 20v-5h5v5"/>',
        'printer'       => '<path d="M6 9V3h12v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M6.5 14h11v7h-11z"/>',
        'box'           => '<path d="M21 8v8l-9 5-9-5V8l9-5 9 5z"/><path d="M3 8l9 5 9-5"/><path d="M12 13v8"/>',
        'tag'           => '<path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8z"/><circle cx="7.5" cy="7.5" r="1.3"/>',
        'percent'       => '<path d="M19 5 5 19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>',
        'send'          => '<path d="m3 11 18-8-6 18-3.5-6.5L3 11z"/><path d="M11.5 14.5 21 3"/>',
        'chevron-left'  => '<path d="m15 6-6 6 6 6"/>',
    ];

    if (!isset($paths[$name])) return '';
    $cls = $class !== '' ? ' class="' . e($class) . '"' : '';
    return '<svg' . $cls . ' xmlns="http://www.w3.org/2000/svg" width="' . $size
         . '" height="' . $size . '" viewBox="0 0 24 24"'
         . ' fill="none" stroke="currentColor"'
         . ' stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
         . $paths[$name] . '</svg>';
}
