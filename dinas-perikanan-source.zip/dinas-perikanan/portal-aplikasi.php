<?php
$base = '';
$pageTitle = 'Portal Aplikasi Online';
$activeNav = 'portal';
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/includes/header.php';

$pdo = db();
$aplikasi = $pdo->query('SELECT * FROM aplikasi WHERE status = 1 ORDER BY urutan ASC')->fetchAll();
?>

<div class="section" style="padding-top:44px;">
  <div class="container">
    <div class="section-head">
      <span class="section-tag">Portal Aplikasi Online</span>
      <h2 class="section-title">Aplikasi &amp; Layanan Digital</h2>
      <p class="section-sub">Kumpulan tautan aplikasi layanan online yang digunakan dalam penyelenggaraan urusan kelautan dan perikanan di <?= e(KODE_WILAYAH) ?>. Klik nama aplikasi untuk membukanya di tab baru.</p>
    </div>

    <?php if ($aplikasi): ?>
    <div class="grid grid-3">
      <?php foreach ($aplikasi as $i => $a): ?>
      <div class="card hover app-card" style="display:flex; flex-direction:column;">
        <div class="card-icon"><?= icon($a['ikon'], 26) ?></div>
        <h3><?= e($a['nama']) ?></h3>
        <p style="flex:1;"><?= e($a['deskripsi']) ?></p>
        <a class="btn btn-outline-navy btn-sm mt-16" style="align-self:flex-start;" href="<?= e($a['url']) ?>" target="_blank" rel="noopener">
          <?= icon('external', 16) ?> Buka Aplikasi
        </a>
      </div>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
      <div class="alert alert-info"><?= icon('search', 18) ?> <span>Belum ada aplikasi yang didaftarkan.</span></div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
