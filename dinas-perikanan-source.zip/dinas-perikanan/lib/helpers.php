<?php
// ============================================================================
// Fungsi bantu umum
// ============================================================================

/** Escape output HTML dengan aman. */
function e(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

/** Redirect lalu hentikan eksekusi. Membuang buffer output agar header Location selalu berfungsi. */
function redirect(string $url): never
{
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Location: ' . $url);
    exit;
}

/** Ambil nilai $_GET dengan default. */
function get(string $key, $default = null)
{
    return $_GET[$key] ?? $default;
}

/** Ambil nilai $_POST dengan default. */
function post(string $key, $default = null)
{
    return $_POST[$key] ?? $default;
}

/** Set pesan flash (session). */
function flash(string $msg, string $type = 'success'): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

/** Tampilkan & hapus pesan flash. */
function flash_out(): string
{
    if (empty($_SESSION['flash'])) return '';
    $f = $_SESSION['flash'];
    unset($_SESSION['flash']);
    $icon = $f['type'] === 'error' ? 'alert' : 'check-circle';
    return '<div class="alert alert-' . e($f['type']) . '">'
         . icon($icon, 20)
         . '<span>' . e($f['msg']) . '</span></div>';
}

/** Token CSRF untuk form admin. */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}

function csrf_check(): void
{
    $sent = $_POST['csrf'] ?? '';
    if (!is_string($sent) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $sent)) {
        http_response_code(419);
        exit('Sesi kedaluwarsa. Silakan muat ulang halaman dan coba lagi.');
    }
}

function csrf_check_q(): void
{
    $sent = $_GET['csrf'] ?? '';
    if (!is_string($sent) || empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $sent)) {
        http_response_code(419);
        exit('Sesi kedaluwarsa. Silakan muat ulang halaman dan coba lagi.');
    }
}

/** Status login admin. */
function is_auth(): bool
{
    return !empty($_SESSION['admin_id']);
}

/** Pesan ramah untuk kode error unggahan PHP (tabel $php_errormsg / $_FILES error). */
function pesan_error_upload(int $kode): string
{
    return match ($kode) {
        UPLOAD_ERR_INI_SIZE   => 'Ukuran berkas melebihi batas unggahan server (maks. 20 MB). Perkecil/kompres berkas lalu coba lagi.',
        UPLOAD_ERR_FORM_SIZE  => 'Ukuran berkas melebihi batas yang ditentukan pada formulir.',
        UPLOAD_ERR_PARTIAL    => 'Berkas hanya terunggah sebagian. Silakan coba lagi.',
        UPLOAD_ERR_NO_FILE    => 'Tidak ada berkas yang dipilih.',
        UPLOAD_ERR_NO_TMP_DIR => 'Folder penyimpanan sementara server tidak tersedia.',
        UPLOAD_ERR_CANT_WRITE => 'Gagal menulis berkas di server. Periksa izin folder.',
        UPLOAD_ERR_EXTENSION  => 'Unggahan dihentikan oleh pengaturan server.',
        default               => 'Gagal mengunggah berkas (kode ' . $kode . ').',
    };
}

function require_auth(): void
{
    if (!is_auth()) redirect('login.php');
}

/** Format tanggal database -> "12 Februari 2025" */
function tanggal_id(?string $dt, bool $denganJam = false): string
{
    if (!$dt) return '-';
    $ts = strtotime($dt);
    if ($ts === false) return e($dt);
    $bulan = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
              'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    $out = date('j', $ts) . ' ' . $bulan[(int)date('n', $ts)] . ' ' . date('Y', $ts);
    if ($denganJam) $out .= ' pukul ' . date('H:i', $ts) . ' WIT';
    return $out;
}

/** Panjang string UTF-8 (tanpa mbstring). */
function u8len(string $s): int
{
    return preg_match_all('/./us', $s, $m);
}

/** Substring UTF-8 (tanpa mbstring). */
function u8sub(string $s, int $start, int $len = 0): string
{
    preg_match_all('/./us', $s, $m);
    return implode('', array_slice($m[0], $start, $len === 0 ? null : $len));
}

/** Karakter pertama UTF-8. */
function u8first(string $s): string
{
    preg_match('/./us', $s, $m);
    return $m[0] ?? '';
}

/** Potong teks tanpa merusak kata. */
function potong(string $s, int $max = 120): string
{
    $s = trim(preg_replace('/\s+/u', ' ', strip_tags($s)));
    if (u8len($s) <= $max) return $s;
    $cut = u8sub($s, 0, $max);
    $pos = strrpos($cut, ' ');
    if ($pos > 0) $cut = u8sub($cut, 0, $pos);
    return $cut . '…';
}

/** Ubah newline paragraf menjadi <p>. */
function paragraf(string $s): string
{
    $paras = preg_split('/\r\n|\r|\n\s*\n/', trim($s));
    $out = '';
    foreach ($paras as $p) {
        $p = trim($p);
        if ($p !== '') $out .= '<p>' . e($p) . '</p>';
    }
    return $out;
}

/** Ambil baris pertama sebagai paragraf pembuka artikel. */
function paragraf_pembuka(string $s): string
{
    $s = trim($s);
    $pos = strpos($s, "\n\n");
    if ($pos !== false) $s = substr($s, 0, $pos);
    return e($s);
}

/** Warna badge kategori berita. */
function warna_kategori(string $k): string
{
    return match ($k) {
        'Pengumuman' => 'gold',
        'Prestasi'   => 'teal',
        'Program'    => 'blue',
        default      => 'navy',
    };
}

/** Angka ribuan dengan format Indonesia (1.234,5). */
function angka($n): string
{
    return number_format((float)$n, 0, ',', '.');
}
