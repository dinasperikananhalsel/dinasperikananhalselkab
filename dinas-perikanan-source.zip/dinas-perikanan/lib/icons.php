<?php
// ============================================================================
// Ikon SVG inline (stroke, currentColor) — tanpa dependensi eksternal
// ============================================================================

function icon(string $name, int $size = 24, string $class = ''): string
{
    static $paths = [
        'facebook'      => '<path d="M13.5 21.5v-7h2.4l.45-2.8h-2.85V9.75c0-.81.4-1.6 1.67-1.6h1.3V5.85s-1.18-.2-2.3-.2c-2.35 0-3.89 1.43-3.89 4.02V11.7H7.1v2.8h2.68v7h3.72z"/>',
        'tiktok'        => '<path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/>',
        'fish'          => '<path d="M3 12c1.6-3.6 4.6-5.6 8.2-5.6 3.1 0 5.6 1.1 7.3 2.7l3.1-1.8v5.4l-3.1-1.8c-1.7 1.6-4.2 2.7-7.3 2.7C7.6 13.6 4.6 11.6 3 12z"/><circle cx="15.6" cy="9.9" r=".9" fill="currentColor" stroke="none"/>',
        'waves'         => '<path d="M2 10c2.2-2.2 4.4-2.2 6.6 0s4.4 2.2 6.6 0 4.4-2.2 6.6 0"/><path d="M2 16c2.2-2.2 4.4-2.2 6.6 0s4.4 2.2 6.6 0 4.4-2.2 6.6 0"/>',
        'anchor'        => '<circle cx="12" cy="5" r="2.2"/><path d="M12 7.2V19"/><path d="M5.5 8.2H18.5"/><path d="M4 11a8 8 0 0 0 16 0"/>',
        'users'         => '<circle cx="9" cy="8" r="3.4"/><path d="M2.6 20c1.2-3.2 3.5-5 6.4-5s5.2 1.8 6.4 5"/><path d="M16 4.9a3.4 3.4 0 0 1 0 6.2"/><path d="M17.6 15.2c1.5 1 2.8 2.5 3.5 4.8"/>',
        'phone'         => '<path d="M5 4h4l2 5-2.6 1.6a12.4 12.4 0 0 0 4.9 4.9L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
        'mail'          => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7.5 9 6 9-6"/>',
        'map-pin'       => '<path d="M12 21.5S5 15.8 5 10.3a7 7 0 0 1 14 0c0 5.5-7 11.2-7 11.2z"/><circle cx="12" cy="10" r="2.6"/>',
        'clock'         => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.4 2"/>',
        'chart'         => '<path d="M4 20V10"/><path d="M10 20V4"/><path d="M16 20v-7"/><path d="M3 20.5h18"/>',
        'file-text'     => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6"/><path d="M9 17h4"/>',
        'shield'        => '<path d="M12 3l7 3v6c0 4.6-3 7.6-7 9-4-1.4-7-4.4-7-9V6z"/><path d="m9 12 2.2 2.2L15.5 9.5"/>',
        'award'         => '<circle cx="12" cy="9" r="5"/><path d="m8.8 13.4-1.6 7 4.8-2.4 4.8 2.4-1.6-7"/>',
        'megaphone'     => '<path d="m3 11 18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>',
        'check-circle'  => '<circle cx="12" cy="12" r="9"/><path d="m8.5 12.5 2.5 2.5 5-6"/>',
        'chevron-down'  => '<path d="m6 9 6 6 6-6"/>',
        'arrow-right'   => '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
        'calendar'      => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4"/><path d="M16 3v4"/><path d="M3 10h18"/>',
        'edit'          => '<path d="M17 3a2.85 2.85 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z"/>',
        'trash'         => '<path d="M4 7h16"/><path d="M9.5 7V5a2 2 0 0 1 2-2h1a2 2 0 0 1 2 2v2"/><path d="M6 7l1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13"/>',
        'plus'          => '<path d="M12 5v14"/><path d="M5 12h14"/>',
        'search'        => '<circle cx="11" cy="11" r="7"/><path d="m20.5 20.5-3.8-3.8"/>',
        'alert'         => '<path d="M12 3 2 20h20L12 3z"/><path d="M12 10v5"/><path d="M12 18h.01"/>',
        'boat'          => '<path d="M3 16.5c0 1 .8 1.9 1.8 1.9h14.4c1 0 1.8-.9 1.8-1.9l-1.3-5.5H4.3z"/><path d="M12 7.5V16.5"/><path d="M12 7.5 8.8 11.2h6.4z"/><path d="M4 21.5h16"/>',
        'building'      => '<rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M9 7h2"/><path d="M13 7h2"/><path d="M9 11h2"/><path d="M13 11h2"/><path d="M9 15h2"/><path d="M13 15h2"/><path d="M10 21v-3h4v3"/>',
        'layers'        => '<path d="m12 3 9 5-9 5-9-5 9-5z"/><path d="m3 13 9 5 9-5"/><path d="m3 17 9 5 9-5"/>',
        'send'          => '<path d="m3 11 18-8-6 18-3.5-6.5L3 11z"/><path d="M11.5 14.5 21 3"/>',
        'list'          => '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3.5 6h.01"/><path d="M3.5 12h.01"/><path d="M3.5 18h.01"/>',
        'external'      => '<path d="M14 4h6v6"/><path d="M20 4 10 14"/><path d="M19 14v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h5"/>',
        'download'      => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
        'file'          => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
        'folder'        => '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
        'photo'         => '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="8.5" cy="10" r="1.6"/><path d="m21 15-5-5L5 21"/>',
    ];

    if (!isset($paths[$name])) return '';
    $cls = $class !== '' ? ' class="' . e($class) . '"' : '';
    $filled = in_array($name, ['facebook', 'tiktok'], true) ? ' fill="currentColor" stroke="none"' : ' fill="none" stroke="currentColor"';
    return '<svg' . $cls . ' xmlns="http://www.w3.org/2000/svg" width="' . $size
         . '" height="' . $size . '" viewBox="0 0 24 24"' . $filled
         . ' stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
         . $paths[$name] . '</svg>';
}
