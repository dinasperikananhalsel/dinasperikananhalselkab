<?php
// ============================================================================
// Koneksi database SQLite + skema + data awal (idempoten)
// Database disimpan di data.sqlite di folder aplikasi.
// ============================================================================

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $file = __DIR__ . '/../data.sqlite';
        $pdo = new PDO('sqlite:' . $file, null, null, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $pdo->exec('PRAGMA journal_mode = WAL');
        $pdo->exec('PRAGMA busy_timeout = 5000');
        migrate($pdo);
    }
    return $pdo;
}

function migrate(PDO $pdo): void
{
    $pdo->exec('BEGIN');

    $pdo->exec("CREATE TABLE IF NOT EXISTS admin (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        nama TEXT NOT NULL DEFAULT 'Administrator'
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS berita (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        judul TEXT NOT NULL,
        ringkasan TEXT NOT NULL DEFAULT '',
        isi TEXT NOT NULL,
        kategori TEXT NOT NULL DEFAULT 'Kegiatan',
        penulis TEXT NOT NULL DEFAULT 'Humas Dinas Perikanan',
        tanggal TEXT NOT NULL,
        dilihat INTEGER NOT NULL DEFAULT 0,
        status INTEGER NOT NULL DEFAULT 1
    )");

    // Migrasi: kolom foto berita (fitur upload foto, ditambahkan kemudian)
    $beritaCols = $pdo->query('PRAGMA table_info(berita)')->fetchAll();
    $adaFoto = false;
    foreach ($beritaCols as $c) {
        if ($c['name'] === 'foto') { $adaFoto = true; break; }
    }
    if (!$adaFoto) {
        $pdo->exec("ALTER TABLE berita ADD COLUMN foto TEXT NOT NULL DEFAULT ''");
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS statistik (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tahun INTEGER NOT NULL UNIQUE,
        tangkap_ton REAL NOT NULL DEFAULT 0,
        budidaya_ton REAL NOT NULL DEFAULT 0,
        nilai_miliar REAL NOT NULL DEFAULT 0
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS komoditas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tahun INTEGER NOT NULL,
        nama TEXT NOT NULL,
        tonase REAL NOT NULL DEFAULT 0,
        urutan INTEGER NOT NULL DEFAULT 0
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS layanan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        kategori TEXT NOT NULL DEFAULT 'Layanan',
        deskripsi TEXT NOT NULL DEFAULT '',
        persyaratan TEXT NOT NULL DEFAULT '',
        waktu TEXT NOT NULL DEFAULT '',
        biaya TEXT NOT NULL DEFAULT '',
        urutan INTEGER NOT NULL DEFAULT 0
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS pesan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        email TEXT NOT NULL DEFAULT '',
        telepon TEXT NOT NULL DEFAULT '',
        subjek TEXT NOT NULL DEFAULT '',
        isi TEXT NOT NULL,
        tanggal TEXT NOT NULL,
        dibaca INTEGER NOT NULL DEFAULT 0
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS pengaduan (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        telepon TEXT NOT NULL DEFAULT '',
        lokasi TEXT NOT NULL DEFAULT '',
        judul TEXT NOT NULL,
        isi TEXT NOT NULL,
        tanggal TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Baru',
        tanggapan TEXT NOT NULL DEFAULT ''
    )");

    // Migrasi: kolom kode pengaduan (untuk pelacakan status di situs publik)
    $pengCols = $pdo->query('PRAGMA table_info(pengaduan)')->fetchAll();
    $adaKode = false;
    foreach ($pengCols as $c) {
        if ($c['name'] === 'kode') { $adaKode = true; break; }
    }
    if (!$adaKode) {
        $pdo->exec("ALTER TABLE pengaduan ADD COLUMN kode TEXT NOT NULL DEFAULT ''");
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS aplikasi (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        deskripsi TEXT NOT NULL DEFAULT '',
        url TEXT NOT NULL,
        ikon TEXT NOT NULL DEFAULT 'external',
        urutan INTEGER NOT NULL DEFAULT 0,
        status INTEGER NOT NULL DEFAULT 1
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS dokumen (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        judul TEXT NOT NULL,
        deskripsi TEXT NOT NULL DEFAULT '',
        kategori TEXT NOT NULL DEFAULT 'Dokumen',
        nama_file TEXT NOT NULL DEFAULT '',
        mime TEXT NOT NULL DEFAULT 'application/octet-stream',
        isi BLOB,
        ukuran INTEGER NOT NULL DEFAULT 0,
        tanggal TEXT NOT NULL,
        urutan INTEGER NOT NULL DEFAULT 0,
        status INTEGER NOT NULL DEFAULT 1
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS galeri (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        judul TEXT NOT NULL DEFAULT '',
        deskripsi TEXT NOT NULL DEFAULT '',
        mime TEXT NOT NULL DEFAULT 'image/jpeg',
        isi BLOB,
        ukuran INTEGER NOT NULL DEFAULT 0,
        tanggal TEXT NOT NULL,
        urutan INTEGER NOT NULL DEFAULT 0,
        status INTEGER NOT NULL DEFAULT 1
    )");

    // ---- Seed: hanya jika tabel kosong ----
    $adminCount = (int)$pdo->query('SELECT COUNT(*) FROM admin')->fetchColumn();
    if ($adminCount === 0) {
        $st = $pdo->prepare('INSERT INTO admin (username, password, nama) VALUES (?, ?, ?)');
        $st->execute(['admin', password_hash('admin123', PASSWORD_DEFAULT), 'Administrator Dinas']);
    }

    $beritaCount = (int)$pdo->query('SELECT COUNT(*) FROM berita')->fetchColumn();
    if ($beritaCount === 0) seed_berita($pdo);

    $statCount = (int)$pdo->query('SELECT COUNT(*) FROM statistik')->fetchColumn();
    if ($statCount === 0) seed_statistik($pdo);

    $komCount = (int)$pdo->query('SELECT COUNT(*) FROM komoditas')->fetchColumn();
    if ($komCount === 0) seed_komoditas($pdo);

    $layCount = (int)$pdo->query('SELECT COUNT(*) FROM layanan')->fetchColumn();
    if ($layCount === 0) seed_layanan($pdo);

    $appCount = (int)$pdo->query('SELECT COUNT(*) FROM aplikasi')->fetchColumn();
    if ($appCount === 0) seed_aplikasi($pdo);

    $docCount = (int)$pdo->query('SELECT COUNT(*) FROM dokumen')->fetchColumn();
    if ($docCount === 0) seed_dokumen($pdo);

    $galCount = (int)$pdo->query('SELECT COUNT(*) FROM galeri')->fetchColumn();
    if ($galCount === 0) seed_galeri($pdo);

    $pdo->exec('COMMIT');
}

function seed_berita(PDO $pdo): void
{
    $rows = [
        [
            'judul' => 'Dinas Perikanan Salurkan 200.000 Benih Ikan untuk Pembudidaya di Kecamatan Bacan',
            'ringkasan' => 'Bantuan benih ikan nila dan bandeng disalurkan kepada kelompok pembudidaya sebagai bagian dari program peningkatan produksi perikanan budidaya tahun 2025.',
            'isi' => <<<'TXT'
Dinas Perikanan Kabupaten Halmahera Selatan menyalurkan bantuan benih ikan sebanyak 200.000 ekor kepada kelompok pembudidaya ikan di Kecamatan Bacan. Bantuan ini terdiri atas benih ikan nila dan bandeng yang diharapkan mampu mendorong peningkatan produksi perikanan budidaya di wilayah pesisir Kabupaten Halmahera Selatan.

Penyerahan bantuan dilakukan secara simbolis di Balai Benih Ikan (BBI) milik daerah, dengan melibatkan penyuluh perikanan pendamping. Kepala Dinas Perikanan menyampaikan bahwa bantuan benih ini merupakan wujud komitmen pemerintah daerah dalam mendukung ketahanan pangan dan kesejahteraan pembudidaya lokal.

"Kami berharap benih yang diberikan dapat dikelola dengan baik oleh kelompok, sehingga produksi perikanan budidaya kita terus meningkat dari tahun ke tahun," ujarnya dalam sambutannya.

Selain penyaluran benih, Dinas Perikanan juga memberikan pendampingan teknis budidaya, mulai dari pengelolaan kualitas air hingga pencegahan penyakit ikan. Pendampingan dilakukan oleh penyuluh perikanan secara berkala agar hasil panen pembudidaya optimal dan sesuai standar.
TXT,
            'kategori' => 'Kegiatan',
            'penulis' => 'Humas Dinas Perikanan',
            'tanggal' => '2025-02-18 09:30:00',
        ],
        [
            'judul' => 'Pelatihan Budidaya Rumput Laut untuk Kelompok Nelayan di Kepulauan Obi',
            'ringkasan' => 'Puluhan anggota kelompok nelayan di Kepulauan Obi mengikuti pelatihan teknis budidaya rumput laut metode long line.',
            'isi' => <<<'TXT'
Dinas Perikanan Kabupaten Halmahera Selatan menggelar pelatihan teknis budidaya rumput laut bagi kelompok nelayan di kawasan Kepulauan Obi. Pelatihan ini bertujuan meningkatkan keterampilan masyarakat pesisir dalam membudidayakan rumput laut dengan metode long line yang lebih produktif dan ramah lingkungan.

Kegiatan yang berlangsung selama tiga hari ini menghadirkan instruktur dari Balai Perikanan Budidaya serta praktisi rumput laut berpengalaman. Materi yang diberikan meliputi pemilihan lokasi budidaya, pengikatan bibit, perawatan, hingga teknik panen dan penjemuran yang baik.

Para peserta juga diajak praktik langsung di perairan untuk memasang tali ris dan mengikat bibit rumput laut. Kepala Bidang Budidaya menuturkan bahwa rumput laut merupakan salah satu komoditas unggulan daerah yang memiliki pangsa pasar cukup besar, baik domestik maupun ekspor.

Setelah pelatihan, peserta akan didampingi penyuluh perikanan dalam penerapan budidaya di lokasi masing-masing. Dinas Perikanan juga membuka akses bantuan sarana berupa tali, pelampung, dan bibit bagi kelompok yang siap mengembangkan usaha budidayanya.
TXT,
            'kategori' => 'Kegiatan',
            'penulis' => 'Humas Dinas Perikanan',
            'tanggal' => '2025-02-04 10:00:00',
        ],
        [
            'judul' => 'Produksi Perikanan Tangkap Halmahera Selatan Tumbuh 8,5 Persen pada 2024',
            'ringkasan' => 'Data Dinas Perikanan mencatat produksi perikanan tangkap tahun 2024 mencapai 55.600 ton, naik 8,5 persen dibanding tahun sebelumnya.',
            'isi' => <<<'TXT'
Produksi perikanan tangkap Kabupaten Halmahera Selatan sepanjang tahun 2024 tercatat mencapai 55.600 ton atau tumbuh 8,5 persen dibandingkan capaian tahun 2023 yang sebesar 51.300 ton. Peningkatan ini didorong oleh membaiknya kondisi cuaca, meningkatnya jumlah armada yang beroperasi, serta penambahan sarana dan prasarana perikanan di sejumlah pangkalan pendaratan ikan.

Komoditas utama penyumbang produksi tangkap antara lain cakalang, tuna, dan ikan layang yang banyak didaratkan di Pelabuhan Perikanan Labuha serta PPI di kawasan Bacan dan Obi.

Kepala Dinas Perikanan menyampaikan apresiasi kepada para nelayan dan seluruh pemangku kepentingan atas capaian tersebut. Ia menegaskan bahwa pemerintah daerah akan terus mendorong pengelolaan perikanan yang bertanggung jawab agar peningkatan produksi tidak mengganggu kelestarian sumber daya ikan.

Ke depan, Dinas Perikanan akan memperkuat pendataan hasil tangkapan, pembinaan kualitas hasil, serta diversifikasi pemasaran agar nilai tambah yang diterima nelayan semakin besar.
TXT,
            'kategori' => 'Prestasi',
            'penulis' => 'Humas Dinas Perikanan',
            'tanggal' => '2025-01-20 08:45:00',
        ],
        [
            'judul' => 'Sosialisasi Asuransi Nelayan Tahun 2025 Digelar di Pelabuhan Perikanan Labuha',
            'ringkasan' => 'Pemerintah memberikan perlindungan asuransi bagi nelayan kecil melalui program asuransi nelayan yang didukung pembayaran premi oleh pemerintah.',
            'isi' => <<<'TXT'
Dinas Perikanan Kabupaten Halmahera Selatan menggelar sosialisasi program asuransi nelayan tahun 2025 di kawasan Pelabuhan Perikanan Labuha. Kegiatan ini diikuti oleh perwakilan kelompok nelayan dari Kecamatan Bacan dan sekitarnya.

Program asuransi nelayan merupakan perlindungan sosial bagi nelayan kecil atas risiko kecelakaan dan kematian saat melaut, dengan premi yang dibayarkan oleh pemerintah. Melalui sosialisasi ini, nelayan diharapkan memahami manfaat, mekanisme pendaftaran, serta hak-haknya sebagai peserta.

Petugas menjelaskan bahwa nelayan yang memenuhi kriteria dapat didaftarkan melalui kelompoknya masing-masing atau langsung ke kantor Dinas Perikanan dengan membawa kartu tanda penduduk dan dokumen kapal.

Dinas Perikanan menargetkan ribuan nelayan terdaftar sebagai peserta asuransi pada tahun 2025. Para nelayan yang hadir menyambut baik program ini dan berharap pendaftaran dapat dilakukan dengan mudah dan cepat.
TXT,
            'kategori' => 'Program',
            'penulis' => 'Humas Dinas Perikanan',
            'tanggal' => '2025-01-12 09:00:00',
        ],
        [
            'judul' => 'Gerakan Makan Ikan (Gemarikan) Perkuat Gizi Masyarakat dan Cegah Stunting',
            'ringkasan' => 'Gemarikan digelar sebagai upaya meningkatkan konsumsi ikan masyarakat sekaligus mendukung program percepatan penurunan stunting.',
            'isi' => <<<'TXT'
Dinas Perikanan Kabupaten Halmahera Selatan kembali menggelar Gerakan Memasyarakatkan Makan Ikan (Gemarikan) yang menyasar ibu hamil, ibu menyusui, dan anak usia sekolah. Kegiatan ini merupakan bagian dari upaya bersama meningkatkan konsumsi ikan masyarakat guna mencegah stunting.

Dalam kegiatan tersebut, diberikan edukasi tentang kandungan gizi ikan serta demonstrasi pengolahan ikan menjadi aneka produk olahan yang digemari anak-anak. Ikan laut segar juga dibagikan kepada peserta sebagai wujud nyata kampanye makan ikan.

Konsumsi ikan masyarakat Halmahera Selatan dinilai masih perlu ditingkatkan meskipun daerah memiliki potensi perikanan yang sangat besar. Oleh karena itu, Gemarikan akan terus digalakkan hingga ke tingkat kecamatan dan desa.

Kepala Dinas Perikanan mengajak seluruh elemen masyarakat untuk menjadikan ikan sebagai menu harian keluarga. "Ikan adalah sumber protein yang murah dan mudah didapat di daerah kita. Mari kita biasakan makan ikan sejak dini," ujarnya.
TXT,
            'kategori' => 'Program',
            'penulis' => 'Humas Dinas Perikanan',
            'tanggal' => '2024-12-09 10:30:00',
        ],
        [
            'judul' => 'Puluhan Nelayan Ikuti Pelatihan Keselamatan Kerja Sebelum Melaut',
            'ringkasan' => 'Pelatihan keselamatan kerja diberikan kepada nelayan sebagai upaya menekan angka kecelakaan laut dan meningkatkan kesiapsiagaan.',
            'isi' => <<<'TXT'
Sebanyak 60 nelayan di kawasan Pelabuhan Perikanan Labuha mengikuti pelatihan keselamatan kerja dan penggunaan alat keselamatan di atas kapal. Pelatihan ini digelar bekerja sama dengan instansi terkait untuk menekan risiko kecelakaan kerja di sektor perikanan tangkap.

Materi yang diberikan meliputi penggunaan life jacket dan pelampung, prosedur pertolongan pertama, komunikasi darurat, hingga pengetahuan dasar kondisi cuaca dan tanda-tanda bahaya di laut. Peserta juga mempraktikkan cara mengenakan alat keselamatan secara benar.

Para nelayan mengaku mendapatkan pengetahuan baru yang sangat berguna sebelum berlayar. Salah satu peserta menyampaikan bahwa selama ini banyak nelayan yang kurang memperhatikan perlengkapan keselamatan, padahal hal itu sangat menentukan keselamatan jiwa.

Dinas Perikanan berkomitmen melanjutkan pelatihan serupa di kecamatan-kecamatan lain secara bertahap, serta mendorong kelompok nelayan untuk melengkapi kapalnya dengan alat keselamatan sesuai standar.
TXT,
            'kategori' => 'Kegiatan',
            'penulis' => 'Humas Dinas Perikanan',
            'tanggal' => '2024-11-25 11:00:00',
        ],
        [
            'judul' => 'Pemkab Halsel Fasilitasi Sertifikasi HACCP bagi Unit Pengolahan Ikan Lokal',
            'ringkasan' => 'Sertifikasi HACCP diharapkan meningkatkan daya saing produk olahan ikan daerah di pasar nasional dan ekspor.',
            'isi' => <<<'TXT'
Pemerintah Kabupaten Halmahera Selatan melalui Dinas Perikanan memfasilitasi sertifikasi Hazard Analysis and Critical Control Points (HACCP) bagi unit pengolahan ikan (UPI) lokal. Fasilitasi ini merupakan bagian dari program peningkatan nilai tambah produk perikanan daerah.

Sertifikasi HACCP menjadi syarat penting bagi unit pengolahan agar produknya dapat diterima pasar modern dan memenuhi standar ekspor. Melalui pendampingan intensif, diharapkan semakin banyak UPI di Halmahera Selatan yang mampu menembus pasar yang lebih luas.

Kegiatan yang berlangsung selama beberapa hari ini melibatkan asesor dari lembaga sertifikasi yang diakui. Para pelaku usaha mendapatkan pendampingan mulai dari pengelolaan bahan baku, proses produksi, hingga pengemasan dan penyimpanan.

Dinas Perikanan menyatakan akan terus mendorong pelaku usaha pengolahan ikan untuk meningkatkan mutu produk, sehingga produk khas daerah seperti ikan asap dan abon ikan semakin dikenal dan diminati pasar.
TXT,
            'kategori' => 'Prestasi',
            'penulis' => 'Humas Dinas Perikanan',
            'tanggal' => '2024-11-04 09:15:00',
        ],
        [
            'judul' => 'Pengumuman: Pendaftaran Calon Peserta Asuransi Nelayan Gelombang II',
            'ringkasan' => 'Nelayan kecil yang memenuhi kriteria dapat mendaftar menjadi peserta asuransi nelayan melalui kelompok atau kantor Dinas Perikanan.',
            'isi' => <<<'TXT'
Dinas Perikanan Kabupaten Halmahera Selatan membuka pendaftaran calon peserta asuransi nelayan gelombang II tahun 2024. Program ini ditujukan bagi nelayan kecil yang aktif melaut dan belum terdaftar sebagai peserta asuransi nelayan.

Persyaratan peserta: (1) Warga Negara Indonesia yang dibuktikan dengan Kartu Tanda Penduduk; (2) berprofesi sebagai nelayan kecil yang menggunakan kapal berukuran di bawah 10 GT; (3) terdaftar dalam kelompok nelayan; dan (4) belum pernah menerima santunan asuransi nelayan.

Pendaftaran dilakukan melalui kelompok nelayan masing-masing atau langsung ke kantor Dinas Perikanan Kabupaten Halmahera Selatan pada jam layanan. Calon peserta diminta membawa fotokopi KTP dan surat keterangan dari kepala desa.

Premi asuransi ditanggung oleh pemerintah sehingga tidak ada pungutan bagi nelayan peserta. Informasi lebih lanjut dapat menghubungi Dinas Perikanan pada jam kerja.
TXT,
            'kategori' => 'Pengumuman',
            'penulis' => 'Sekretariat Dinas',
            'tanggal' => '2024-10-15 08:00:00',
        ],
    ];

    $st = $pdo->prepare('INSERT INTO berita (judul, ringkasan, isi, kategori, penulis, tanggal, status)
                         VALUES (?, ?, ?, ?, ?, ?, 1)');
    foreach ($rows as $r) {
        $st->execute([$r['judul'], $r['ringkasan'], $r['isi'], $r['kategori'], $r['penulis'], $r['tanggal']]);
    }
}

function seed_statistik(PDO $pdo): void
{
    $rows = [
        [2019, 42500, 8200, 615],
        [2020, 39800, 9100, 598],
        [2021, 44600, 10400, 672],
        [2022, 47900, 11800, 715],
        [2023, 51300, 13200, 768],
        [2024, 55600, 15100, 834],
    ];
    $st = $pdo->prepare('INSERT INTO statistik (tahun, tangkap_ton, budidaya_ton, nilai_miliar) VALUES (?, ?, ?, ?)');
    foreach ($rows as $r) $st->execute($r);
}

function seed_komoditas(PDO $pdo): void
{
    $rows = [
        [2024, 'Cakalang',    18400, 1],
        [2024, 'Tuna',        14200, 2],
        [2024, 'Rumput Laut', 11500, 3],
        [2024, 'Ikan Layang',  9800, 4],
        [2024, 'Udang',        2300, 5],
        [2024, 'Kerapu',       1900, 6],
        [2024, 'Bandeng',       850, 7],
        [2024, 'Teripang',      640, 8],
    ];
    $st = $pdo->prepare('INSERT INTO komoditas (tahun, nama, tonase, urutan) VALUES (?, ?, ?, ?)');
    foreach ($rows as $r) $st->execute($r);
}

function seed_layanan(PDO $pdo): void
{    $rows = [
        [
            'nama' => 'Penerbitan Surat Izin Penangkapan Ikan (SIPI)',
            'kategori' => 'Perizinan',
            'deskripsi' => 'Penerbitan SIPI bagi kapal perikanan berukuran di atas 10 GT yang beroperasi di wilayah pengelolaan perikanan dalam kewenangan daerah.',
            'persyaratan' => "Fotokopi KTP pemilik kapal;\nFotokopi Surat Tanda Bukti Kepemilikan Kapal (STBKK);\nFotokopi Surat Persetujuan Berlayar;\nSurat permohonan bermaterai;\nPas foto 3x4 (2 lembar).",
            'waktu' => '5 hari kerja',
            'biaya' => 'Sesuai ketentuan PNBP yang berlaku',
        ],
        [
            'nama' => 'Rekomendasi Perizinan Berusaha Sektor Perikanan (OSS)',
            'kategori' => 'Perizinan',
            'deskripsi' => 'Penerbitan surat rekomendasi sebagai persyaratan pengajuan perizinan berusaha bidang perikanan tangkap dan budidaya melalui sistem OSS.',
            'persyaratan' => "Fotokopi KTP pemohon;\nNIB (Nomor Induk Berusaha);\nDokumen teknis usaha perikanan;\nSurat permohonan bermaterai.",
            'waktu' => '3 hari kerja',
            'biaya' => 'Gratis',
        ],
        [
            'nama' => 'Pendaftaran dan Sertifikasi Pembudidaya Ikan (CPIB)',
            'kategori' => 'Sertifikasi',
            'deskripsi' => 'Pendaftaran pembudidaya ikan serta fasilitasi penerbitan sertifikat kompetensi pembudidaya ikan (CPIB) untuk meningkatkan mutu usaha budidaya.',
            'persyaratan' => "Fotokopi KTP;\nFotokopi Kartu Keluarga;\nSurat permohonan;\nSurat keterangan dari kepala desa;\nPas foto 3x4 (2 lembar).",
            'waktu' => '5 hari kerja',
            'biaya' => 'Gratis',
        ],
        [
            'nama' => 'Surat Rekomendasi Pengadaan dan Penebaran Benih Ikan',
            'kategori' => 'Perizinan',
            'deskripsi' => 'Rekomendasi teknis bagi kelompok pembudidaya yang mengajukan bantuan pengadaan benih ikan dari pemerintah atau sumber lainnya.',
            'persyaratan' => "Fotokopi KTP ketua kelompok;\nProposal pengajuan bantuan;\nSurat keterangan kelompok aktif dari desa;\nData kepemilikan kolam/tambak.",
            'waktu' => '3 hari kerja',
            'biaya' => 'Gratis',
        ],
        [
            'nama' => 'Pelayanan Data dan Statistik Perikanan',
            'kategori' => 'Informasi',
            'deskripsi' => 'Pelayanan permintaan data produksi perikanan tangkap, budidaya, pengolahan, dan data kelautan lainnya untuk kepentingan penelitian, usaha, atau penyusunan kebijakan.',
            'persyaratan' => "Surat permohonan resmi (instansi/perorangan);\nFotokopi KTP;\nMenjelaskan tujuan penggunaan data.",
            'waktu' => '3 hari kerja',
            'biaya' => 'Gratis',
        ],
        [
            'nama' => 'Pendampingan dan Fasilitasi Asuransi Nelayan',
            'kategori' => 'Pemberdayaan',
            'deskripsi' => 'Pendaftaran nelayan kecil sebagai peserta asuransi nelayan, termasuk verifikasi berkas dan koordinasi dengan pihak asuransi.',
            'persyaratan' => "Fotokopi KTP;\nSurat keterangan nelayan dari kepala desa;\nData kapal (jika ada);\nTerdaftar dalam kelompok nelayan.",
            'waktu' => '7 hari kerja',
            'biaya' => 'Gratis (premi ditanggung pemerintah)',
        ],
        [
            'nama' => 'Bantuan Sarana dan Prasarana Perikanan',
            'kategori' => 'Pemberdayaan',
            'deskripsi' => 'Penyaluran bantuan sarana perikanan seperti alat tangkap ramah lingkungan, mesin kapal, tali ris rumput laut, dan sarana pengolahan bagi kelompok yang memenuhi kriteria.',
            'persyaratan' => "Proposal permohonan kelompok;\nAD/ART dan daftar anggota kelompok;\nSurat keterangan dari kepala desa;\nHasil verifikasi lapangan oleh petugas.",
            'waktu' => 'Menyesuaikan jadwal penyaluran',
            'biaya' => 'Gratis',
        ],
        [
            'nama' => 'Layanan Pengaduan Masyarakat',
            'kategori' => 'Lainnya',
            'deskripsi' => 'Wadah penyampaian pengaduan, keluhan, dan informasi terkait penyelenggaraan urusan kelautan dan perikanan di Kabupaten Halmahera Selatan.',
            'persyaratan' => "Identitas pelapor (nama dan nomor telepon);\nUraian kronologis kejadian;\nLokasi kejadian.",
            'waktu' => 'Ditindaklanjuti maksimal 7 hari kerja',
            'biaya' => 'Gratis',
        ],
    ];

    $st = $pdo->prepare('INSERT INTO layanan (nama, kategori, deskripsi, persyaratan, waktu, biaya, urutan)
                         VALUES (?, ?, ?, ?, ?, ?, ?)');
    $i = 1;
    foreach ($rows as $r) {
        $st->execute([$r['nama'], $r['kategori'], $r['deskripsi'], $r['persyaratan'], $r['waktu'], $r['biaya'], $i]);
        $i++;
    }
}

function seed_aplikasi(PDO $pdo): void
{
    $rows = [
        [
            'nama' => 'OSS — Online Single Submission',
            'deskripsi' => 'Perizinan berusaha terintegrasi secara elektronik untuk usaha perikanan tangkap, budidaya, dan pengolahan.',
            'url' => 'https://oss.go.id',
            'ikon' => 'building',
        ],
        [
            'nama' => 'e-Logbook Penangkapan Ikan',
            'deskripsi' => 'Sistem pencatatan logbook penangkapan ikan secara elektronik dari Kementerian Kelautan dan Perikanan.',
            'url' => 'https://elogbook.kkp.go.id',
            'ikon' => 'anchor',
        ],
        [
            'nama' => 'Satu Data Kelautan dan Perikanan',
            'deskripsi' => 'Portal data kelautan dan perikanan nasional yang dapat diakses untuk keperluan penelitian dan kebijakan.',
            'url' => 'https://satudata.kkp.go.id',
            'ikon' => 'chart',
        ],
        [
            'nama' => 'E-Kinerja',
            'deskripsi' => 'Aplikasi pengukuran dan penilaian kinerja pegawai Aparatur Sipil Negara secara elektronik.',
            'url' => 'https://kinerja.bkn.go.id',
            'ikon' => 'award',
        ],
    ];

    $st = $pdo->prepare('INSERT INTO aplikasi (nama, deskripsi, url, ikon, urutan, status) VALUES (?, ?, ?, ?, ?, 1)');
    $i = 1;
    foreach ($rows as $r) {
        $st->execute([$r['nama'], $r['deskripsi'], $r['url'], $r['ikon'], $i]);
        $i++;
    }
}

function seed_dokumen(PDO $pdo): void
{
    // Pengaman: jangan seed jika sudah ada dokumen dengan judul yang sama
    $ada = (int)$pdo->query("SELECT COUNT(*) FROM dokumen WHERE judul LIKE 'Contoh Dokumen%' OR judul LIKE 'Pedoman Layanan%'")->fetchColumn();
    if ($ada > 0) return;

    // Dua dokumen contoh (PDF kecil dibuat programatik) — ganti lewat panel admin.
    $pdf1 = base64_decode('JVBERi0xLjQKMSAwIG9iago8PCAvVHlwZSAvQ2F0YWxvZyAvUGFnZXMgMiAwIFIgPj4KZW5kb2JqCjIgMCBvYmoKPDwgL1R5cGUgL1BhZ2VzIC9LaWRzIFszIDAgUl0gL0NvdW50IDEgPj4KZW5kb2JqCjMgMCBvYmoKPDwgL1R5cGUgL1BhZ2UgL1BhcmVudCAyIDAgUiAvTWVkaWFCb3ggWzAgMCA2MTIgNzkyXSAvQ29udGVudHMgNCAwIFIgL1Jlc291cmNlcyA8PCAvRm9udCA8PCAvRjEgNSAwIFIgL0YyIDYgMCBSIC9GMyA3IDAgUiA+PiA+PiA+PgplbmRvYmoKNCAwIG9iago8PCAvTGVuZ3RoIDIzMiA+PgpzdHJlYW0KQlQgL0YxIDE2IFRmIDcyIDc0MCBUZCAoRE9LVU1FTiBQVUJMSUsgLSBESU5BUyBQRVJJS0FOQU4pIFRqIEVUCkJUIC9GMiAxMSBUZiA3MiA3MTYgVGQgKEthYnVwYXRlbiBIYWxtYWhlcmEgU2VsYXRhbikgVGogRVQKQlQgL0YzIDEwIFRmIDcyIDY5MCBUZCAoQ29udG9oIGRva3VtZW4gcHVibGlrLiBTaWxha2FuIGdhbnRpIGRlbmdhbiBkb2t1bWVuIHJlc21pIG1lbGFsdWkgcGFuZWwgYWRtaW4uKSBUaiBFVAplbmRzdHJlYW0KZW5kb2JqCjUgMCBvYmoKPDwgL1R5cGUgL0ZvbnQgL1N1YnR5cGUgL1R5cGUxIC9CYXNlRm9udCAvSGVsdmV0aWNhLUJvbGQgPj4KZW5kb2JqCjYgMCBvYmoKPDwgL1R5cGUgL0ZvbnQgL1N1YnR5cGUgL1R5cGUxIC9CYXNlRm9udCAvSGVsdmV0aWNhID4+CmVuZG9iago3IDAgb2JqCjw8IC9UeXBlIC9Gb250IC9TdWJ0eXBlIC9UeXBlMSAvQmFzZUZvbnQgL0hlbHZldGljYS1PYmxpcXVlID4+CmVuZG9iagp4cmVmCjAgOAowMDAwMDAwMDAwIDY1NTM1IGYgCjAwMDAwMDAwMDkgMDAwMDAgbiAKMDAwMDAwMDA1OCAwMDAwMCBuIAowMDAwMDAwMTE1IDAwMDAwIG4gCjAwMDAwMDAyNjEgMDAwMDAgbiAKMDAwMDAwMDU0NCAwMDAwMCBuIAowMDAwMDAwNjE5IDAwMDAwIG4gCjAwMDAwMDA2ODkgMDAwMDAgbiAKdHJhaWxlcgo8PCAvU2l6ZSA4IC9Sb290IDEgMCBSID4+CnN0YXJ0eHJlZgo3NjcKJSVFT0Y=');
    $pdf2 = base64_decode('JVBERi0xLjQKMSAwIG9iago8PCAvVHlwZSAvQ2F0YWxvZyAvUGFnZXMgMiAwIFIgPj4KZW5kb2JqCjIgMCBvYmoKPDwgL1R5cGUgL1BhZ2VzIC9LaWRzIFszIDAgUl0gL0NvdW50IDEgPj4KZW5kb2JqCjMgMCBvYmoKPDwgL1R5cGUgL1BhZ2UgL1BhcmVudCAyIDAgUiAvTWVkaWFCb3ggWzAgMCA2MTIgNzkyXSAvQ29udGVudHMgNCAwIFIgL1Jlc291cmNlcyA8PCAvRm9udCA8PCAvRjEgNSAwIFIgL0YyIDYgMCBSIC9GMyA3IDAgUiA+PiA+PiA+PgplbmRvYmoKNCAwIG9iago8PCAvTGVuZ3RoIDIyOSA+PgpzdHJlYW0KQlQgL0YxIDE2IFRmIDcyIDc0MCBUZCAoUEVET01BTiBMQVlBTkFOIFBFUklaSU5BTikgVGogRVQKQlQgL0YyIDExIFRmIDcyIDcxNiBUZCAoRGluYXMgUGVyaWthbmFuIEthYi4gSGFsbWFoZXJhIFNlbGF0YW4pIFRqIEVUCkJUIC9GMyAxMCBUZiA3MiA2OTAgVGQgKERva3VtZW4gY29udG9oIGtlZHVhOiBhbHVyIGRhbiBwZXJzeWFyYXRhbiBsYXlhbmFuIHBlcml6aW5hbiBwZXJpa2FuYW4uKSBUaiBFVAplbmRzdHJlYW0KZW5kb2JqCjUgMCBvYmoKPDwgL1R5cGUgL0ZvbnQgL1N1YnR5cGUgL1R5cGUxIC9CYXNlRm9udCAvSGVsdmV0aWNhLUJvbGQgPj4KZW5kb2JqCjYgMCBvYmoKPDwgL1R5cGUgL0ZvbnQgL1N1YnR5cGUgL1R5cGUxIC9CYXNlRm9udCAvSGVsdmV0aWNhID4+CmVuZG9iago3IDAgb2JqCjw8IC9UeXBlIC9Gb250IC9TdWJ0eXBlIC9UeXBlMSAvQmFzZUZvbnQgL0hlbHZldGljYS1PYmxpcXVlID4+CmVuZG9iagp4cmVmCjAgOAowMDAwMDAwMDAwIDY1NTM1IGYgCjAwMDAwMDAwMDkgMDAwMDAgbiAKMDAwMDAwMDA1OCAwMDAwMCBuIAowMDAwMDAwMTE1IDAwMDAwIG4gCjAwMDAwMDAyNjEgMDAwMDAgbiAKMDAwMDAwMDU0MSAwMDAwMCBuIAowMDAwMDAwNjE2IDAwMDAwIG4gCjAwMDAwMDA2ODYgMDAwMDAgbiAKdHJhaWxlcgo8PCAvU2l6ZSA4IC9Sb290IDEgMCBSID4+CnN0YXJ0eHJlZgo3NjQKJSVFT0Y=');

    $rows = [
        [
            'judul' => 'Contoh Dokumen Publik',
            'deskripsi' => 'Contoh dokumen publik Dinas Perikanan Kabupaten Halmahera Selatan. Dokumen ini dapat diganti dengan dokumen resmi melalui panel admin.',
            'kategori' => 'Laporan',
            'nama_file' => 'contoh-dokumen-publik.pdf',
            'mime' => 'application/pdf',
            'isi' => $pdf1,
        ],
        [
            'judul' => 'Pedoman Layanan Perizinan Perikanan',
            'deskripsi' => 'Pedoman alur dan persyaratan layanan perizinan di bidang perikanan. Contoh dokumen, silakan diganti dengan versi resmi.',
            'kategori' => 'Peraturan',
            'nama_file' => 'pedoman-layanan-perizinan.pdf',
            'mime' => 'application/pdf',
            'isi' => $pdf2,
        ],
    ];

    $st = $pdo->prepare('INSERT INTO dokumen (judul, deskripsi, kategori, nama_file, mime, isi, ukuran, tanggal, urutan, status)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)');
    $i = 1;
    foreach ($rows as $r) {
        $st->bindValue(1, $r['judul']);
        $st->bindValue(2, $r['deskripsi']);
        $st->bindValue(3, $r['kategori']);
        $st->bindValue(4, $r['nama_file']);
        $st->bindValue(5, $r['mime']);
        $st->bindValue(6, $r['isi'], PDO::PARAM_LOB);
        $st->bindValue(7, strlen($r['isi']), PDO::PARAM_INT);
        $st->bindValue(8, date('Y-m-d H:i:s'));
        $st->bindValue(9, $i, PDO::PARAM_INT);
        $st->execute();
        $i++;
    }
}

function seed_galeri(PDO $pdo): void
{
    // Foto contoh galeri — file sampel dikomit di assets/img/galeri-sample-*.jpg
    // lalu disalin ke BLOB database (platform tidak melayani file statis runtime).
    $file1 = __DIR__ . '/../assets/img/galeri-sample-1.jpg';
    $file2 = __DIR__ . '/../assets/img/galeri-sample-2.jpg';
    $file3 = __DIR__ . '/../assets/img/galeri-sample-3.jpg';

    $rows = [];
    foreach ([
        ['Contoh Foto Kegiatan Penangkapan Ikan', 'Dokumentasi contoh: aktivitas perikanan tangkap di perairan Halmahera Selatan. Ganti dengan foto kegiatan resmi melalui panel admin.', $file1],
        ['Contoh Foto Budidaya Perikanan', 'Dokumentasi contoh: kegiatan perikanan budidaya. Ganti dengan foto kegiatan resmi melalui panel admin.', $file2],
        ['Contoh Foto Sarana & Prasarana', 'Dokumentasi contoh: sarana dan prasarana perikanan. Ganti dengan foto kegiatan resmi melalui panel admin.', $file3],
    ] as $i => $r) {
        if (!is_file($r[2])) continue;
        $isi = file_get_contents($r[2]);
        if ($isi === false) continue;
        $rows[] = ['judul' => $r[0], 'deskripsi' => $r[1], 'isi' => $isi];
    }
    if (!$rows) return;

    $st = $pdo->prepare('INSERT INTO galeri (judul, deskripsi, mime, isi, ukuran, tanggal, urutan, status)
                         VALUES (?, ?, ?, ?, ?, ?, ?, 1)');
    $i = 1;
    foreach ($rows as $r) {
        $st->bindValue(1, $r['judul']);
        $st->bindValue(2, $r['deskripsi']);
        $st->bindValue(3, 'image/jpeg');
        $st->bindValue(4, $r['isi'], PDO::PARAM_LOB);
        $st->bindValue(5, strlen($r['isi']), PDO::PARAM_INT);
        $st->bindValue(6, date('Y-m-d H:i:s'));
        $st->bindValue(7, $i, PDO::PARAM_INT);
        $st->execute();
        $i++;
    }
}
