<?php
// ============================================================================
// KONFIGURASI SITUS — Dinas Perikanan Kabupaten Halmahera Selatan
// Ubah data kontak / identitas instansi di bawah sesuai kebutuhan.
// ============================================================================

const SITE_NAME     = 'Dinas Perikanan';
const INSTANSI      = 'Pemerintah Kabupaten Halmahera Selatan';
const SITE_TAGLINE  = 'Mewujudkan perikanan tangkap dan budidaya yang maju, mandiri, dan berkelanjutan';

const ALAMAT_KANTOR = 'Jl. Raya Mandaong No. 5, Labuha, Kabupaten Halmahera Selatan, Maluku Utara 97791';
const TELEPON       = '(0922) 21000';
const WHATSAPP      = '0823-4500-7980';
const EMAIL_DINAS   = 'dinasperikananhalsel@gmail.com';
const FACEBOOK_NAMA = 'Dinas Perikanan Kab Halsel';
const FACEBOOK_URL  = 'https://www.facebook.com/search/top?q=Dinas%20Perikanan%20Kab%20Halsel'; // ganti dengan URL halaman resmi bila tersedia
const TIKTOK_NAMA   = '@dinasperikananhalsel';
const TIKTOK_URL    = 'https://www.tiktok.com/@dinasperikananhalsel';
const JAM_LAYANAN   = 'Senin – Jumat, 08.00 – 16.00 WIT';
const NAMA_BUPATI   = 'Hasan Ali Bassam Kasuba';
const NAMA_WAKIL_BUPATI = 'Helmi Umar Muchsin';
const NAMA_KEPALA   = 'Idris Ali';
const KODE_WILAYAH  = 'Kabupaten Halmahera Selatan';
