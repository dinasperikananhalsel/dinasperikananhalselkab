<?php
$base = '';
$pageTitle = 'Dokumen Publik';
$activeNav = 'dokumen';
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/includes/header.php';

$pdo = db();
$kategoris = ['Peraturan', 'Laporan', 'Data & Statistik', 'Lainnya'];
$kategori = trim((string)get('kategori', ''));
if ($kategori !== '' && !in_array($kategori, $kategoris, true)) $kategori = '';

if ($kategori !== '') {
    $st = $pdo->prepare('SELECT * FROM dokumen WHERE status = 1 AND kategori = ? ORDER BY tanggal DESC, urutan ASC');
    $st->execute([$kategori]);
    $dokumen = $st->fetchAll();
} else {
    $dokumen = $pdo->query('SELECT * FROM dokumen WHERE status = 1 ORDER BY tanggal DESC, urutan ASC')->fetchAll();
}

function ukuran_file(int $b): string
{
    if ($b >= 1048576) return number_format($b / 1048576, 1, ',', '.') . ' MB';
    if ($b >= 1024) return number_format($b / 1024, 0, ',', '.') . ' KB';
    return $b . ' B';
}

function ekstensi_dokumen(string $nama): string
{
    return strtoupper(pathinfo($nama, PATHINFO_EXTENSION)) ?: 'FILE';
}

function warna_jenis(string $ext): string
{
    return match ($ext) {
        'PDF' => 'red',
        'DOC', 'DOCX' => 'blue',
        'XLS', 'XLSX', 'CSV' => 'teal',
        'PPT', 'PPTX' => 'gold',
        default => 'navy',
    };
}
?>

<div class="section" style="padding-top:44px;">
  <div class="container">
    <div class="section-head">
      <span class="section-tag">Dokumen Publik</span>
      <h2 class="section-title">Dokumen &amp; Peraturan Terkait</h2>
      <p class="section-sub">Dokumen resmi, laporan, peraturan, dan data publik <?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?> yang dapat diunduh oleh masyarakat.</p>
    </div>

    <div style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:28px;">
      <a class="btn btn-sm <?= $kategori === '' ? 'btn-primary' : 'btn-outline-navy' ?>" href="<?= $site ?>dokumen-publik.php">Semua</a>
      <?php foreach ($kategoris as $k): ?>
      <a class="btn btn-sm <?= $kategori === $k ? 'btn-primary' : 'btn-outline-navy' ?>" href="<?= $site ?>dokumen-publik.php?kategori=<?= e(urlencode($k)) ?>"><?= e($k) ?></a>
      <?php endforeach; ?>
    </div>

    <?php if ($dokumen): ?>
    <div class="grid grid-2" style="align-items:stretch;">
      <?php foreach ($dokumen as $d):
          $ext = ekstensi_dokumen($d['nama_file']);
          $w = warna_jenis($ext); ?>
      <div class="card doc-card hover">
        <div style="display:flex; gap:16px; align-items:flex-start;">
          <div class="doc-ico <?= e($w) ?>"><?= icon('file', 26) ?><span><?= e($ext) ?></span></div>
          <div style="flex:1; min-width:0;">
            <div class="doc-meta">
              <span class="pill <?= e($w) ?>"><?= e($d['kategori']) ?></span>
              <span><?= icon('calendar', 14) ?> <?= e(tanggal_id($d['tanggal'])) ?></span>
            </div>
            <h3 style="font-size:16.5px; margin-top:8px;"><?= e($d['judul']) ?></h3>
            <p style="font-size:14px; margin-top:6px;"><?= e($d['deskripsi']) ?></p>
            <div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px; margin-top:14px;">
              <span class="form-note"><?= icon('file', 13) ?> <?= e($d['nama_file']) ?> · <?= e(ukuran_file((int)$d['ukuran'])) ?></span>
              <a class="btn btn-primary btn-sm" href="<?= $site ?>dokumen.php?id=<?= (int)$d['id'] ?>"><?= icon('download', 16) ?> Unduh</a>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
      <div class="alert alert-info"><?= icon('folder', 18) ?> <span>Belum ada dokumen pada kategori ini.</span></div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
