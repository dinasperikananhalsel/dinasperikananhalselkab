# Website Dinas Perikanan Kabupaten Halmahera Selatan

Website resmi (portal informasi & layanan) Dinas Perikanan Kabupaten Halmahera Selatan,
dibangun dengan **PHP 8 + SQLite (PDO)** — tanpa framework dan tanpa dependensi eksternal
(semua ikon/chart adalah SVG/CSS inline).

## Menjalankan secara lokal

```bash
# pastikan ekstensi pdo_sqlite aktif (di server produksi sudah default)
php -d extension=pdo.so -d extension=pdo_sqlite.so -d session.save_path=/tmp \
    -S 127.0.0.1:8000 -t .   # dari folder induk yang berisi dinas-perikanan/
```

Lalu buka `http://127.0.0.1:8000/dinas-perikanan/`.

Database (`data.sqlite`) dibuat otomatis pada kunjungan pertama beserta data awal
(berita, statistik, komoditas, layanan). Tidak ada skrip seed terpisah.

## Login admin

| | |
|---|---|
| URL | `/dinas-perikanan/admin/login.php` |
| Username | `admin` |
| Password | `admin123` |

> **Penting:** segera ganti password default. Password admin di-hash dengan
> `password_hash()` di tabel `admin`. Ganti lewat SQLite (mis. `UPDATE admin SET password = '<hash>'`).

Fitur admin: kelola berita (publikasi/draf, hapus, **upload foto** — JPG/PNG/WebP/GIF
maks. 3 MB, disimpan di database & dilayani via `foto-berita.php?id=`), data statistik
& komoditas per tahun,
layanan publik, pesan masuk dari formulir kontak, dan pengaduan masyarakat (status + tanggapan).

## Struktur

```
dinas-perikanan/
├── index.php            Beranda
├── profil.php           Profil, visi-misi, tupoksi, struktur organisasi
├── berita.php           Daftar berita (+ detail via ?id=, filter kategori, paginasi)
├── layanan.php          Layanan publik + FAQ
├── statistik.php        Data produksi (grafik CSS) + tabel
├── kontak.php           Info kontak + formulir pesan + peta
├── pengaduan.php        Formulir pengaduan masyarakat
├── portal-aplikasi.php  Portal Aplikasi Online (tautan aplikasi, kelola via admin)
├── dokumen-publik.php   Dokumen Publik (unduh dokumen, kelola via admin)
├── dokumen.php          Endpoint unduh dokumen (melayani BLOB dari database)
├── galeri.php           Galeri foto kegiatan (grid + lightbox, kelola via admin)
├── galeri-foto.php      Endpoint foto galeri (melayani BLOB dari database)
├── admin/               Panel admin (login session + CSRF)
├── includes/            header.php & footer.php bersama
├── lib/                 config.php, db.php (skema+seed), helpers.php, icons.php
├── assets/              css, js, img (logo daerah PNG + favicon)
└── data.sqlite          Database (dibuat otomatis, jangan dihapus saat aplikasi berjalan)
```

## Catatan konten

- Identitas & kontak (alamat, telepon, email, jam layanan) diatur di `lib/config.php` —
  nilai saat ini adalah contoh/placeholder yang perlu disesuaikan instansi.
- Nama pejabat sengaja generik ("Kepala Dinas Perikanan") — sesuaikan bila perlu.
- Berita, statistik, dan layanan adalah data awal contoh yang bisa diedit dari panel admin.
- Semua path aset/link **relatif** (tanpa slash di depan) agar situs benar saat dipasang
  di subpath `/dinas-perikanan/`.
