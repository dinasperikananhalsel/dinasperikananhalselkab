<?php
// ============================================================================
// Endpoint foto galeri — melayani gambar dari kolom BLOB tabel galeri.
// CATATAN platform: file statis yang dibuat saat runtime TIDAK dilayani oleh
// platform, sehingga foto galeri disimpan di database SQLite dan disajikan
// melalui skrip ini.
// ============================================================================
require_once __DIR__ . '/lib/db.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { http_response_code(404); exit('Not found'); }

$db = db();
$st = $db->prepare('SELECT mime, isi FROM galeri WHERE id = ? AND status = 1');
$st->execute([$id]);
$foto = $st->fetch();

if (!$foto || !is_string($foto['isi']) || $foto['isi'] === '') {
    http_response_code(404);
    exit('Not found');
}

header('Content-Type: ' . ($foto['mime'] ?: 'image/jpeg'));
header('Cache-Control: public, max-age=3600');
header('Content-Length: ' . strlen($foto['isi']));
echo $foto['isi'];
exit;
