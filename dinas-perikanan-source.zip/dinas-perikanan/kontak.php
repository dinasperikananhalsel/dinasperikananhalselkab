<?php
$base = '';
$pageTitle = 'Kontak';
$activeNav = 'kontak';
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/includes/header.php';

$pdo = db();
$sukses = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama   = trim((string)post('nama'));
    $email  = trim((string)post('email'));
    $telp   = trim((string)post('telepon'));
    $subjek = trim((string)post('subjek'));
    $isi    = trim((string)post('isi'));

    if ($nama === '' || $isi === '') {
        $err = 'Nama dan isi pesan wajib diisi.';
    } elseif ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err = 'Format alamat email tidak valid.';
    } else {
        $st = $pdo->prepare('INSERT INTO pesan (nama, email, telepon, subjek, isi, tanggal) VALUES (?, ?, ?, ?, ?, ?)');
        $st->execute([$nama, $email, $telp, $subjek, $isi, date('Y-m-d H:i:s')]);
        $sukses = 'Terima kasih, pesan Anda telah kami terima dan akan segera ditindaklanjuti.';
    }
}
?>

<div class="section" style="padding-top:44px;">
  <div class="container">
    <div class="grid grid-2" style="align-items:start; gap:36px;">
      <div>
        <span class="section-tag">Hubungi Kami</span>
        <h2 class="section-title">Kontak <?= e(SITE_NAME) ?></h2>
        <p class="section-sub">Silakan hubungi kami melalui kanal berikut, atau kirim pesan melalui formulir di samping.</p>

        <div style="display:flex; flex-direction:column; gap:18px; margin-top:24px;">
          <div class="contact-item">
            <div class="ci-icon"><?= icon('map-pin', 22) ?></div>
            <div><h4>Alamat Kantor</h4><p><?= e(ALAMAT_KANTOR) ?></p></div>
          </div>
          <div class="contact-item">
            <div class="ci-icon"><?= icon('phone', 22) ?></div>
            <div>
              <h4>Telepon / WhatsApp</h4>
              <p><?= e(TELEPON) ?><br>
                <a href="https://wa.me/6282345007980" target="_blank" rel="noopener" style="font-weight:600; color:var(--navy-800);">
                  <?= icon('send', 14) ?> <?= e(WHATSAPP) ?> (klik untuk chat)
                </a>
              </p>
            </div>
          </div>
          <div class="contact-item">
            <div class="ci-icon"><?= icon('mail', 22) ?></div>
            <div><h4>Email</h4><p><?= e(EMAIL_DINAS) ?></p></div>
          </div>
          <div class="contact-item">
            <div class="ci-icon" style="background:#e7edf7; color:#1877f2;"><?= icon('facebook', 22) ?></div>
            <div>
              <h4>Facebook</h4>
              <p><a href="<?= e(FACEBOOK_URL) ?>" target="_blank" rel="noopener" style="font-weight:600; color:var(--navy-800);"><?= e(FACEBOOK_NAMA) ?> <?= icon('external', 13) ?></a></p>
            </div>
          </div>
          <div class="contact-item">
            <div class="ci-icon" style="background:#0f1117; color:#ffffff;"><?= icon('tiktok', 22) ?></div>
            <div>
              <h4>TikTok</h4>
              <p><a href="<?= e(TIKTOK_URL) ?>" target="_blank" rel="noopener" style="font-weight:600; color:var(--navy-800);"><?= e(TIKTOK_NAMA) ?> <?= icon('external', 13) ?></a></p>
            </div>
          </div>
          <div class="contact-item">
            <div class="ci-icon"><?= icon('clock', 22) ?></div>
            <div><h4>Jam Layanan</h4><p><?= e(JAM_LAYANAN) ?></p></div>
          </div>
        </div>
      </div>

      <div class="form-card">
        <h3 style="font-size:18px; color:var(--navy-900); margin-bottom:18px;">Kirim Pesan</h3>
        <?php if (!empty($sukses)): ?>
          <div class="alert alert-success"><?= icon('check-circle', 20) ?> <span><?= e($sukses) ?></span></div>
        <?php elseif (!empty($err)): ?>
          <div class="alert alert-error"><?= icon('alert', 20) ?> <span><?= e($err) ?></span></div>
        <?php endif; ?>
        <form method="post" action="<?= $site ?>kontak.php">
          <div class="form-grid">
            <div class="field">
              <label for="nama">Nama Lengkap <span class="req">*</span></label>
              <input type="text" id="nama" name="nama" required maxlength="120" value="<?= e(post('nama', '')) ?>">
            </div>
            <div class="field">
              <label for="telepon">No. Telepon</label>
              <input type="text" id="telepon" name="telepon" maxlength="30" value="<?= e(post('telepon', '')) ?>">
            </div>
            <div class="field full">
              <label for="email">Alamat Email</label>
              <input type="email" id="email" name="email" maxlength="120" value="<?= e(post('email', '')) ?>">
            </div>
            <div class="field full">
              <label for="subjek">Subjek</label>
              <input type="text" id="subjek" name="subjek" maxlength="160" value="<?= e(post('subjek', '')) ?>">
            </div>
            <div class="field full">
              <label for="isi">Isi Pesan <span class="req">*</span></label>
              <textarea id="isi" name="isi" required maxlength="4000" rows="6"><?= e(post('isi', '')) ?></textarea>
            </div>
          </div>
          <button type="submit" class="btn btn-primary mt-16"><?= icon('send', 17) ?> Kirim Pesan</button>
        </form>
      </div>
    </div>

    <div class="mt-32">
      <div class="map-wrap">
        <iframe title="Lokasi Dinas Perikanan Kabupaten Halmahera Selatan" loading="lazy" referrerpolicy="no-referrer-when-downgrade"
          src="https://maps.google.com/maps?q=Jl.%20Raya%20Mandaong%20Labuha%2C%20Halmahera%20Selatan&t=&z=15&ie=UTF8&iwloc=&output=embed"></iframe>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
