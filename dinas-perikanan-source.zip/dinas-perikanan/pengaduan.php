<?php
$base = '';
$pageTitle = 'Pengaduan';
$activeNav = 'kontak';
require_once __DIR__ . '/lib/helpers.php';
require_once __DIR__ . '/lib/db.php';

$pdo = db();
$sukses = null;
$kodeBaru = '';

// Generate kode pengaduan unik: ADU-XXXXXX
function buat_kode_pengaduan(PDO $pdo): string
{
    do {
        $kode = 'ADU-' . strtoupper(bin2hex(random_bytes(3)));
        $st = $pdo->prepare('SELECT COUNT(*) FROM pengaduan WHERE kode = ?');
        $st->execute([$kode]);
    } while ((int)$st->fetchColumn() > 0);
    return $kode;
}

// Proses POST SEBELUM output apa pun agar redirect() (PRG) berfungsi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama   = trim((string)post('nama'));
    $telp   = trim((string)post('telepon'));
    $lokasi = trim((string)post('lokasi'));
    $judul  = trim((string)post('judul'));
    $isi    = trim((string)post('isi'));

    if ($nama === '' || $judul === '' || $isi === '') {
        $err = 'Nama, judul, dan uraian pengaduan wajib diisi.';
    } else {
        $kodeBaru = buat_kode_pengaduan($pdo);
        $st = $pdo->prepare('INSERT INTO pengaduan (nama, telepon, lokasi, judul, isi, tanggal, kode) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $st->execute([$nama, $telp, $lokasi, $judul, $isi, date('Y-m-d H:i:s'), $kodeBaru]);
        redirect('pengaduan.php?sukses=' . urlencode($kodeBaru));
    }
}

// Tampilkan kode sukses dari query (hasil redirect setelah pengiriman)
$suksesKode = strtoupper(trim((string)get('sukses', '')));
if ($suksesKode !== '') {
    $sukses = 'Pengaduan Anda berhasil dikirim dan akan ditindaklanjuti paling lambat 7 hari kerja. Simpan kode pengaduan Anda untuk memantau status. Terima kasih.';
    $kodeBaru = $suksesKode;
}

// ---------- Cek status pengaduan ----------
$cek = strtoupper(trim((string)get('cek', '')));
$hasilCek = null;
if ($cek !== '') {
    $st = $pdo->prepare('SELECT * FROM pengaduan WHERE kode = ?');
    $st->execute([$cek]);
    $hasilCek = $st->fetch() ?: null;
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="section" style="padding-top:44px;">
  <div class="container">
    <div class="grid grid-2" style="align-items:start; gap:36px;">
      <div>
        <span class="section-tag">Layanan Pengaduan</span>
        <h2 class="section-title">Sampaikan Pengaduan Anda</h2>
        <p class="section-sub">Gunakan kanal ini untuk menyampaikan pengaduan, keluhan, atau informasi terkait penyelenggaraan urusan kelautan dan perikanan di <?= e(KODE_WILAYAH) ?>.</p>
        <div class="card mt-24">
          <h3 style="display:flex; align-items:center; gap:9px; font-size:16px;"><?= icon('shield', 19) ?> Jaminan Kerahasiaan</h3>
          <p style="margin-top:10px;">Identitas pelapor dirahasiakan dan digunakan semata-mata untuk keperluan tindak lanjut. Pengaduan yang disampaikan secara jelas, lengkap, dan dapat diverifikasi akan diprioritaskan penanganannya.</p>
        </div>
        <div class="card mt-16">
          <h3 style="display:flex; align-items:center; gap:9px; font-size:16px;"><?= icon('clock', 19) ?> Alur Penanganan</h3>
          <ul class="tupoksi" style="list-style:none;">
            <li><span class="no">1</span><div><strong>Verifikasi</strong> kelengkapan dan kesesuaian pengaduan.</div></li>
            <li><span class="no">2</span><div><strong>Penelaahan</strong> oleh bidang terkait.</div></li>
            <li><span class="no">3</span><div><strong>Penanganan</strong> dan penjadwalan tindak lanjut lapangan.</div></li>
            <li><span class="no">4</span><div><strong>Penyampaian hasil</strong> kepada pelapor.</div></li>
          </ul>
        </div>

        <div class="card mt-16">
          <h3 style="display:flex; align-items:center; gap:9px; font-size:16px;"><?= icon('search', 19) ?> Cek Status Pengaduan</h3>
          <p style="margin-top:8px;">Masukkan kode pengaduan (contoh: <strong>ADU-A1B2C3</strong>) yang Anda terima saat mengirim pengaduan.</p>
          <form method="get" action="<?= $site ?>pengaduan.php" style="display:flex; gap:8px; margin-top:14px;">
            <input type="text" name="cek" required maxlength="12" placeholder="ADU-XXXXXX" value="<?= e($cek) ?>" style="flex:1; font-family:inherit; font-size:14.5px; border:1.5px solid var(--line); border-radius:9px; padding:10px 13px; text-transform:uppercase;">
            <button type="submit" class="btn btn-primary btn-sm" style="white-space:nowrap;"><?= icon('search', 16) ?> Cek</button>
          </form>

          <?php if ($cek !== ''): ?>
            <div class="mt-16">
              <?php if ($hasilCek):
                  $cls = match ($hasilCek['status']) { 'Selesai' => 'selesai', 'Diproses' => 'diproses', default => 'baru' }; ?>
              <div style="background:var(--bg); border-radius:10px; padding:14px 16px; border:1px solid var(--line);">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                  <strong style="color:var(--navy-900);"><?= e($hasilCek['kode']) ?> — <?= e($hasilCek['judul']) ?></strong>
                  <span class="status-pill <?= e($cls) ?>"><?= e($hasilCek['status']) ?></span>
                </div>
                <p style="font-size:13px; color:var(--muted); margin-top:6px;"><?= icon('calendar', 14) ?> Dikirim <?= e(tanggal_id($hasilCek['tanggal'], true)) ?></p>
                <?php if ($hasilCek['tanggapan']): ?>
                  <p style="margin-top:10px; font-size:14px; background:#fff; border-radius:8px; padding:10px 12px;"><strong style="color:var(--navy-900);">Tanggapan:</strong> <?= e($hasilCek['tanggapan']) ?></p>
                <?php else: ?>
                  <p style="margin-top:10px; font-size:13.5px; color:var(--muted); font-style:italic;">Belum ada tanggapan. Pengaduan sedang dalam proses penanganan.</p>
                <?php endif; ?>
              </div>
              <?php else: ?>
              <div class="alert alert-error" style="margin-bottom:0;"><?= icon('alert', 18) ?> <span>Kode pengaduan <strong><?= e($cek) ?></strong> tidak ditemukan. Periksa kembali kode Anda.</span></div>
              <?php endif; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <div class="form-card">
        <h3 style="font-size:18px; color:var(--navy-900); margin-bottom:18px;">Formulir Pengaduan</h3>
        <?php if (!empty($sukses)): ?>
          <div class="alert alert-success"><?= icon('check-circle', 20) ?> <span><?= e($sukses) ?></span></div>
          <?php if ($kodeBaru): ?>
          <div style="border:2px dashed var(--gold); background:#fffdf6; text-align:center; padding:20px; border-radius:12px; margin-bottom:20px;">
            <div style="font-size:13px; color:var(--muted); font-weight:600; letter-spacing:.5px;">KODE PENGADUAN ANDA</div>
            <div style="font-size:30px; font-weight:800; color:var(--navy-900); letter-spacing:2px; margin-top:6px;"><?= e($kodeBaru) ?></div>
            <div style="font-size:13px; color:var(--muted); margin-top:6px;">Gunakan kode ini di kolom "Cek Status Pengaduan" untuk memantau perkembangan penanganan.</div>
          </div>
          <?php endif; ?>
        <?php elseif (!empty($err)): ?>
          <div class="alert alert-error"><?= icon('alert', 20) ?> <span><?= e($err) ?></span></div>
        <?php endif; ?>
        <form method="post" action="<?= $site ?>pengaduan.php">
          <div class="form-grid">
            <div class="field">
              <label for="nama">Nama Lengkap <span class="req">*</span></label>
              <input type="text" id="nama" name="nama" required maxlength="120" value="<?= e(post('nama', '')) ?>">
            </div>
            <div class="field">
              <label for="telepon">No. Telepon <span class="req">*</span></label>
              <input type="text" id="telepon" name="telepon" required maxlength="30" value="<?= e(post('telepon', '')) ?>">
            </div>
            <div class="field">
              <label for="lokasi">Lokasi Kejadian</label>
              <input type="text" id="lokasi" name="lokasi" maxlength="160" placeholder="mis. Desa / Kecamatan" value="<?= e(post('lokasi', '')) ?>">
            </div>
            <div class="field">
              <label for="judul">Judul Pengaduan <span class="req">*</span></label>
              <input type="text" id="judul" name="judul" required maxlength="160" value="<?= e(post('judul', '')) ?>">
            </div>
            <div class="field full">
              <label for="isi">Uraian Kejadian <span class="req">*</span></label>
              <textarea id="isi" name="isi" required maxlength="4000" rows="7" placeholder="Jelaskan kronologi kejadian secara singkat dan jelas..."><?= e(post('isi', '')) ?></textarea>
            </div>
          </div>
          <button type="submit" class="btn btn-primary mt-16"><?= icon('send', 17) ?> Kirim Pengaduan</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
