<?php
// ============================================================================
// Endpoint unduh dokumen publik — melayani file dari kolom BLOB tabel dokumen.
// CATATAN platform: file statis yang dibuat saat runtime TIDAK dilayani oleh
// platform, sehingga dokumen disimpan di database SQLite dan disajikan skrip ini.
// ============================================================================
require_once __DIR__ . '/lib/db.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { http_response_code(404); exit('Not found'); }

$db = db();
$st = $db->prepare('SELECT judul, nama_file, mime, isi, ukuran FROM dokumen WHERE id = ? AND status = 1');
$st->execute([$id]);
$doc = $st->fetch();

if (!$doc || empty($doc['isi'])) {
    http_response_code(404);
    exit('Not found');
}

$namaFile = $doc['nama_file'] !== '' ? $doc['nama_file'] : 'dokumen-' . $id . '.pdf';
$mime = $doc['mime'] !== '' ? $doc['mime'] : 'application/octet-stream';

// Nama file aman untuk header (ASCII fallback + RFC 5987 untuk karakter khusus)
$namaAscii = preg_replace('/[^A-Za-z0-9._-]/', '_', $namaFile);
$namaAscii = $namaAscii === '' ? 'dokumen-' . $id . '.pdf' : $namaAscii;

header('Content-Type: ' . $mime);
header('Content-Length: ' . strlen($doc['isi']));
header('Content-Disposition: attachment; filename="' . $namaAscii . '"; filename*=UTF-8\'\'' . rawurlencode($namaFile));
header('Cache-Control: public, max-age=3600');
header('X-Content-Type-Options: nosniff');

echo $doc['isi'];
exit;
