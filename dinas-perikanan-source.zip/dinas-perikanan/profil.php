<?php
$base = '';
$pageTitle = 'Profil';
$activeNav = 'profil';
require_once __DIR__ . '/includes/header.php';
?>

<div class="section" style="padding-top:44px;">
  <div class="container">

    <div class="grid grid-2" style="align-items:start; gap:40px;">
      <div>
        <span class="section-tag">Tentang Dinas</span>
        <h2 class="section-title"><?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?></h2>
        <p style="color:var(--muted); margin-top:14px;">
          <?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?> merupakan unsur pelaksana urusan pemerintahan daerah di bidang kelautan dan perikanan. Dinas dibentuk seiring dengan pemekaran Kabupaten Halmahera Selatan dan terus berkembang mengikuti dinamika kebutuhan pembangunan kelautan dan perikanan daerah.
        </p>
        <p style="color:var(--muted); margin-top:10px;">
          Sebagai daerah kepulauan, Kabupaten Halmahera Selatan memiliki wilayah laut yang sangat luas meliputi gugusan Kepulauan Bacan, Obi, Gane, dan sekitarnya. Kondisi ini menjadikan sektor perikanan tangkap, budidaya laut, serta pengolahan hasil perikanan sebagai sektor unggulan yang menopang perekonomian dan mata pencaharian sebagian besar masyarakat.
        </p>
        <p style="color:var(--muted); margin-top:10px;">
          Dalam penyelenggaraannya, Dinas Perikanan berpedoman pada peraturan perundang-undangan di bidang kelautan dan perikanan, serta mendukung pencapaian prioritas pembangunan daerah, nasional, dan Tujuan Pembangunan Berkelanjutan (TPB/SDGs).
        </p>
      </div>
      <div>
        <div class="card" style="padding:0; overflow:hidden;">
          <div class="news-thumb" style="height:120px; border-radius:0;"><?= icon('boat', 54) ?></div>
          <div style="padding:22px 24px;">
            <h3 style="font-size:16px; display:flex; align-items:center; gap:9px;"><?= icon('map-pin', 18) ?> Wilayah Kerja</h3>
            <p style="margin-top:10px; font-size:14.5px;">Kantor Dinas Perikanan berlokasi di <?= e(ALAMAT_KANTOR) ?>.</p>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-top:16px;">
              <div class="badge" style="justify-content:center; padding:10px;"><?= icon('building', 15) ?> 30 kecamatan</div>
              <div class="badge" style="justify-content:center; padding:10px;"><?= icon('waves', 15) ?> Daerah kepulauan</div>
              <div class="badge" style="justify-content:center; padding:10px;"><?= icon('users', 15) ?> ± 12.400 nelayan</div>
              <div class="badge" style="justify-content:center; padding:10px;"><?= icon('fish', 15) ?> 8 komoditas unggulan</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="divider"></div>

    <!-- Pimpinan -->
    <div class="section-head center">
      <span class="section-tag">Pimpinan</span>
      <h2 class="section-title">Pimpinan Daerah dan Dinas</h2>
      <p class="section-sub">Pemimpin <?= e(KODE_WILAYAH) ?> dan <?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?> periode berjalan.</p>
    </div>
    <div class="leader-grid">
      <div class="leader-card fade-in">
        <div class="leader-photo"><img src="<?= $site ?>assets/img/bupati.png" alt="Bupati Halmahera Selatan"></div>
        <div class="leader-info">
          <span class="role">Bupati</span>
          <h3><?= e(NAMA_BUPATI) ?></h3>
          <div class="inst">Bupati <?= e(KODE_WILAYAH) ?></div>
        </div>
      </div>
      <div class="leader-card fade-in">
        <div class="leader-photo"><img src="<?= $site ?>assets/img/wakil-bupati.png" alt="Wakil Bupati Halmahera Selatan"></div>
        <div class="leader-info">
          <span class="role">Wakil Bupati</span>
          <h3><?= e(NAMA_WAKIL_BUPATI) ?></h3>
          <div class="inst">Wakil Bupati <?= e(KODE_WILAYAH) ?></div>
        </div>
      </div>
      <div class="leader-card fade-in">
        <div class="leader-photo"><img src="<?= $site ?>assets/img/kadis.jpg" alt="Kepala Dinas Perikanan"></div>
        <div class="leader-info">
          <span class="role">Kepala Dinas</span>
          <h3><?= e(NAMA_KEPALA) ?></h3>
          <div class="inst"><?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?></div>
        </div>
      </div>
    </div>

    <div class="divider"></div>

    <!-- Visi & Misi -->
    <div class="section-head center">
      <span class="section-tag">Visi &amp; Misi</span>
      <h2 class="section-title">Arah dan Tujuan Pembangunan Perikanan</h2>
    </div>
    <div class="grid grid-2" style="align-items:stretch;">
      <div class="visi-card">
        <h3><?= icon('waves', 18) ?> Visi</h3>
        <p>“Mewujudkan Senyum Halmahera Selatan yang Adil, Maju dan Berkelanjutan Berbasis Agromaritim dalam Bingkai Saruma Penuh Berkah”</p>
      </div>
      <div class="misi-card">
        <h3><?= icon('list', 18) ?> Misi</h3>
        <ol>
          <li>Transformasi Senyum Unggul Berdaya</li>
          <li>Transformasi Senyum Maju Berkelanjutan</li>
          <li>Transformasi Senyum Produktif Sejahtera</li>
          <li>Transformasi Senyum Prima Bernilai</li>
          <li>Transformasi Senyum Saruma Tangguh</li>
        </ol>
      </div>
    </div>

    <div class="divider"></div>

    <!-- Tupoksi -->
    <div class="section-head center">
      <span class="section-tag">Tugas &amp; Fungsi</span>
      <h2 class="section-title">Tupoksi Dinas Perikanan</h2>
    </div>
    <div class="grid grid-2" style="align-items:start;">
      <div class="card">
        <h3 style="display:flex; align-items:center; gap:9px; font-size:17px;"><?= icon('file-text', 19) ?> Tugas Pokok</h3>
        <p style="margin-top:10px;">Melaksanakan urusan pemerintahan daerah di bidang kelautan dan perikanan berdasarkan asas otonomi dan tugas pembantuan, meliputi perikanan tangkap, perikanan budidaya, pengolahan dan pemasaran hasil perikanan, pengawasan sumber daya kelautan dan perikanan, serta pemberdayaan masyarakat pesisir.</p>
      </div>
      <div class="card">
        <h3 style="display:flex; align-items:center; gap:9px; font-size:17px;"><?= icon('list', 19) ?> Fungsi</h3>
        <ul class="tupoksi" style="list-style:none;">
          <li><span class="no">1</span><div><strong>Perumusan kebijakan</strong> teknis bidang kelautan dan perikanan.</div></li>
          <li><span class="no">2</span><div><strong>Pelaksanaan</strong> urusan perikanan tangkap, budidaya, pengolahan, dan pengawasan.</div></li>
          <li><span class="no">3</span><div><strong>Pembinaan dan pengawasan</strong> terhadap pelaku usaha perikanan.</div></li>
          <li><span class="no">4</span><div><strong>Pengelolaan data</strong> dan informasi statistik perikanan.</div></li>
          <li><span class="no">5</span><div><strong>Pemberdayaan</strong> nelayan, pembudidaya, dan pengolah ikan.</div></li>
        </ul>
      </div>
    </div>

    <div class="divider"></div>

    <!-- Struktur -->
    <div class="section-head center">
      <span class="section-tag">Organisasi</span>
      <h2 class="section-title">Struktur Organisasi</h2>
      <p class="section-sub">Susunan organisasi <?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?> berdasarkan peraturan daerah tentang kedudukan, susunan organisasi, tugas, dan fungsi perangkat daerah.</p>
    </div>
    <div class="card" style="padding:36px 28px;">
      <div class="struktur">
        <div class="struktur-box">Kepala Dinas<small><?= e(NAMA_KEPALA) ?></small></div>
        <div class="struktur-line"></div>
        <div class="struktur-box">Sekretariat<small>Kasubag Umum &amp; Keuangan serta Pejabat Fungsional</small></div>
        <div class="struktur-line"></div>
        <div class="struktur-grid">
          <div class="struktur-box">Bidang Perikanan Tangkap<small>Kelompok Jabatan Fungsional</small></div>
          <div class="struktur-box">Bidang Perikanan Budidaya<small>Kelompok Jabatan Fungsional</small></div>
          <div class="struktur-box">Bidang Pengolahan, Pemasaran &amp; Pengawasan Sumberdaya Perikanan<small>Kelompok Jabatan Fungsional</small></div>
        </div>
        <div class="struktur-line"></div>
        <div class="struktur-box sub">UPTD<small>Bertanggung jawab langsung kepada Kepala Dinas</small></div>
      </div>
    </div>

  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
