<?php
// ============================================================================
// Endpoint foto berita — melayani gambar dari kolom BLOB pada tabel berita.
// CATATAN platform: file statis yang dibuat saat runtime TIDAK dilayani oleh
// platform (selalu fallback HTML 200), sehingga foto berita disimpan di
// database SQLite dan disajikan melalui skrip ini.
// ============================================================================
require_once __DIR__ . '/lib/db.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) { http_response_code(404); exit('Not found'); }

$db = db();
$st = $db->prepare('SELECT foto FROM berita WHERE id = ? AND status = 1');
$st->execute([$id]);
$foto = $st->fetchColumn();

if (!$foto || !is_string($foto) || $foto === '') {
    http_response_code(404);
    exit('Not found');
}

// Deteksi tipe MIME dari magic bytes
$mime = 'application/octet-stream';
$head = substr($foto, 0, 12);
if (str_starts_with($foto, "\xFF\xD8\xFF")) {
    $mime = 'image/jpeg';
} elseif (str_starts_with($foto, "\x89PNG")) {
    $mime = 'image/png';
} elseif (str_starts_with($foto, 'GIF8')) {
    $mime = 'image/gif';
} elseif (str_starts_with($head, 'RIFF') && substr($head, 8, 4) === 'WEBP') {
    $mime = 'image/webp';
}

header('Content-Type: ' . $mime);
header('Cache-Control: public, max-age=3600');
header('Content-Length: ' . strlen($foto));
echo $foto;
exit;
