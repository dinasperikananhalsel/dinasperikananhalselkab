<?php
$base = '';
$pageTitle = 'Layanan';
$activeNav = 'layanan';
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/includes/header.php';

$pdo = db();
$layanan = $pdo->query('SELECT * FROM layanan ORDER BY urutan ASC')->fetchAll();

$faq = [
    [
        'q' => 'Apa saja syarat mengurus Surat Izin Penangkapan Ikan (SIPI)?',
        'a' => 'Pemohon menyiapkan fotokopi KTP, Surat Tanda Bukti Kepemilikan Kapal (STBKK), Surat Persetujuan Berlayar, surat permohonan bermaterai, serta pas foto 3x4. Pengurusan dilakukan di kantor Dinas Perikanan pada jam layanan.',
    ],
    [
        'q' => 'Apakah layanan Dinas Perikanan dikenakan biaya?',
        'a' => 'Sebagian besar layanan publik Dinas Perikanan tidak dipungut biaya (gratis). Untuk penerbitan SIPI berlaku ketentuan PNBP sesuai peraturan perundang-undangan yang berlaku.',
    ],
    [
        'q' => 'Bagaimana cara mendaftar sebagai peserta asuransi nelayan?',
        'a' => 'Nelayan kecil yang aktif melaut dapat mendaftar melalui kelompok nelayan masing-masing atau langsung ke kantor Dinas Perikanan dengan membawa fotokopi KTP dan surat keterangan dari kepala desa. Premi ditanggung pemerintah.',
    ],
    [
        'q' => 'Bagaimana cara mendapatkan bantuan benih ikan atau sarana budidaya?',
        'a' => 'Kelompok pembudidaya mengajukan proposal permohonan kepada Dinas Perikanan melalui penyuluh perikanan pendamping. Bantuan disalurkan berdasarkan prioritas, kelayakan, dan ketersediaan anggaran.',
    ],
    [
        'q' => 'Di mana dan kapan jam layanan Dinas Perikanan?',
        'a' => 'Layanan dibuka di kantor Dinas Perikanan Kabupaten Halmahera Selatan setiap hari kerja, ' . JAM_LAYANAN . '.',
    ],
    [
        'q' => 'Bagaimana jika menemukan dugaan pelanggaran di bidang perikanan?',
        'a' => 'Masyarakat dapat melaporkan melalui halaman Layanan Pengaduan pada situs ini atau langsung menghubungi Bidang Pengawasan dan Pemberdayaan Dinas Perikanan. Identitas pelapor dirahasiakan.',
    ],
];
?>

<div class="section" style="padding-top:44px;">
  <div class="container">
    <div class="section-head">
      <span class="section-tag">Layanan Publik</span>
      <h2 class="section-title">Layanan <?= e(SITE_NAME) ?></h2>
      <p class="section-sub">Informasi layanan perizinan, sertifikasi, pemberdayaan, dan pengaduan. Klik "Selengkapnya" pada setiap layanan untuk melihat persyaratan, waktu, dan biaya.</p>
    </div>

    <div class="grid grid-2" style="align-items:start;">
      <?php foreach ($layanan as $l): ?>
      <div class="card service-card" id="layanan-<?= (int)$l['id'] ?>">
        <span class="service-num"><?= str_pad((string)$l['urutan'], 2, '0', STR_PAD_LEFT) ?> · <?= e($l['kategori']) ?></span>
        <h3><?= e($l['nama']) ?></h3>
        <p><?= e($l['deskripsi']) ?></p>
        <details class="acc">
          <summary><?= icon('chevron-down', 17) ?> Persyaratan, waktu &amp; biaya</summary>
          <div class="acc-body">
            <?php if ($l['persyaratan']): ?>
              <strong>Persyaratan:</strong>
              <?php $syarat = array_filter(array_map('trim', explode("\n", $l['persyaratan']))); ?>
              <ul><?php foreach ($syarat as $s): ?><li><?= e($s) ?></li><?php endforeach; ?></ul>
            <?php endif; ?>
            <p><strong>Waktu penyelesaian:</strong> <?= e($l['waktu'] ?: '-') ?></p>
            <p><strong>Biaya:</strong> <?= e($l['biaya'] ?: '-') ?></p>
          </div>
        </details>
      </div>
      <?php endforeach; ?>
    </div>

    <div class="divider"></div>

    <div class="grid grid-2" style="align-items:start; gap:36px;">
      <div>
        <span class="section-tag">FAQ</span>
        <h2 class="section-title">Pertanyaan yang Sering Diajukan</h2>
        <p class="section-sub">Jawaban atas pertanyaan masyarakat yang paling sering diterima oleh layanan informasi Dinas Perikanan.</p>
      </div>
      <div>
        <?php foreach ($faq as $i => $f): ?>
        <details class="acc" style="margin-bottom:12px; background:#fff; border:1px solid var(--line); border-radius:12px; padding:14px 18px; box-shadow:var(--shadow);">
          <summary><?= icon('chevron-down', 17) ?> <?= e($f['q']) ?></summary>
          <div class="acc-body" style="background:var(--bg);"><?= e($f['a']) ?></div>
        </details>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="cta-band mt-32">
      <div>
        <h3>Butuh bantuan lebih lanjut?</h3>
        <p>Hubungi kami melalui halaman kontak, atau sampaikan pengaduan Anda agar segera ditindaklanjuti.</p>
      </div>
      <div class="cta-actions">
        <a class="btn btn-gold" href="<?= $site ?>kontak.php"><?= icon('send', 18) ?> Hubungi Kami</a>
        <a class="btn btn-outline" href="<?= $site ?>pengaduan.php"><?= icon('alert', 18) ?> Ajukan Pengaduan</a>
      </div>
    </div>

  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
