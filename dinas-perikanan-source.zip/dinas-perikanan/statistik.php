<?php
$base = '';
$pageTitle = 'Statistik';
$activeNav = 'statistik';
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/includes/header.php';

$pdo = db();
$statistik = $pdo->query('SELECT * FROM statistik ORDER BY tahun ASC')->fetchAll();
$tahunMax = $statistik ? max(array_column($statistik, 'tahun')) : 0;
$statTerbaru = null;
foreach ($statistik as $s) { if ((int)$s['tahun'] === $tahunMax) $statTerbaru = $s; }

// Tahun yang dipilih untuk komoditas unggulan (default: tahun terbaru)
$tahunKom = (int)get('tahun', 0);
$daftarTahun = array_column($statistik, 'tahun');
if (!in_array($tahunKom, $daftarTahun, true)) $tahunKom = $tahunMax;

$komoditas = $pdo->prepare('SELECT * FROM komoditas WHERE tahun = ? ORDER BY urutan ASC');
$komoditas->execute([$tahunKom]);
$komoditas = $komoditas->fetchAll();
$maxKom = $komoditas ? max(array_column($komoditas, 'tonase')) : 1;

$maxTangkap = $statistik ? max(array_column($statistik, 'tangkap_ton')) : 1;
$maxBudidaya = $statistik ? max(array_column($statistik, 'budidaya_ton')) : 1;

$total2024 = $statTerbaru ? ($statTerbaru['tangkap_ton'] + $statTerbaru['budidaya_ton']) : 0;
?>

<div class="section" style="padding-top:44px;">
  <div class="container">
    <div class="section-head">
      <span class="section-tag">Data &amp; Statistik</span>
      <h2 class="section-title">Statistik Perikanan <?= e(KODE_WILAYAH) ?></h2>
      <p class="section-sub">Data produksi perikanan tangkap, budidaya, nilai produksi, dan komoditas unggulan. Data diperbarui secara berkala oleh Seksi Data dan Statistik.</p>
    </div>

    <div class="kpi-grid" style="margin-bottom:26px;">
      <div class="kpi">
        <div class="kpi-icon navy"><?= icon('fish', 22) ?></div>
        <div><div class="kpi-num"><?= angka($total2024) ?><small style="font-size:13px"> ton</small></div><div class="kpi-label">Produksi total <?= e($tahunMax) ?></div></div>
      </div>
      <div class="kpi">
        <div class="kpi-icon gold"><?= icon('chart', 22) ?></div>
        <div><div class="kpi-num">Rp <?= angka($statTerbaru['nilai_miliar'] ?? 0) ?><small style="font-size:13px"> miliar</small></div><div class="kpi-label">Nilai produksi <?= e($tahunMax) ?></div></div>
      </div>
      <div class="kpi">
        <div class="kpi-icon teal"><?= icon('anchor', 22) ?></div>
        <div><div class="kpi-num"><?= angka($statTerbaru['tangkap_ton'] ?? 0) ?><small style="font-size:13px"> ton</small></div><div class="kpi-label">Perikanan tangkap <?= e($tahunMax) ?></div></div>
      </div>
      <div class="kpi">
        <div class="kpi-icon red"><?= icon('waves', 22) ?></div>
        <div><div class="kpi-num"><?= angka($statTerbaru['budidaya_ton'] ?? 0) ?><small style="font-size:13px"> ton</small></div><div class="kpi-label">Perikanan budidaya <?= e($tahunMax) ?></div></div>
      </div>
    </div>

    <div class="grid grid-2" style="align-items:start;">
      <div class="card chart-card">
        <h3>Perkembangan produksi (ton)</h3>
        <div class="chart-sub">Perbandingan perikanan tangkap dan budidaya per tahun</div>
        <div class="bars">
          <?php foreach ($statistik as $r):
              $hT = round($r['tangkap_ton'] / $maxTangkap * 100);
              $hB = round($r['budidaya_ton'] / $maxBudidaya * 100); ?>
          <div class="bar-group">
            <div class="bar-pair">
              <div class="bar tangkap" style="height:<?= max(4, $hT) ?>%"></div>
              <div class="bar budidaya" style="height:<?= max(4, $hB) ?>%"></div>
            </div>
            <div class="bar-x"><?= (int)$r['tahun'] ?></div>
          </div>
          <?php endforeach; ?>
        </div>
        <div class="legend">
          <span><i class="lg-tangkap"></i>Perikanan tangkap</span>
          <span><i class="lg-budidaya"></i>Perikanan budidaya</span>
        </div>
      </div>

      <div class="card chart-card">
        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:4px;">
          <h3 style="margin:0;">Komoditas unggulan <?= e($tahunKom) ?> (ton)</h3>
          <form method="get" action="<?= $site ?>statistik.php" style="display:flex; gap:6px; align-items:center;">
            <select name="tahun" onchange="this.form.submit()" style="padding:6px 10px; border:1.5px solid var(--line); border-radius:8px; font-family:inherit; font-size:13.5px; background:#fff;">
              <?php foreach (array_reverse($statistik) as $r): ?>
              <option value="<?= (int)$r['tahun'] ?>" <?= (int)$r['tahun'] === $tahunKom ? 'selected' : '' ?>>Tahun <?= (int)$r['tahun'] ?></option>
              <?php endforeach; ?>
            </select>
            <noscript><button class="btn btn-primary btn-sm" type="submit">Tampil</button></noscript>
          </form>
        </div>
        <div class="chart-sub">Komoditas dengan produksi terbesar pada tahun terpilih</div>
        <?php if ($komoditas): ?>
        <div class="hbars">
          <?php foreach ($komoditas as $i => $k):
              $w = min(100, max(6, round($k['tonase'] / $maxKom * 100))); ?>
          <div class="hbar-row">
            <span class="nama"><?= e($k['nama']) ?></span>
            <div class="hbar-track"><div class="hbar-fill" style="width:<?= $w ?>%"></div></div>
            <span class="nilai"><?= angka($k['tonase']) ?> ton</span>
          </div>
          <?php endforeach; ?>
        </div>
        <?php else: ?>
          <p style="color:var(--muted); font-size:14px; margin-top:8px;">Belum ada data komoditas untuk tahun <?= (int)$tahunKom ?>. Data dapat diinput melalui panel admin.</p>
        <?php endif; ?>
      </div>
    </div>

    <div class="mt-32">
      <div class="card" style="padding:0; overflow:hidden;">
        <div style="padding:22px 26px 0;">
          <h3 style="font-size:18px; color:var(--navy-900);">Data produksi per tahun</h3>
          <p style="font-size:13px; color:var(--muted); margin-top:2px;">Satuan: ton untuk produksi; Rp miliar untuk nilai produksi</p>
        </div>
        <div class="table-wrap" style="border:none; border-radius:0;">
          <table class="tbl">
            <thead>
              <tr>
                <th>Tahun</th>
                <th class="num">Perikanan Tangkap (ton)</th>
                <th class="num">Perikanan Budidaya (ton)</th>
                <th class="num">Total Produksi (ton)</th>
                <th class="num">Nilai Produksi (Rp miliar)</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach (array_reverse($statistik) as $r): ?>
              <tr>
                <td><strong><?= (int)$r['tahun'] ?></strong></td>
                <td class="num"><?= angka($r['tangkap_ton']) ?></td>
                <td class="num"><?= angka($r['budidaya_ton']) ?></td>
                <td class="num"><strong><?= angka($r['tangkap_ton'] + $r['budidaya_ton']) ?></strong></td>
                <td class="num"><?= angka($r['nilai_miliar']) ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
      <p class="form-note mt-8" style="color:var(--muted);">Sumber: data internal <?= e(SITE_NAME) ?>, diolah dari laporan statistik perikanan. Data bersifat indikatif dan dapat diperbarui.</p>
    </div>

    <div class="cta-band mt-32">
      <div>
        <h3>Membutuhkan data untuk penelitian atau kegiatan usaha?</h3>
        <p>Ajukan permohonan data melalui layanan pelayanan data dan statistik perikanan.</p>
      </div>
      <div class="cta-actions">
        <a class="btn btn-gold" href="<?= $site ?>layanan.php"><?= icon('list', 18) ?> Lihat Layanan</a>
        <a class="btn btn-outline" href="<?= $site ?>kontak.php"><?= icon('send', 18) ?> Hubungi Kami</a>
      </div>
    </div>

  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
