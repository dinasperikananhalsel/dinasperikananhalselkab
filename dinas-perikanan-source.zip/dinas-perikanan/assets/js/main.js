// Dinas Perikanan Kabupaten Halmahera Selatan — interaksi ringan
(function () {
  'use strict';

  // Toggle menu mobile
  var toggle = document.querySelector('.nav-toggle');
  var links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      links.classList.toggle('open');
    });
    document.addEventListener('click', function (e) {
      if (!toggle.contains(e.target) && !links.contains(e.target)) {
        links.classList.remove('open');
      }
    });
  }

  // Konfirmasi aksi hapus
  document.querySelectorAll('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      if (!window.confirm(f.getAttribute('data-confirm'))) e.preventDefault();
    });
  });

  // Auto-sembunyikan alert sukses setelah beberapa saat
  document.querySelectorAll('.alert:not(.alert-error)').forEach(function (a) {
    setTimeout(function () {
      a.style.transition = 'opacity .5s';
      a.style.opacity = '0';
      setTimeout(function () { a.remove(); }, 600);
    }, 6000);
  });

  // Lightbox galeri
  var lb = document.getElementById('lightbox');
  var lbImg = lb ? lb.querySelector('img') : null;
  var lbCap = lb ? lb.querySelector('.lightbox-caption') : null;
  var lbClose = lb ? lb.querySelector('.lightbox-close') : null;

  function tutupLightbox() {
    if (lb) lb.classList.remove('open');
    document.body.style.overflow = '';
  }

  if (lb && lbImg && lbClose) {
    document.querySelectorAll('.gal-item img').forEach(function (img) {
      img.addEventListener('click', function () {
        lbImg.src = img.getAttribute('data-full') || img.src;
        if (lbCap) {
          var fig = img.closest('.gal-item');
          lbCap.textContent = fig && fig.querySelector('figcaption strong')
            ? fig.querySelector('figcaption strong').textContent : '';
        }
        lb.classList.add('open');
        document.body.style.overflow = 'hidden';
      });
    });
    lbClose.addEventListener('click', tutupLightbox);
    lb.addEventListener('click', function (e) { if (e.target === lb) tutupLightbox(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') tutupLightbox(); });
  }
})();
