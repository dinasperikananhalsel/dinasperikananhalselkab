<?php
$activeAdmin = 'statistik';
$pageTitle = 'Kelola Statistik';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../lib/db.php';

$pdo = db();
$aksi = (string)get('aksi', '');

// ---------- Simpan / edit data tahun ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $aksi === 'simpan_tahun') {
    csrf_check();
    $id      = (int)post('id', 0);
    $tahun   = (int)post('tahun', 0);
    $tangkap = (float)str_replace(',', '.', (string)post('tangkap_ton', 0));
    $budidaya= (float)str_replace(',', '.', (string)post('budidaya_ton', 0));
    $nilai   = (float)str_replace(',', '.', (string)post('nilai_miliar', 0));

    if ($tahun < 1990 || $tahun > 2100) {
        flash('Tahun tidak valid.', 'error');
        redirect('statistik.php');
    }
    try {
        if ($id > 0) {
            $st = $pdo->prepare('UPDATE statistik SET tahun = ?, tangkap_ton = ?, budidaya_ton = ?, nilai_miliar = ? WHERE id = ?');
            $st->execute([$tahun, $tangkap, $budidaya, $nilai, $id]);
            flash('Data tahun ' . $tahun . ' berhasil diperbarui.');
        } else {
            $st = $pdo->prepare('INSERT INTO statistik (tahun, tangkap_ton, budidaya_ton, nilai_miliar) VALUES (?, ?, ?, ?)');
            $st->execute([$tahun, $tangkap, $budidaya, $nilai]);
            flash('Data tahun ' . $tahun . ' berhasil ditambahkan.');
        }
    } catch (PDOException $ex) {
        flash('Gagal menyimpan: tahun ' . $tahun . ' sudah ada.', 'error');
    }
    redirect('statistik.php');
}

if ($aksi === 'hapus_tahun') {
    csrf_check_q();
    $id = (int)get('id', 0);
    $st = $pdo->prepare('SELECT tahun FROM statistik WHERE id = ?');
    $st->execute([$id]);
    $tahun = (int)$st->fetchColumn();
    $pdo->prepare('DELETE FROM statistik WHERE id = ?')->execute([$id]);
    if ($tahun > 0) {
        $pdo->prepare('DELETE FROM komoditas WHERE tahun = ?')->execute([$tahun]);
    }
    flash('Data tahun berhasil dihapus beserta komoditasnya.');
    redirect('statistik.php');
}

// ---------- Simpan / edit komoditas ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $aksi === 'simpan_kom') {
    csrf_check();
    $id     = (int)post('id', 0);
    $tahun  = (int)post('tahun', 0);
    $nama   = trim((string)post('nama'));
    $tonase = (float)str_replace(',', '.', (string)post('tonase', 0));
    $urutan = (int)post('urutan', 0);

    if ($nama === '') {
        flash('Nama komoditas wajib diisi.', 'error');
        redirect('statistik.php');
    }
    if ($id > 0) {
        $st = $pdo->prepare('UPDATE komoditas SET tahun = ?, nama = ?, tonase = ?, urutan = ? WHERE id = ?');
        $st->execute([$tahun, $nama, $tonase, $urutan, $id]);
        flash('Komoditas berhasil diperbarui.');
    } else {
        $st = $pdo->prepare('INSERT INTO komoditas (tahun, nama, tonase, urutan) VALUES (?, ?, ?, ?)');
        $st->execute([$tahun, $nama, $tonase, $urutan]);
        flash('Komoditas berhasil ditambahkan.');
    }
    redirect('statistik.php');
}

if ($aksi === 'hapus_kom') {
    csrf_check_q();
    $pdo->prepare('DELETE FROM komoditas WHERE id = ?')->execute([(int)get('id', 0)]);
    flash('Komoditas berhasil dihapus.');
    redirect('statistik.php');
}

// ---------- Data untuk tampilan ----------
$statistik = $pdo->query('SELECT * FROM statistik ORDER BY tahun DESC')->fetchAll();
$tahunTersedia = array_map(fn($r) => (int)$r['tahun'], $statistik);
// Tahun terpilih: dari query string (?tahun=) jika valid, selain itu tahun terbaru
$tahunReq = (int)get('tahun', 0);
if ($tahunReq > 0 && in_array($tahunReq, $tahunTersedia, true)) {
    $tahunPilih = $tahunReq;
} else {
    $tahunPilih = $tahunTersedia[0] ?? date('Y');
}

$editTahun = null;
$editKom = null;
if ($aksi === 'edit_tahun') {
    $st = $pdo->prepare('SELECT * FROM statistik WHERE id = ?');
    $st->execute([(int)get('id', 0)]);
    $editTahun = $st->fetch();
}
if ($aksi === 'edit_kom') {
    $st = $pdo->prepare('SELECT * FROM komoditas WHERE id = ?');
    $st->execute([(int)get('id', 0)]);
    $editKom = $st->fetch();
}

$komoditas = $pdo->prepare('SELECT * FROM komoditas WHERE tahun = ? ORDER BY urutan ASC');
$komoditas->execute([$tahunPilih]);
$komoditas = $komoditas->fetchAll();
?>

<!-- ============ DATA TAHUN ============ -->
<div class="admin-tools">
  <h3 style="font-size:16px; color:var(--navy-900); margin:0;">Data Produksi per Tahun</h3>
  <span class="form-note"><?= count($statistik) ?> tahun terdata</span>
</div>

<?php if ($editTahun): ?>
<div class="admin-card">
  <h3>Edit Data Tahun <?= (int)$editTahun['tahun'] ?></h3>
  <form method="post" action="statistik.php?aksi=simpan_tahun">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)$editTahun['id'] ?>">
    <div class="form-grid">
      <div class="field"><label for="tahun">Tahun</label><input type="number" id="tahun" name="tahun" required min="1990" max="2100" value="<?= (int)$editTahun['tahun'] ?>"></div>
      <div class="field"><label for="tangkap_ton">Tangkap (ton)</label><input type="number" step="0.1" id="tangkap_ton" name="tangkap_ton" value="<?= e($editTahun['tangkap_ton']) ?>"></div>
      <div class="field"><label for="budidaya_ton">Budidaya (ton)</label><input type="number" step="0.1" id="budidaya_ton" name="budidaya_ton" value="<?= e($editTahun['budidaya_ton']) ?>"></div>
      <div class="field"><label for="nilai_miliar">Nilai Produksi (Rp miliar)</label><input type="number" step="0.1" id="nilai_miliar" name="nilai_miliar" value="<?= e($editTahun['nilai_miliar']) ?>"></div>
    </div>
    <button type="submit" class="btn btn-primary mt-16"><?= icon('check-circle', 17) ?> Simpan Perubahan</button>
    <a class="btn btn-outline-navy btn-sm mt-16" href="statistik.php">Batal</a>
  </form>
</div>
<?php else: ?>
<div class="admin-card">
  <h3 style="display:flex; align-items:center; gap:8px;"><?= icon('plus', 17) ?> Tambah Data Tahun Baru</h3>
  <form method="post" action="statistik.php?aksi=simpan_tahun" class="mt-8">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="0">
    <div class="form-grid">
      <div class="field"><label for="tahun_baru">Tahun <span class="req">*</span></label><input type="number" id="tahun_baru" name="tahun" required min="1990" max="2100" placeholder="mis. 2025" value="<?= date('Y') ?>"></div>
      <div class="field"><label for="tangkap_baru">Perikanan Tangkap (ton)</label><input type="number" step="0.1" id="tangkap_baru" name="tangkap_ton" placeholder="0" value="0"></div>
      <div class="field"><label for="budidaya_baru">Perikanan Budidaya (ton)</label><input type="number" step="0.1" id="budidaya_baru" name="budidaya_ton" placeholder="0" value="0"></div>
      <div class="field"><label for="nilai_baru">Nilai Produksi (Rp miliar)</label><input type="number" step="0.1" id="nilai_baru" name="nilai_miliar" placeholder="0" value="0"></div>
    </div>
    <button type="submit" class="btn btn-primary mt-16"><?= icon('plus', 16) ?> Simpan Data Tahun</button>
  </form>
</div>
<?php endif; ?>

<div class="admin-card" style="padding:0; overflow:hidden;">
  <div class="table-wrap" style="border:none; border-radius:0;">
    <table class="tbl">
      <thead>
        <tr>
          <th>Tahun</th>
          <th class="num">Tangkap (ton)</th>
          <th class="num">Budidaya (ton)</th>
          <th class="num">Nilai (Rp miliar)</th>
          <th style="text-align:right;">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($statistik as $s): ?>
        <tr>
          <td><strong><?= (int)$s['tahun'] ?></strong></td>
          <td class="num"><?= angka($s['tangkap_ton']) ?></td>
          <td class="num"><?= angka($s['budidaya_ton']) ?></td>
          <td class="num"><?= angka($s['nilai_miliar']) ?></td>
          <td>
            <div class="row-actions" style="justify-content:flex-end;">
              <a href="statistik.php?aksi=edit_tahun&id=<?= (int)$s['id'] ?>" title="Edit"><?= icon('edit', 15) ?></a>
              <form method="post" action="statistik.php?aksi=hapus_tahun&id=<?= (int)$s['id'] ?>&csrf=<?= e(csrf_token()) ?>" data-confirm="Hapus data tahun <?= (int)$s['tahun'] ?>?">
                <button type="submit" class="del" title="Hapus"><?= icon('trash', 15) ?></button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$statistik): ?>
        <tr><td colspan="5" style="text-align:center; color:var(--muted); padding:26px;">Belum ada data statistik.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ============ KOMODITAS ============ -->
<div class="admin-tools mt-32">
  <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
    <h3 style="font-size:16px; color:var(--navy-900); margin:0;">Komoditas Unggulan</h3>
    <form method="get" action="statistik.php" style="display:flex; gap:8px; align-items:center;">
      <select name="tahun" onchange="this.form.submit()" style="padding:8px 12px; border:1.5px solid var(--line); border-radius:8px; font-family:inherit; font-size:14px;">
        <?php foreach ($tahunTersedia as $t): ?>
        <option value="<?= $t ?>" <?= $t === $tahunPilih ? 'selected' : '' ?>><?= $t ?></option>
        <?php endforeach; ?>
      </select>
      <noscript><button class="btn btn-primary btn-sm" type="submit">Tampil</button></noscript>
    </form>
    <a class="btn btn-primary btn-sm" href="statistik.php?aksi=edit_kom&tahun=<?= $tahunPilih ?>"><?= icon('plus', 16) ?> Tambah Komoditas</a>
    <?php if ($editKom || $aksi === 'edit_kom'): ?><a class="btn btn-outline-navy btn-sm" href="statistik.php">Batal</a><?php endif; ?>
  </div>
</div>

<?php if ($editKom || $aksi === 'edit_kom'): ?>
<div class="admin-card">
  <h3><?= $editKom ? 'Edit Komoditas #' . (int)$editKom['id'] : 'Tambah Komoditas' ?></h3>
  <form method="post" action="statistik.php?aksi=simpan_kom">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)($editKom['id'] ?? 0) ?>">
    <div class="form-grid">
      <div class="field">
        <label for="kom_tahun">Tahun <span class="req">*</span></label>
        <select id="kom_tahun" name="tahun">
          <?php foreach ($tahunTersedia as $t): ?>
          <option value="<?= $t ?>" <?= ($editKom['tahun'] ?? $tahunPilih) == $t ? 'selected' : '' ?>><?= $t ?></option>
          <?php endforeach; ?>
        </select>
        <span class="form-note">Pilih tahun untuk data komoditas ini.</span>
      </div>
      <div class="field"><label for="nama">Nama Komoditas <span class="req">*</span></label><input type="text" id="nama" name="nama" required maxlength="80" value="<?= e($editKom['nama'] ?? '') ?>"></div>
      <div class="field"><label for="tonase">Tonase (ton)</label><input type="number" step="0.1" id="tonase" name="tonase" value="<?= e($editKom['tonase'] ?? '') ?>"></div>
      <div class="field"><label for="urutan">Urutan</label><input type="number" id="urutan" name="urutan" value="<?= (int)($editKom['urutan'] ?? 0) ?>"></div>
    </div>
    <button type="submit" class="btn btn-primary mt-16"><?= icon('check-circle', 17) ?> Simpan</button>
  </form>
</div>
<?php endif; ?>

<div class="admin-card" style="padding:0; overflow:hidden;">
  <div style="padding:14px 18px 0; font-size:13px; color:var(--muted);">Menampilkan komoditas unggulan tahun <strong style="color:var(--navy-900);"><?= (int)$tahunPilih ?></strong></div>
  <div class="table-wrap" style="border:none; border-radius:0;">
    <table class="tbl">
      <thead>
        <tr><th>#</th><th>Komoditas</th><th class="num">Tonase (ton)</th><th style="text-align:right;">Aksi</th></tr>
      </thead>
      <tbody>
        <?php foreach ($komoditas as $k): ?>
        <tr>
          <td><?= (int)$k['urutan'] ?></td>
          <td><strong><?= e($k['nama']) ?></strong></td>
          <td class="num"><?= angka($k['tonase']) ?></td>
          <td>
            <div class="row-actions" style="justify-content:flex-end;">
              <a href="statistik.php?aksi=edit_kom&id=<?= (int)$k['id'] ?>" title="Edit"><?= icon('edit', 15) ?></a>
              <form method="post" action="statistik.php?aksi=hapus_kom&id=<?= (int)$k['id'] ?>&csrf=<?= e(csrf_token()) ?>" data-confirm="Hapus komoditas <?= e($k['nama']) ?>?">
                <button type="submit" class="del" title="Hapus"><?= icon('trash', 15) ?></button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$komoditas): ?>
        <tr><td colspan="4" style="text-align:center; color:var(--muted); padding:26px;">Belum ada komoditas untuk tahun <?= (int)$tahunPilih ?>.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
