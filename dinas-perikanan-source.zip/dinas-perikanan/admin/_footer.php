    </div><!-- /.admin-content -->
  </div><!-- /.admin-main -->
</div><!-- /.admin-shell -->
<script src="../assets/js/main.js"></script>
</body>
</html>
