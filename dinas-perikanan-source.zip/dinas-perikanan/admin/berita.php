<?php
$activeAdmin = 'berita';
$pageTitle = 'Kelola Berita';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../lib/db.php';

$pdo = db();
$kategoris = ['Kegiatan', 'Pengumuman', 'Program', 'Prestasi'];
$edit = null;
$formData = ['id' => 0, 'judul' => '', 'kategori' => 'Kegiatan', 'penulis' => 'Humas Dinas Perikanan',
             'tanggal' => date('Y-m-d H:i'), 'ringkasan' => '', 'isi' => '', 'status' => 1, 'foto' => ''];

/** Baca & validasi unggahan foto berita. Mengembalikan isi biner gambar ('' jika tidak ada file). */
function baca_foto_upload(array $file, &$err): string
{
    $file += ['error' => UPLOAD_ERR_NO_FILE, 'size' => 0, 'tmp_name' => ''];
    if ((int)$file['error'] === UPLOAD_ERR_NO_FILE) return ''; // tidak ada file yang diunggah
    if ((int)$file['error'] !== UPLOAD_ERR_OK) {
        $err = pesan_error_upload((int)$file['error']);
        return '';
    }
    if ((int)$file['size'] > 3 * 1024 * 1024) { $err = 'Ukuran foto maksimal 3 MB.'; return ''; }
    $tmp = $file['tmp_name'] ?? '';
    if ($tmp === '' || !is_uploaded_file($tmp)) { $err = 'File foto tidak valid.'; return ''; }
    $info = @getimagesize($tmp);
    if ($info === false) { $err = 'File harus berupa gambar (JPG/PNG/WebP/GIF).'; return ''; }
    $extMap = ['image/jpeg' => true, 'image/png' => true, 'image/webp' => true, 'image/gif' => true];
    if (!isset($extMap[$info['mime']])) { $err = 'Format gambar tidak didukung (JPG/PNG/WebP/GIF).'; return ''; }
    $isi = file_get_contents($tmp);
    if ($isi === false || $isi === '') { $err = 'Gagal membaca foto.'; return ''; }
    return $isi;
}

// ---------- Proses aksi ----------
$aksi = (string)get('aksi', '');
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $aksi === 'simpan') {
    csrf_check();
    $d = $formData;
    $d['id']        = (int)post('id', 0);
    $d['judul']     = trim((string)post('judul'));
    $d['kategori']  = in_array(post('kategori'), $kategoris, true) ? post('kategori') : 'Kegiatan';
    $d['penulis']   = trim((string)post('penulis')) ?: 'Humas Dinas Perikanan';
    $d['tanggal']   = trim((string)post('tanggal'));
    $d['ringkasan'] = trim((string)post('ringkasan'));
    $d['isi']       = trim((string)post('isi'));
    $d['status']    = isset($_POST['status']) ? 1 : 0;

    if ($d['judul'] === '' || $d['isi'] === '') {
        flash('Judul dan isi berita wajib diisi.', 'error');
        redirect('berita.php');
    }
    if ($d['tanggal'] === '') $d['tanggal'] = date('Y-m-d H:i');
    $d['tanggal'] = str_replace('T', ' ', $d['tanggal']);

    // Foto lama (saat edit)
    $fotoLama = '';
    if ($d['id'] > 0) {
        $st = $pdo->prepare('SELECT foto FROM berita WHERE id = ?');
        $st->execute([$d['id']]);
        $fotoLama = (string)$st->fetchColumn();
    }

    // Proses foto baru / hapus foto (foto disimpan sebagai BLOB di database)
    $errFoto = '';
    $fotoBaru = baca_foto_upload($_FILES['foto'] ?? ['error' => UPLOAD_ERR_NO_FILE], $errFoto);
    if ($errFoto !== '') {
        flash($errFoto, 'error');
        redirect('berita.php');
    }
    if ($fotoBaru !== '') {
        $d['foto'] = $fotoBaru;
    } elseif (isset($_POST['hapus_foto'])) {
        $d['foto'] = '';
    } else {
        $d['foto'] = $fotoLama;
    }

    if ($d['id'] > 0) {
        $st = $pdo->prepare('UPDATE berita SET judul = ?, ringkasan = ?, isi = ?, kategori = ?, penulis = ?, tanggal = ?, status = ?, foto = ? WHERE id = ?');
        $st->bindValue(1, $d['judul']);
        $st->bindValue(2, $d['ringkasan']);
        $st->bindValue(3, $d['isi']);
        $st->bindValue(4, $d['kategori']);
        $st->bindValue(5, $d['penulis']);
        $st->bindValue(6, $d['tanggal']);
        $st->bindValue(7, $d['status'], PDO::PARAM_INT);
        $st->bindValue(8, $d['foto'], $d['foto'] === '' ? PDO::PARAM_STR : PDO::PARAM_LOB);
        $st->bindValue(9, $d['id'], PDO::PARAM_INT);
        $st->execute();
        flash('Berita berhasil diperbarui.');
    } else {
        $st = $pdo->prepare('INSERT INTO berita (judul, ringkasan, isi, kategori, penulis, tanggal, status, foto) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $st->bindValue(1, $d['judul']);
        $st->bindValue(2, $d['ringkasan']);
        $st->bindValue(3, $d['isi']);
        $st->bindValue(4, $d['kategori']);
        $st->bindValue(5, $d['penulis']);
        $st->bindValue(6, $d['tanggal']);
        $st->bindValue(7, $d['status'], PDO::PARAM_INT);
        $st->bindValue(8, $d['foto'], $d['foto'] === '' ? PDO::PARAM_STR : PDO::PARAM_LOB);
        $st->execute();
        flash('Berita baru berhasil disimpan.');
    }
    redirect('berita.php');
}

if ($aksi === 'hapus') {
    csrf_check_q();
    $pdo->prepare('DELETE FROM berita WHERE id = ?')->execute([(int)get('id', 0)]);
    flash('Berita berhasil dihapus.');
    redirect('berita.php');
}

if ($aksi === 'toggle') {
    csrf_check_q();
    $pdo->prepare('UPDATE berita SET status = CASE status WHEN 1 THEN 0 ELSE 1 END WHERE id = ?')->execute([(int)get('id', 0)]);
    flash('Status publikasi berita diubah.');
    redirect('berita.php');
}

// ---------- Mode edit ----------
if ($aksi === 'edit') {
    $st = $pdo->prepare('SELECT * FROM berita WHERE id = ?');
    $st->execute([(int)get('id', 0)]);
    $edit = $st->fetch();
    if ($edit) {
        $formData = $edit;
        $formData['tanggal'] = date('Y-m-d\TH:i', strtotime($edit['tanggal']));
    }
}

$berita = $pdo->query('SELECT * FROM berita ORDER BY tanggal DESC')->fetchAll();
?>

<div class="admin-tools">
  <a class="btn btn-primary btn-sm" href="berita.php?aksi=edit"><?= icon('plus', 16) ?> Tambah Berita</a>
  <?php if ($edit): ?><a class="btn btn-outline-navy btn-sm" href="berita.php">Batal edit</a><?php endif; ?>
  <span class="form-note"><?= count($berita) ?> berita tersimpan</span>
</div>

<?php if ($edit || get('aksi') === 'edit'): ?>
<div class="admin-card">
  <h3><?= $edit ? 'Edit Berita #' . (int)$edit['id'] : 'Tambah Berita Baru' ?></h3>
  <form method="post" action="berita.php?aksi=simpan" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)$formData['id'] ?>">
    <div class="form-grid">
      <div class="field full">
        <label for="judul">Judul Berita <span class="req">*</span></label>
        <input type="text" id="judul" name="judul" required maxlength="255" value="<?= e($formData['judul']) ?>">
      </div>
      <div class="field">
        <label for="kategori">Kategori</label>
        <select id="kategori" name="kategori">
          <?php foreach ($kategoris as $k): ?>
          <option value="<?= e($k) ?>" <?= $formData['kategori'] === $k ? 'selected' : '' ?>><?= e($k) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label for="penulis">Penulis</label>
        <input type="text" id="penulis" name="penulis" maxlength="120" value="<?= e($formData['penulis']) ?>">
      </div>
      <div class="field full">
        <label for="tanggal">Tanggal &amp; Jam Publikasi</label>
        <input type="datetime-local" id="tanggal" name="tanggal" value="<?= e($formData['tanggal']) ?>">
      </div>
      <div class="field full">
        <label for="ringkasan">Ringkasan (opsional)</label>
        <textarea id="ringkasan" name="ringkasan" maxlength="500" rows="2"><?= e($formData['ringkasan']) ?></textarea>
        <span class="form-note">Tampil di halaman daftar berita. Jika kosong, ringkasan diambil otomatis dari isi berita.</span>
      </div>
      <div class="field full">
        <label for="foto">Foto Berita</label>
        <input type="file" id="foto" name="foto" accept="image/jpeg,image/png,image/webp,image/gif">
        <span class="form-note">Format JPG, PNG, WebP, atau GIF — maksimal 3 MB. Jika tidak dipilih, berita memakai ikon bawaan. Ganti foto = unggah file baru; hapus foto = centang di bawah.</span>
        <?php if (!empty($formData['foto']) && !empty($formData['id'])): ?>
        <div style="display:flex; gap:14px; align-items:center; margin-top:10px; flex-wrap:wrap;">
          <img src="../foto-berita.php?id=<?= (int)$formData['id'] ?>" alt="Foto berita saat ini" style="height:86px; max-width:180px; object-fit:cover; border-radius:10px; border:1px solid var(--line); box-shadow:var(--shadow);">
          <label style="font-weight:600; font-size:14px; display:flex; gap:7px; align-items:center; cursor:pointer; color:var(--navy-800);">
            <input type="checkbox" name="hapus_foto" value="1" style="width:17px;height:17px;"> Hapus foto ini
          </label>
        </div>
        <?php endif; ?>
      </div>
      <div class="field full">
        <label for="isi">Isi Berita <span class="req">*</span></label>
        <textarea id="isi" name="isi" required maxlength="20000" rows="12"><?= e($formData['isi']) ?></textarea>
        <span class="form-note">Pisahkan paragraf dengan baris kosong.</span>
      </div>
      <div class="field full">
        <label style="flex-direction:row; gap:8px; align-items:center; cursor:pointer;">
          <input type="checkbox" name="status" value="1" style="width:18px;height:18px;" <?= (int)$formData['status'] === 1 ? 'checked' : '' ?>>
          Publikasikan di situs
        </label>
      </div>
    </div>
    <button type="submit" class="btn btn-primary mt-16"><?= icon('check-circle', 17) ?> Simpan Berita</button>
  </form>
</div>
<?php endif; ?>

<div class="admin-card" style="padding:0; overflow:hidden;">
  <div class="table-wrap" style="border:none; border-radius:0;">
    <table class="tbl">
      <thead>
        <tr>
          <th>ID</th>
          <th>Foto</th>
          <th>Judul</th>
          <th>Kategori</th>
          <th>Tanggal</th>
          <th>Dilihat</th>
          <th>Status</th>
          <th style="text-align:right;">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($berita as $b): ?>
        <tr>
          <td><?= (int)$b['id'] ?></td>
          <td>
            <?php if (!empty($b['foto'])): ?>
              <img src="../foto-berita.php?id=<?= (int)$b['id'] ?>" alt="" style="width:56px; height:40px; object-fit:cover; border-radius:6px; border:1px solid var(--line);">
            <?php else: ?>
              <span style="color:#b9c4d0; font-size:12px;">—</span>
            <?php endif; ?>
          </td>
          <td style="max-width:300px;"><a href="../berita.php?id=<?= (int)$b['id'] ?>" target="_blank"><?= e(potong($b['judul'], 60)) ?></a></td>
          <td><span class="badge"><?= e($b['kategori']) ?></span></td>
          <td class="num" style="white-space:nowrap;"><?= e(tanggal_id($b['tanggal'], true)) ?></td>
          <td class="num"><?= (int)$b['dilihat'] ?></td>
          <td>
            <?php if ((int)$b['status'] === 1): ?>
              <span class="status-pill aktif">Aktif</span>
            <?php else: ?>
              <span class="status-pill baru">Draf</span>
            <?php endif; ?>
          </td>
          <td>
            <div class="row-actions" style="justify-content:flex-end;">
              <a href="berita.php?aksi=edit&id=<?= (int)$b['id'] ?>" title="Edit"><?= icon('edit', 15) ?></a>
              <a href="berita.php?aksi=toggle&id=<?= (int)$b['id'] ?>&csrf=<?= e(csrf_token()) ?>" title="<?= (int)$b['status'] === 1 ? 'Jadikan draf' : 'Publikasikan' ?>">
                <?= icon((int)$b['status'] === 1 ? 'chevron-down' : 'check-circle', 15) ?>
              </a>
              <form method="post" action="berita.php?aksi=hapus&id=<?= (int)$b['id'] ?>&csrf=<?= e(csrf_token()) ?>" data-confirm="Hapus berita ini?">
                <button type="submit" class="del" title="Hapus"><?= icon('trash', 15) ?></button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$berita): ?>
        <tr><td colspan="8" style="text-align:center; color:var(--muted); padding:26px;">Belum ada berita.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
