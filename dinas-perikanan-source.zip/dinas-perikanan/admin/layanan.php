<?php
$activeAdmin = 'layanan';
$pageTitle = 'Kelola Layanan';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../lib/db.php';

$pdo = db();
$aksi = (string)get('aksi', '');
$kategoris = ['Perizinan', 'Sertifikasi', 'Pemberdayaan', 'Informasi', 'Lainnya'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $aksi === 'simpan') {
    csrf_check();
    $d = [
        'id'           => (int)post('id', 0),
        'nama'         => trim((string)post('nama')),
        'kategori'     => in_array(post('kategori'), $kategoris, true) ? post('kategori') : 'Lainnya',
        'deskripsi'    => trim((string)post('deskripsi')),
        'persyaratan'  => trim((string)post('persyaratan')),
        'waktu'        => trim((string)post('waktu')),
        'biaya'        => trim((string)post('biaya')),
        'urutan'       => (int)post('urutan', 0),
    ];
    if ($d['nama'] === '') {
        flash('Nama layanan wajib diisi.', 'error');
        redirect('layanan.php');
    }
    if ($d['id'] > 0) {
        $st = $pdo->prepare('UPDATE layanan SET nama = ?, kategori = ?, deskripsi = ?, persyaratan = ?, waktu = ?, biaya = ?, urutan = ? WHERE id = ?');
        $st->execute([$d['nama'], $d['kategori'], $d['deskripsi'], $d['persyaratan'], $d['waktu'], $d['biaya'], $d['urutan'], $d['id']]);
        flash('Layanan berhasil diperbarui.');
    } else {
        $st = $pdo->prepare('INSERT INTO layanan (nama, kategori, deskripsi, persyaratan, waktu, biaya, urutan) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $st->execute([$d['nama'], $d['kategori'], $d['deskripsi'], $d['persyaratan'], $d['waktu'], $d['biaya'], $d['urutan']]);
        flash('Layanan baru berhasil disimpan.');
    }
    redirect('layanan.php');
}

if ($aksi === 'hapus') {
    csrf_check_q();
    $pdo->prepare('DELETE FROM layanan WHERE id = ?')->execute([(int)get('id', 0)]);
    flash('Layanan berhasil dihapus.');
    redirect('layanan.php');
}

$edit = null;
if ($aksi === 'edit') {
    $st = $pdo->prepare('SELECT * FROM layanan WHERE id = ?');
    $st->execute([(int)get('id', 0)]);
    $edit = $st->fetch();
}

$layanan = $pdo->query('SELECT * FROM layanan ORDER BY urutan ASC')->fetchAll();
?>

<div class="admin-tools">
  <a class="btn btn-primary btn-sm" href="layanan.php?aksi=edit"><?= icon('plus', 16) ?> Tambah Layanan</a>
  <?php if ($edit): ?><a class="btn btn-outline-navy btn-sm" href="layanan.php">Batal edit</a><?php endif; ?>
  <span class="form-note"><?= count($layanan) ?> layanan tersimpan</span>
</div>

<?php if ($edit || get('aksi') === 'edit'): ?>
<div class="admin-card">
  <h3><?= $edit ? 'Edit Layanan #' . (int)$edit['id'] : 'Tambah Layanan Baru' ?></h3>
  <form method="post" action="layanan.php?aksi=simpan">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
    <div class="form-grid">
      <div class="field full">
        <label for="nama">Nama Layanan <span class="req">*</span></label>
        <input type="text" id="nama" name="nama" required maxlength="180" value="<?= e($edit['nama'] ?? '') ?>">
      </div>
      <div class="field">
        <label for="kategori">Kategori</label>
        <select id="kategori" name="kategori">
          <?php foreach ($kategoris as $k): ?>
          <option value="<?= e($k) ?>" <?= ($edit['kategori'] ?? '') === $k ? 'selected' : '' ?>><?= e($k) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label for="urutan">Urutan Tampil</label>
        <input type="number" id="urutan" name="urutan" min="1" value="<?= (int)($edit['urutan'] ?? 0) ?>">
      </div>
      <div class="field full">
        <label for="deskripsi">Deskripsi</label>
        <textarea id="deskripsi" name="deskripsi" maxlength="1000" rows="3"><?= e($edit['deskripsi'] ?? '') ?></textarea>
      </div>
      <div class="field full">
        <label for="persyaratan">Persyaratan</label>
        <textarea id="persyaratan" name="persyaratan" maxlength="3000" rows="5"><?= e($edit['persyaratan'] ?? '') ?></textarea>
        <span class="form-note">Tulis satu syarat per baris.</span>
      </div>
      <div class="field">
        <label for="waktu">Waktu Penyelesaian</label>
        <input type="text" id="waktu" name="waktu" maxlength="120" value="<?= e($edit['waktu'] ?? '') ?>">
      </div>
      <div class="field">
        <label for="biaya">Biaya</label>
        <input type="text" id="biaya" name="biaya" maxlength="120" value="<?= e($edit['biaya'] ?? '') ?>">
      </div>
    </div>
    <button type="submit" class="btn btn-primary mt-16"><?= icon('check-circle', 17) ?> Simpan Layanan</button>
  </form>
</div>
<?php endif; ?>

<div class="admin-card" style="padding:0; overflow:hidden;">
  <div class="table-wrap" style="border:none; border-radius:0;">
    <table class="tbl">
      <thead>
        <tr><th>Urutan</th><th>Nama Layanan</th><th>Kategori</th><th>Waktu</th><th style="text-align:right;">Aksi</th></tr>
      </thead>
      <tbody>
        <?php foreach ($layanan as $l): ?>
        <tr>
          <td><?= (int)$l['urutan'] ?></td>
          <td><strong><?= e($l['nama']) ?></strong></td>
          <td><span class="badge"><?= e($l['kategori']) ?></span></td>
          <td><?= e($l['waktu'] ?: '-') ?></td>
          <td>
            <div class="row-actions" style="justify-content:flex-end;">
              <a href="layanan.php?aksi=edit&id=<?= (int)$l['id'] ?>" title="Edit"><?= icon('edit', 15) ?></a>
              <form method="post" action="layanan.php?aksi=hapus&id=<?= (int)$l['id'] ?>&csrf=<?= e(csrf_token()) ?>" data-confirm="Hapus layanan ini?">
                <button type="submit" class="del" title="Hapus"><?= icon('trash', 15) ?></button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$layanan): ?>
        <tr><td colspan="5" style="text-align:center; color:var(--muted); padding:26px;">Belum ada layanan.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
