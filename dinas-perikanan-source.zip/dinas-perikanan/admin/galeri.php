<?php
$activeAdmin = 'galeri';
$pageTitle = 'Kelola Galeri';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../lib/db.php';

$pdo = db();
$aksi = (string)get('aksi', '');
$maxUkuran = 3 * 1024 * 1024; // 3 MB

/** Baca & validasi unggahan foto galeri. Mengembalikan [mime, isi] atau null (tidak ada file). */
function baca_foto_galeri(array $file, &$err): ?array
{
    global $maxUkuran;
    $file += ['error' => UPLOAD_ERR_NO_FILE, 'size' => 0, 'tmp_name' => ''];
    if ((int)$file['error'] === UPLOAD_ERR_NO_FILE) return null;
    if ((int)$file['error'] !== UPLOAD_ERR_OK) { $err = pesan_error_upload((int)$file['error']); return null; }
    if ((int)$file['size'] > $maxUkuran) { $err = 'Ukuran foto maksimal 3 MB.'; return null; }
    $tmp = $file['tmp_name'] ?? '';
    if ($tmp === '' || !is_uploaded_file($tmp)) { $err = 'File foto tidak valid.'; return null; }
    $info = @getimagesize($tmp);
    if ($info === false) { $err = 'File harus berupa gambar (JPG/PNG/WebP/GIF).'; return null; }
    $extMap = ['image/jpeg' => true, 'image/png' => true, 'image/webp' => true, 'image/gif' => true];
    if (!isset($extMap[$info['mime']])) { $err = 'Format gambar tidak didukung (JPG/PNG/WebP/GIF).'; return null; }
    $isi = file_get_contents($tmp);
    if ($isi === false || $isi === '') { $err = 'Gagal membaca foto.'; return null; }
    return ['mime' => $info['mime'], 'isi' => $isi];
}

// ---------- Simpan ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $aksi === 'simpan') {
    csrf_check();
    $id         = (int)post('id', 0);
    $judul      = trim((string)post('judul'));
    $deskripsi  = trim((string)post('deskripsi'));
    $urutan     = (int)post('urutan', 0);
    $status     = isset($_POST['status']) ? 1 : 0;
    $tanggal    = trim((string)post('tanggal'));

    if ($judul === '') {
        flash('Judul foto wajib diisi.', 'error');
        redirect('galeri.php');
    }

    $fotoLama = null;
    if ($id > 0) {
        $st = $pdo->prepare('SELECT * FROM galeri WHERE id = ?');
        $st->execute([$id]);
        $fotoLama = $st->fetch();
    }

    $errFoto = '';
    $upload = baca_foto_galeri($_FILES['foto'] ?? ['error' => UPLOAD_ERR_NO_FILE], $errFoto);
    if ($errFoto !== '') {
        flash($errFoto, 'error');
        redirect('galeri.php');
    }

    if ($upload !== null) {
        $mime = $upload['mime'];
        $isi = $upload['isi'];
        $ukuran = strlen($isi);
    } elseif ($fotoLama && !isset($_POST['hapus_foto'])) {
        $mime = $fotoLama['mime'];
        $isi = $fotoLama['isi'];
        $ukuran = (int)$fotoLama['ukuran'];
    } else {
        $mime = 'image/jpeg';
        $isi = '';
        $ukuran = 0;
    }

    if ($tanggal === '') $tanggal = $fotoLama['tanggal'] ?? date('Y-m-d H:i');
    $tanggal = str_replace('T', ' ', $tanggal);

    if ($id > 0) {
        $st = $pdo->prepare('UPDATE galeri SET judul = ?, deskripsi = ?, mime = ?, isi = ?, ukuran = ?, tanggal = ?, urutan = ?, status = ? WHERE id = ?');
        $st->bindValue(1, $judul);
        $st->bindValue(2, $deskripsi);
        $st->bindValue(3, $mime);
        $st->bindValue(4, $isi, $isi === '' ? PDO::PARAM_STR : PDO::PARAM_LOB);
        $st->bindValue(5, $ukuran, PDO::PARAM_INT);
        $st->bindValue(6, $tanggal);
        $st->bindValue(7, $urutan, PDO::PARAM_INT);
        $st->bindValue(8, $status, PDO::PARAM_INT);
        $st->bindValue(9, $id, PDO::PARAM_INT);
        $st->execute();
        flash('Foto galeri berhasil diperbarui.');
    } else {
        if ($upload === null) {
            flash('File foto wajib diunggah untuk foto baru.', 'error');
            redirect('galeri.php');
        }
        $st = $pdo->prepare('INSERT INTO galeri (judul, deskripsi, mime, isi, ukuran, tanggal, urutan, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $st->bindValue(1, $judul);
        $st->bindValue(2, $deskripsi);
        $st->bindValue(3, $mime);
        $st->bindValue(4, $isi, PDO::PARAM_LOB);
        $st->bindValue(5, $ukuran, PDO::PARAM_INT);
        $st->bindValue(6, $tanggal);
        $st->bindValue(7, $urutan, PDO::PARAM_INT);
        $st->bindValue(8, $status, PDO::PARAM_INT);
        $st->execute();
        flash('Foto galeri baru berhasil disimpan.');
    }
    redirect('galeri.php');
}

if ($aksi === 'hapus') {
    csrf_check_q();
    $pdo->prepare('DELETE FROM galeri WHERE id = ?')->execute([(int)get('id', 0)]);
    flash('Foto galeri berhasil dihapus.');
    redirect('galeri.php');
}

if ($aksi === 'toggle') {
    csrf_check_q();
    $pdo->prepare('UPDATE galeri SET status = CASE status WHEN 1 THEN 0 ELSE 1 END WHERE id = ?')->execute([(int)get('id', 0)]);
    flash('Status publikasi foto diubah.');
    redirect('galeri.php');
}

$edit = null;
if ($aksi === 'edit') {
    $st = $pdo->prepare('SELECT * FROM galeri WHERE id = ?');
    $st->execute([(int)get('id', 0)]);
    $edit = $st->fetch();
}

$foto = $pdo->query('SELECT * FROM galeri ORDER BY tanggal DESC, urutan ASC')->fetchAll();
?>

<div class="admin-tools">
  <a class="btn btn-primary btn-sm" href="galeri.php?aksi=edit"><?= icon('plus', 16) ?> Tambah Foto</a>
  <?php if ($edit): ?><a class="btn btn-outline-navy btn-sm" href="galeri.php">Batal edit</a><?php endif; ?>
  <span class="form-note"><?= count($foto) ?> foto tersimpan</span>
</div>

<?php if ($edit || get('aksi') === 'edit'): ?>
<div class="admin-card">
  <h3><?= $edit ? 'Edit Foto #' . (int)$edit['id'] : 'Tambah Foto Baru' ?></h3>
  <form method="post" action="galeri.php?aksi=simpan" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
    <div class="form-grid">
      <div class="field full">
        <label for="judul">Judul Foto <span class="req">*</span></label>
        <input type="text" id="judul" name="judul" required maxlength="160" value="<?= e($edit['judul'] ?? '') ?>">
      </div>
      <div class="field full">
        <label for="deskripsi">Deskripsi (opsional)</label>
        <textarea id="deskripsi" name="deskripsi" maxlength="500" rows="2"><?= e($edit['deskripsi'] ?? '') ?></textarea>
      </div>
      <div class="field">
        <label for="urutan">Urutan Tampil</label>
        <input type="number" id="urutan" name="urutan" min="1" value="<?= (int)($edit['urutan'] ?? 0) ?>">
      </div>
      <div class="field">
        <label for="tanggal">Tanggal</label>
        <input type="datetime-local" id="tanggal" name="tanggal" value="<?= e($edit ? date('Y-m-d\TH:i', strtotime($edit['tanggal'])) : date('Y-m-d\TH:i')) ?>">
      </div>
      <div class="field full">
        <label for="foto">Foto <?= $edit ? '' : '<span class="req">*</span>' ?></label>
        <input type="file" id="foto" name="foto" accept="image/jpeg,image/png,image/webp,image/gif">
        <span class="form-note">JPG, PNG, WebP, atau GIF — maksimal 3 MB. <?= $edit ? 'Kosongkan jika tidak mengganti foto.' : 'Wajib diisi untuk foto baru.' ?></span>
        <?php if ($edit && !empty($edit['isi'])): ?>
        <div style="display:flex; gap:14px; align-items:center; margin-top:10px; flex-wrap:wrap;">
          <img src="../galeri-foto.php?id=<?= (int)$edit['id'] ?>" alt="Foto saat ini" style="height:86px; max-width:180px; object-fit:cover; border-radius:10px; border:1px solid var(--line); box-shadow:var(--shadow);">
          <label style="font-weight:600; font-size:14px; display:flex; gap:7px; align-items:center; cursor:pointer; color:var(--navy-800);">
            <input type="checkbox" name="hapus_foto" value="1" style="width:17px;height:17px;"> Hapus foto ini
          </label>
        </div>
        <?php endif; ?>
      </div>
      <div class="field full">
        <label style="flex-direction:row; gap:8px; align-items:center; cursor:pointer;">
          <input type="checkbox" name="status" value="1" style="width:18px;height:18px;" <?= (int)($edit['status'] ?? 1) === 1 ? 'checked' : '' ?>>
          Publikasikan di situs
        </label>
      </div>
    </div>
    <button type="submit" class="btn btn-primary mt-16"><?= icon('check-circle', 17) ?> Simpan Foto</button>
  </form>
</div>
<?php endif; ?>

<div class="admin-card" style="padding:0; overflow:hidden;">
  <div class="table-wrap" style="border:none; border-radius:0;">
    <table class="tbl">
      <thead>
        <tr>
          <th>ID</th>
          <th>Foto</th>
          <th>Judul</th>
          <th>Tanggal</th>
          <th>Status</th>
          <th style="text-align:right;">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($foto as $f): ?>
        <tr>
          <td><?= (int)$f['id'] ?></td>
          <td>
            <?php if (!empty($f['isi'])): ?>
              <img src="../galeri-foto.php?id=<?= (int)$f['id'] ?>" alt="" style="width:64px; height:44px; object-fit:cover; border-radius:6px; border:1px solid var(--line);">
            <?php else: ?>
              <span style="color:#b9c4d0; font-size:12px;">—</span>
            <?php endif; ?>
          </td>
          <td style="max-width:280px;"><?= e(potong($f['judul'], 60)) ?></td>
          <td class="num" style="white-space:nowrap;"><?= e(tanggal_id($f['tanggal'])) ?></td>
          <td>
            <?php if ((int)$f['status'] === 1): ?>
              <span class="status-pill aktif">Aktif</span>
            <?php else: ?>
              <span class="status-pill baru">Nonaktif</span>
            <?php endif; ?>
          </td>
          <td>
            <div class="row-actions" style="justify-content:flex-end;">
              <a href="../galeri-foto.php?id=<?= (int)$f['id'] ?>" target="_blank" title="Lihat"><?= icon('photo', 15) ?></a>
              <a href="galeri.php?aksi=edit&id=<?= (int)$f['id'] ?>" title="Edit"><?= icon('edit', 15) ?></a>
              <a href="galeri.php?aksi=toggle&id=<?= (int)$f['id'] ?>&csrf=<?= e(csrf_token()) ?>" title="<?= (int)$f['status'] === 1 ? 'Nonaktifkan' : 'Publikasikan' ?>">
                <?= icon((int)$f['status'] === 1 ? 'chevron-down' : 'check-circle', 15) ?>
              </a>
              <form method="post" action="galeri.php?aksi=hapus&id=<?= (int)$f['id'] ?>&csrf=<?= e(csrf_token()) ?>" data-confirm="Hapus foto ini?">
                <button type="submit" class="del" title="Hapus"><?= icon('trash', 15) ?></button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$foto): ?>
        <tr><td colspan="6" style="text-align:center; color:var(--muted); padding:26px;">Belum ada foto. Klik "Tambah Foto" untuk mengunggah.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
