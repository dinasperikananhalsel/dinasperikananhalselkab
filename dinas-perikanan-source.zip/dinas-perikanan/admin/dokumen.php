<?php
$activeAdmin = 'dokumen';
$pageTitle = 'Kelola Dokumen Publik';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../lib/db.php';

$pdo = db();
$aksi = (string)get('aksi', '');
$kategoris = ['Peraturan', 'Laporan', 'Data & Statistik', 'Lainnya'];
$ekstensiIzin = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'odt', 'txt', 'csv'];
$maxUkuran = 10 * 1024 * 1024; // 10 MB

function ekstensi_file(string $nama): string
{
    return strtolower(pathinfo($nama, PATHINFO_EXTENSION));
}

/** Baca & validasi unggahan dokumen. Mengembalikan array [nama_file, mime, isi] atau null (tidak ada file), set $err bila gagal. */
function baca_dokumen_upload(array $file, &$err): ?array
{
    global $ekstensiIzin, $maxUkuran;
    $file += ['error' => UPLOAD_ERR_NO_FILE, 'size' => 0, 'tmp_name' => '', 'name' => ''];
    if ((int)$file['error'] === UPLOAD_ERR_NO_FILE) return null;
    if ((int)$file['error'] !== UPLOAD_ERR_OK) { $err = pesan_error_upload((int)$file['error']); return null; }
    if ((int)$file['size'] > $maxUkuran) { $err = 'Ukuran berkas maksimal 10 MB.'; return null; }
    $tmp = $file['tmp_name'] ?? '';
    if ($tmp === '' || !is_uploaded_file($tmp)) { $err = 'Berkas tidak valid.'; return null; }

    $namaAsli = basename((string)$file['name']);
    $ext = ekstensi_file($namaAsli);
    if (!in_array($ext, $ekstensiIzin, true)) { $err = 'Jenis berkas tidak diizinkan (PDF, DOC/DOCX, XLS/XLSX, PPT/PPTX, ODT, TXT, CSV).'; return null; }

    $isi = file_get_contents($tmp);
    if ($isi === false || $isi === '') { $err = 'Gagal membaca berkas.'; return null; }

    // Deteksi MIME: preferensi finfo, fallback peta ekstensi
    $mime = 'application/octet-stream';
    if (class_exists('finfo')) {
        $fi = new finfo(FILEINFO_MIME_TYPE);
        $deteksi = $fi->buffer($isi);
        if (is_string($deteksi) && $deteksi !== '' && $deteksi !== 'application/octet-stream') $mime = $deteksi;
    } else {
        $peta = ['pdf' => 'application/pdf', 'doc' => 'application/msword', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'xls' => 'application/vnd.ms-excel', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'ppt' => 'application/vnd.ms-powerpoint', 'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'odt' => 'application/vnd.oasis.opendocument.text', 'txt' => 'text/plain', 'csv' => 'text/csv'];
        $mime = $peta[$ext] ?? 'application/octet-stream';
    }

    return ['nama_file' => $namaAsli, 'mime' => $mime, 'isi' => $isi];
}

// ---------- Simpan ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $aksi === 'simpan') {
    csrf_check();
    $id         = (int)post('id', 0);
    $judul      = trim((string)post('judul'));
    $deskripsi  = trim((string)post('deskripsi'));
    $kategori   = in_array(post('kategori'), $kategoris, true) ? post('kategori') : 'Lainnya';
    $urutan     = (int)post('urutan', 0);
    $status     = isset($_POST['status']) ? 1 : 0;
    $tanggal    = trim((string)post('tanggal'));

    if ($judul === '') {
        flash('Judul dokumen wajib diisi.', 'error');
        redirect('dokumen.php');
    }

    // Dokumen lama (saat edit)
    $docLama = null;
    if ($id > 0) {
        $st = $pdo->prepare('SELECT * FROM dokumen WHERE id = ?');
        $st->execute([$id]);
        $docLama = $st->fetch();
    }

    // Proses berkas baru
    $errDoc = '';
    $upload = baca_dokumen_upload($_FILES['dokumen'] ?? ['error' => UPLOAD_ERR_NO_FILE], $errDoc);
    if ($errDoc !== '') {
        flash($errDoc, 'error');
        redirect('dokumen.php');
    }
    if ($upload !== null) {
        $namaFile = $upload['nama_file'];
        $mime = $upload['mime'];
        $isi = $upload['isi'];
        $ukuran = strlen($isi);
    } elseif ($docLama && !isset($_POST['hapus_file'])) {
        $namaFile = $docLama['nama_file'];
        $mime = $docLama['mime'];
        $isi = $docLama['isi'];
        $ukuran = (int)$docLama['ukuran'];
    } else {
        $namaFile = '';
        $mime = 'application/octet-stream';
        $isi = '';
        $ukuran = 0;
    }

    if ($tanggal === '') $tanggal = $docLama['tanggal'] ?? date('Y-m-d H:i');
    $tanggal = str_replace('T', ' ', $tanggal);

    if ($id > 0) {
        $st = $pdo->prepare('UPDATE dokumen SET judul = ?, deskripsi = ?, kategori = ?, nama_file = ?, mime = ?, isi = ?, ukuran = ?, tanggal = ?, urutan = ?, status = ? WHERE id = ?');
        $st->bindValue(1, $judul);
        $st->bindValue(2, $deskripsi);
        $st->bindValue(3, $kategori);
        $st->bindValue(4, $namaFile);
        $st->bindValue(5, $mime);
        $st->bindValue(6, $isi, $isi === '' ? PDO::PARAM_STR : PDO::PARAM_LOB);
        $st->bindValue(7, $ukuran, PDO::PARAM_INT);
        $st->bindValue(8, $tanggal);
        $st->bindValue(9, $urutan, PDO::PARAM_INT);
        $st->bindValue(10, $status, PDO::PARAM_INT);
        $st->bindValue(11, $id, PDO::PARAM_INT);
        $st->execute();
        flash('Dokumen berhasil diperbarui.');
    } else {
        if ($upload === null) {
            flash('Berkas dokumen wajib diunggah untuk dokumen baru.', 'error');
            redirect('dokumen.php');
        }
        $st = $pdo->prepare('INSERT INTO dokumen (judul, deskripsi, kategori, nama_file, mime, isi, ukuran, tanggal, urutan, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $st->bindValue(1, $judul);
        $st->bindValue(2, $deskripsi);
        $st->bindValue(3, $kategori);
        $st->bindValue(4, $namaFile);
        $st->bindValue(5, $mime);
        $st->bindValue(6, $isi, PDO::PARAM_LOB);
        $st->bindValue(7, $ukuran, PDO::PARAM_INT);
        $st->bindValue(8, $tanggal);
        $st->bindValue(9, $urutan, PDO::PARAM_INT);
        $st->bindValue(10, $status, PDO::PARAM_INT);
        $st->execute();
        flash('Dokumen baru berhasil disimpan.');
    }
    redirect('dokumen.php');
}

if ($aksi === 'hapus') {
    csrf_check_q();
    $pdo->prepare('DELETE FROM dokumen WHERE id = ?')->execute([(int)get('id', 0)]);
    flash('Dokumen berhasil dihapus.');
    redirect('dokumen.php');
}

if ($aksi === 'toggle') {
    csrf_check_q();
    $pdo->prepare('UPDATE dokumen SET status = CASE status WHEN 1 THEN 0 ELSE 1 END WHERE id = ?')->execute([(int)get('id', 0)]);
    flash('Status publikasi dokumen diubah.');
    redirect('dokumen.php');
}

$edit = null;
if ($aksi === 'edit') {
    $st = $pdo->prepare('SELECT * FROM dokumen WHERE id = ?');
    $st->execute([(int)get('id', 0)]);
    $edit = $st->fetch();
}

$dokumen = $pdo->query('SELECT * FROM dokumen ORDER BY tanggal DESC, urutan ASC')->fetchAll();

function ukuran_admin(int $b): string
{
    if ($b >= 1048576) return number_format($b / 1048576, 1, ',', '.') . ' MB';
    if ($b >= 1024) return number_format($b / 1024, 0, ',', '.') . ' KB';
    return $b . ' B';
}
?>

<div class="admin-tools">
  <a class="btn btn-primary btn-sm" href="dokumen.php?aksi=edit"><?= icon('plus', 16) ?> Unggah Dokumen</a>
  <?php if ($edit): ?><a class="btn btn-outline-navy btn-sm" href="dokumen.php">Batal edit</a><?php endif; ?>
  <span class="form-note"><?= count($dokumen) ?> dokumen tersimpan</span>
</div>

<?php if ($edit || get('aksi') === 'edit'): ?>
<div class="admin-card">
  <h3><?= $edit ? 'Edit Dokumen #' . (int)$edit['id'] : 'Unggah Dokumen Baru' ?></h3>
  <form method="post" action="dokumen.php?aksi=simpan" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
    <div class="form-grid">
      <div class="field full">
        <label for="judul">Judul Dokumen <span class="req">*</span></label>
        <input type="text" id="judul" name="judul" required maxlength="255" value="<?= e($edit['judul'] ?? '') ?>">
      </div>
      <div class="field">
        <label for="kategori">Kategori</label>
        <select id="kategori" name="kategori">
          <?php foreach ($kategoris as $k): ?>
          <option value="<?= e($k) ?>" <?= ($edit['kategori'] ?? 'Laporan') === $k ? 'selected' : '' ?>><?= e($k) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label for="urutan">Urutan Tampil</label>
        <input type="number" id="urutan" name="urutan" min="1" value="<?= (int)($edit['urutan'] ?? 0) ?>">
      </div>
      <div class="field full">
        <label for="deskripsi">Deskripsi</label>
        <textarea id="deskripsi" name="deskripsi" maxlength="1000" rows="2"><?= e($edit['deskripsi'] ?? '') ?></textarea>
      </div>
      <div class="field full">
        <label for="tanggal">Tanggal Publikasi</label>
        <input type="datetime-local" id="tanggal" name="tanggal" value="<?= e($edit ? date('Y-m-d\TH:i', strtotime($edit['tanggal'])) : date('Y-m-d\TH:i')) ?>">
      </div>
      <div class="field full">
        <label for="dokumen">Berkas Dokumen <?= $edit ? '' : '<span class="req">*</span>' ?></label>
        <input type="file" id="dokumen" name="dokumen" accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.odt,.txt,.csv">
        <span class="form-note">PDF, Word, Excel, PowerPoint, ODT, TXT, CSV — maksimal 10 MB. <?= $edit ? 'Kosongkan jika tidak mengganti berkas.' : 'Wajib diisi untuk dokumen baru.' ?></span>
        <?php if ($edit && !empty($edit['isi'])): ?>
        <div style="display:flex; gap:14px; align-items:center; margin-top:10px; flex-wrap:wrap;">
          <span style="font-size:13.5px; background:var(--bg); border:1px solid var(--line); padding:8px 12px; border-radius:8px;">
            <?= icon('file', 14) ?> <?= e($edit['nama_file']) ?> · <?= e(ukuran_admin((int)$edit['ukuran'])) ?>
          </span>
          <label style="font-weight:600; font-size:14px; display:flex; gap:7px; align-items:center; cursor:pointer; color:var(--navy-800);">
            <input type="checkbox" name="hapus_file" value="1" style="width:17px;height:17px;"> Hapus berkas ini
          </label>
        </div>
        <?php endif; ?>
      </div>
      <div class="field full">
        <label style="flex-direction:row; gap:8px; align-items:center; cursor:pointer;">
          <input type="checkbox" name="status" value="1" style="width:18px;height:18px;" <?= (int)($edit['status'] ?? 1) === 1 ? 'checked' : '' ?>>
          Publikasikan di situs
        </label>
      </div>
    </div>
    <button type="submit" class="btn btn-primary mt-16"><?= icon('check-circle', 17) ?> Simpan Dokumen</button>
  </form>
</div>
<?php endif; ?>

<div class="admin-card" style="padding:0; overflow:hidden;">
  <div class="table-wrap" style="border:none; border-radius:0;">
    <table class="tbl">
      <thead>
        <tr>
          <th>ID</th>
          <th>Judul</th>
          <th>Kategori</th>
          <th>Berkas</th>
          <th>Tanggal</th>
          <th>Status</th>
          <th style="text-align:right;">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($dokumen as $d): ?>
        <tr>
          <td><?= (int)$d['id'] ?></td>
          <td style="max-width:300px;"><a href="../dokumen-publik.php" target="_blank"><?= e(potong($d['judul'], 60)) ?></a></td>
          <td><span class="badge"><?= e($d['kategori']) ?></span></td>
          <td style="font-size:13px;"><?= icon('file', 13) ?> <?= e($d['nama_file']) ?><br><span style="color:var(--muted);"><?= e(ukuran_admin((int)$d['ukuran'])) ?></span></td>
          <td class="num" style="white-space:nowrap;"><?= e(tanggal_id($d['tanggal'])) ?></td>
          <td>
            <?php if ((int)$d['status'] === 1): ?>
              <span class="status-pill aktif">Aktif</span>
            <?php else: ?>
              <span class="status-pill baru">Nonaktif</span>
            <?php endif; ?>
          </td>
          <td>
            <div class="row-actions" style="justify-content:flex-end;">
              <a href="../dokumen.php?id=<?= (int)$d['id'] ?>" target="_blank" title="Unduh"><?= icon('download', 15) ?></a>
              <a href="dokumen.php?aksi=edit&id=<?= (int)$d['id'] ?>" title="Edit"><?= icon('edit', 15) ?></a>
              <a href="dokumen.php?aksi=toggle&id=<?= (int)$d['id'] ?>&csrf=<?= e(csrf_token()) ?>" title="<?= (int)$d['status'] === 1 ? 'Nonaktifkan' : 'Publikasikan' ?>">
                <?= icon((int)$d['status'] === 1 ? 'chevron-down' : 'check-circle', 15) ?>
              </a>
              <form method="post" action="dokumen.php?aksi=hapus&id=<?= (int)$d['id'] ?>&csrf=<?= e(csrf_token()) ?>" data-confirm="Hapus dokumen ini?">
                <button type="submit" class="del" title="Hapus"><?= icon('trash', 15) ?></button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$dokumen): ?>
        <tr><td colspan="7" style="text-align:center; color:var(--muted); padding:26px;">Belum ada dokumen. Klik "Unggah Dokumen" untuk menambahkan.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
