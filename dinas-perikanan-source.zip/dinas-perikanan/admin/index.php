<?php
$activeAdmin = 'dashboard';
$pageTitle = 'Dashboard';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../lib/db.php';

$pdo = db();

$jmlBerita    = (int)$pdo->query('SELECT COUNT(*) FROM berita')->fetchColumn();
$jmlBeritaAktif = (int)$pdo->query('SELECT COUNT(*) FROM berita WHERE status = 1')->fetchColumn();
$jmlPesan     = (int)$pdo->query('SELECT COUNT(*) FROM pesan')->fetchColumn();
$jmlPesanBaru = (int)$pdo->query('SELECT COUNT(*) FROM pesan WHERE dibaca = 0')->fetchColumn();
$jmlPengaduan = (int)$pdo->query('SELECT COUNT(*) FROM pengaduan')->fetchColumn();
$jmlPengBaru  = (int)$pdo->query("SELECT COUNT(*) FROM pengaduan WHERE status = 'Baru'")->fetchColumn();
$jmlLayanan   = (int)$pdo->query('SELECT COUNT(*) FROM layanan')->fetchColumn();
$jmlTahun     = (int)$pdo->query('SELECT COUNT(*) FROM statistik')->fetchColumn();
$jmlAplikasi  = (int)$pdo->query('SELECT COUNT(*) FROM aplikasi')->fetchColumn();
$jmlAplikasiAktif = (int)$pdo->query('SELECT COUNT(*) FROM aplikasi WHERE status = 1')->fetchColumn();

$pesanTerbaru  = $pdo->query('SELECT * FROM pesan ORDER BY tanggal DESC LIMIT 5')->fetchAll();
$pengTerbaru   = $pdo->query('SELECT * FROM pengaduan ORDER BY tanggal DESC LIMIT 5')->fetchAll();
?>

<div class="kpi-grid">
  <div class="kpi">
    <div class="kpi-icon navy"><?= icon('file-text', 22) ?></div>
    <div><div class="kpi-num"><?= $jmlBerita ?></div><div class="kpi-label">Berita (<?= $jmlBeritaAktif ?> publikasi)</div></div>
  </div>
  <div class="kpi">
    <div class="kpi-icon gold"><?= icon('mail', 22) ?></div>
    <div><div class="kpi-num"><?= $jmlPesan ?></div><div class="kpi-label">Pesan (<?= $jmlPesanBaru ?> baru)</div></div>
  </div>
  <div class="kpi">
    <div class="kpi-icon red"><?= icon('alert', 22) ?></div>
    <div><div class="kpi-num"><?= $jmlPengaduan ?></div><div class="kpi-label">Pengaduan (<?= $jmlPengBaru ?> baru)</div></div>
  </div>
  <div class="kpi">
    <div class="kpi-icon teal"><?= icon('chart', 22) ?></div>
    <div><div class="kpi-num"><?= $jmlTahun ?></div><div class="kpi-label">Tahun data statistik</div></div>
  </div>
  <div class="kpi">
    <div class="kpi-icon sky"><?= icon('external', 22) ?></div>
    <div><div class="kpi-num"><?= $jmlAplikasi ?></div><div class="kpi-label">Aplikasi portal (<?= $jmlAplikasiAktif ?> aktif)</div></div>
  </div>
</div>

<div class="grid grid-2" style="align-items:start;">
  <div class="admin-card" style="padding:0; overflow:hidden;">
    <div style="padding:18px 22px 0; display:flex; justify-content:space-between; align-items:center;">
      <h3 style="margin:0;">Pesan Terbaru</h3>
      <a href="pesan.php" style="font-size:13px; font-weight:600;">Lihat semua</a>
    </div>
    <div class="table-wrap" style="border:none; border-radius:0;">
      <table class="tbl">
        <thead><tr><th>Nama</th><th>Subjek</th><th>Tanggal</th></tr></thead>
        <tbody>
          <?php foreach ($pesanTerbaru as $p): ?>
          <tr>
            <td><?= e($p['nama']) ?><?= (int)$p['dibaca'] === 0 ? ' <span class="badge">Baru</span>' : '' ?></td>
            <td style="max-width:200px;"><?= e(potong($p['subjek'] ?: '(tanpa subjek)', 45)) ?></td>
            <td class="num" style="white-space:nowrap;"><?= e(tanggal_id($p['tanggal'])) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (!$pesanTerbaru): ?><tr><td colspan="3" style="text-align:center; color:var(--muted);">Belum ada pesan.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="admin-card" style="padding:0; overflow:hidden;">
    <div style="padding:18px 22px 0; display:flex; justify-content:space-between; align-items:center;">
      <h3 style="margin:0;">Pengaduan Terbaru</h3>
      <a href="pengaduan.php" style="font-size:13px; font-weight:600;">Lihat semua</a>
    </div>
    <div class="table-wrap" style="border:none; border-radius:0;">
      <table class="tbl">
        <thead><tr><th>Judul</th><th>Status</th><th>Tanggal</th></tr></thead>
        <tbody>
          <?php foreach ($pengTerbaru as $p):
              $cls = match ($p['status']) { 'Selesai' => 'selesai', 'Diproses' => 'diproses', default => 'baru' }; ?>
          <tr>
            <td style="max-width:220px;"><?= e(potong($p['judul'], 50)) ?></td>
            <td><span class="status-pill <?= e($cls) ?>"><?= e($p['status']) ?></span></td>
            <td class="num" style="white-space:nowrap;"><?= e(tanggal_id($p['tanggal'])) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (!$pengTerbaru): ?><tr><td colspan="3" style="text-align:center; color:var(--muted);">Belum ada pengaduan.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="alert alert-info mt-16" style="margin-bottom:0;">
  <?= icon('shield', 18) ?>
  <span>Gunakan menu di samping untuk mengelola konten. Semua perubahan langsung tampil di situs publik. Disarankan mengubah password default setelah login pertama kali.</span>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
