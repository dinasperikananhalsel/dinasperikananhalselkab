<?php
// Login panel admin
session_start();
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/icons.php';
require_once __DIR__ . '/../lib/db.php';

if (is_auth()) redirect('index.php');

$err = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim((string)post('username'));
    $p = (string)post('password');
    if ($u === '' || $p === '') {
        $err = 'Username dan password wajib diisi.';
    } else {
        $st = db()->prepare('SELECT * FROM admin WHERE username = ?');
        $st->execute([$u]);
        $admin = $st->fetch();
        if ($admin && password_verify($p, $admin['password'])) {
            session_regenerate_id(true);
            $_SESSION['admin_id'] = (int)$admin['id'];
            $_SESSION['admin_nama'] = $admin['nama'];
            $_SESSION['admin_user'] = $admin['username'];
            redirect('index.php');
        }
        $err = 'Username atau password salah.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex">
<title>Login Admin — <?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?></title>
<link rel="icon" type="image/png" href="../assets/img/favicon-64.png">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin-login">
  <div class="login-card fade-in">
    <div class="lc-brand">
      <img src="../assets/img/logo-daerah.png" alt="Lambang Kabupaten Halmahera Selatan">
      <h1>Panel Admin</h1>
      <p><?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?></p>
    </div>
    <?php if ($err): ?>
      <div class="alert alert-error"><?= icon('alert', 20) ?> <span><?= e($err) ?></span></div>
    <?php endif; ?>
    <form method="post" action="login.php">
      <div class="field">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" required autofocus autocomplete="username">
      </div>
      <div class="field">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required autocomplete="current-password">
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%; justify-content:center; margin-top:8px;"><?= icon('shield', 17) ?> Masuk</button>
    </form>
    <p class="form-note text-center mt-16"><a href="../index.php">← Kembali ke situs</a></p>
  </div>
</body>
</html>
