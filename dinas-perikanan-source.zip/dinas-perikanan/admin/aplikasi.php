<?php
$activeAdmin = 'aplikasi';
$pageTitle = 'Kelola Portal Aplikasi';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../lib/db.php';

$pdo = db();
$aksi = (string)get('aksi', '');
$daftarIkon = ['building', 'fish', 'anchor', 'waves', 'chart', 'file-text', 'shield', 'award',
               'megaphone', 'calendar', 'layers', 'search', 'boat', 'mail', 'phone', 'users',
               'list', 'external', 'check-circle', 'alert', 'send', 'map-pin', 'clock'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $aksi === 'simpan') {
    csrf_check();
    $d = [
        'id'        => (int)post('id', 0),
        'nama'      => trim((string)post('nama')),
        'url'       => trim((string)post('url')),
        'deskripsi' => trim((string)post('deskripsi')),
        'ikon'      => in_array(post('ikon'), $daftarIkon, true) ? post('ikon') : 'external',
        'urutan'    => (int)post('urutan', 0),
        'status'    => isset($_POST['status']) ? 1 : 0,
    ];
    if ($d['nama'] === '' || $d['url'] === '') {
        flash('Nama aplikasi dan URL wajib diisi.', 'error');
        redirect('aplikasi.php');
    }
    if (!preg_match('~^https?://~i', $d['url'])) {
        flash('URL harus diawali http:// atau https://', 'error');
        redirect('aplikasi.php');
    }
    if ($d['id'] > 0) {
        $st = $pdo->prepare('UPDATE aplikasi SET nama = ?, url = ?, deskripsi = ?, ikon = ?, urutan = ?, status = ? WHERE id = ?');
        $st->execute([$d['nama'], $d['url'], $d['deskripsi'], $d['ikon'], $d['urutan'], $d['status'], $d['id']]);
        flash('Aplikasi berhasil diperbarui.');
    } else {
        $st = $pdo->prepare('INSERT INTO aplikasi (nama, url, deskripsi, ikon, urutan, status) VALUES (?, ?, ?, ?, ?, ?)');
        $st->execute([$d['nama'], $d['url'], $d['deskripsi'], $d['ikon'], $d['urutan'], $d['status']]);
        flash('Aplikasi baru berhasil disimpan.');
    }
    redirect('aplikasi.php');
}

if ($aksi === 'hapus') {
    csrf_check_q();
    $pdo->prepare('DELETE FROM aplikasi WHERE id = ?')->execute([(int)get('id', 0)]);
    flash('Aplikasi berhasil dihapus.');
    redirect('aplikasi.php');
}

$edit = null;
if ($aksi === 'edit') {
    $st = $pdo->prepare('SELECT * FROM aplikasi WHERE id = ?');
    $st->execute([(int)get('id', 0)]);
    $edit = $st->fetch();
}

$aplikasi = $pdo->query('SELECT * FROM aplikasi ORDER BY urutan ASC')->fetchAll();
?>

<div class="admin-tools">
  <a class="btn btn-primary btn-sm" href="aplikasi.php?aksi=edit"><?= icon('plus', 16) ?> Tambah Aplikasi</a>
  <?php if ($edit): ?><a class="btn btn-outline-navy btn-sm" href="aplikasi.php">Batal edit</a><?php endif; ?>
  <span class="form-note"><?= count($aplikasi) ?> aplikasi terdaftar</span>
</div>

<?php if ($edit || get('aksi') === 'edit'): ?>
<div class="admin-card">
  <h3><?= $edit ? 'Edit Aplikasi #' . (int)$edit['id'] : 'Tambah Aplikasi Baru' ?></h3>
  <form method="post" action="aplikasi.php?aksi=simpan">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
    <div class="form-grid">
      <div class="field full">
        <label for="nama">Nama Aplikasi <span class="req">*</span></label>
        <input type="text" id="nama" name="nama" required maxlength="160" value="<?= e($edit['nama'] ?? '') ?>">
      </div>
      <div class="field full">
        <label for="url">URL / Link Aplikasi <span class="req">*</span></label>
        <input type="url" id="url" name="url" required maxlength="300" placeholder="https://contoh.go.id" value="<?= e($edit['url'] ?? '') ?>">
        <span class="form-note">Aplikasi akan dibuka di tab baru.</span>
      </div>
      <div class="field full">
        <label for="deskripsi">Deskripsi</label>
        <textarea id="deskripsi" name="deskripsi" maxlength="500" rows="2"><?= e($edit['deskripsi'] ?? '') ?></textarea>
      </div>
      <div class="field">
        <label for="ikon">Ikon</label>
        <select id="ikon" name="ikon">
          <?php foreach ($daftarIkon as $ik): ?>
          <option value="<?= e($ik) ?>" <?= ($edit['ikon'] ?? 'external') === $ik ? 'selected' : '' ?>><?= e($ik) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label for="urutan">Urutan Tampil</label>
        <input type="number" id="urutan" name="urutan" min="1" value="<?= (int)($edit['urutan'] ?? 0) ?>">
      </div>
      <div class="field full">
        <label style="flex-direction:row; gap:8px; align-items:center; cursor:pointer;">
          <input type="checkbox" name="status" value="1" style="width:18px;height:18px;" <?= (int)($edit['status'] ?? 1) === 1 ? 'checked' : '' ?>>
          Tampilkan di situs
        </label>
      </div>
    </div>
    <button type="submit" class="btn btn-primary mt-16"><?= icon('check-circle', 17) ?> Simpan Aplikasi</button>
  </form>
</div>
<?php endif; ?>

<div class="admin-card" style="padding:0; overflow:hidden;">
  <div class="table-wrap" style="border:none; border-radius:0;">
    <table class="tbl">
      <thead>
        <tr><th>Urutan</th><th>Nama Aplikasi</th><th>Link</th><th>Status</th><th style="text-align:right;">Aksi</th></tr>
      </thead>
      <tbody>
        <?php foreach ($aplikasi as $a): ?>
        <tr>
          <td><?= (int)$a['urutan'] ?></td>
          <td><strong><?= e($a['nama']) ?></strong></td>
          <td><a href="<?= e($a['url']) ?>" target="_blank" rel="noopener" style="font-size:13px;"><?= e(potong($a['url'], 50)) ?> <?= icon('external', 12) ?></a></td>
          <td>
            <?php if ((int)$a['status'] === 1): ?>
              <span class="status-pill aktif">Aktif</span>
            <?php else: ?>
              <span class="status-pill baru">Nonaktif</span>
            <?php endif; ?>
          </td>
          <td>
            <div class="row-actions" style="justify-content:flex-end;">
              <a href="aplikasi.php?aksi=edit&id=<?= (int)$a['id'] ?>" title="Edit"><?= icon('edit', 15) ?></a>
              <form method="post" action="aplikasi.php?aksi=hapus&id=<?= (int)$a['id'] ?>&csrf=<?= e(csrf_token()) ?>" data-confirm="Hapus aplikasi ini?">
                <button type="submit" class="del" title="Hapus"><?= icon('trash', 15) ?></button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$aplikasi): ?>
        <tr><td colspan="5" style="text-align:center; color:var(--muted); padding:26px;">Belum ada aplikasi. Klik "Tambah Aplikasi" untuk mendaftarkan link.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
