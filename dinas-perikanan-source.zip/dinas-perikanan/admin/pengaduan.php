<?php
$activeAdmin = 'pengaduan';
$pageTitle = 'Kelola Pengaduan';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../lib/db.php';

$pdo = db();
$aksi = (string)get('aksi', '');
$statuses = ['Baru', 'Diproses', 'Selesai'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $aksi === 'update') {
    csrf_check();
    $id       = (int)post('id', 0);
    $status   = in_array(post('status'), $statuses, true) ? post('status') : 'Baru';
    $tanggapan = trim((string)post('tanggapan'));
    $pdo->prepare('UPDATE pengaduan SET status = ?, tanggapan = ? WHERE id = ?')
       ->execute([$status, $tanggapan, $id]);
    flash('Status pengaduan #' . $id . ' berhasil diperbarui.');
    redirect('pengaduan.php');
}

if ($aksi === 'hapus') {
    csrf_check_q();
    $pdo->prepare('DELETE FROM pengaduan WHERE id = ?')->execute([(int)get('id', 0)]);
    flash('Pengaduan berhasil dihapus.');
    redirect('pengaduan.php');
}

$pengaduan = $pdo->query('SELECT * FROM pengaduan ORDER BY tanggal DESC')->fetchAll();
$jmlBaru = (int)$pdo->query("SELECT COUNT(*) FROM pengaduan WHERE status = 'Baru'")->fetchColumn();
?>

<div class="admin-tools">
  <span class="form-note"><?= count($pengaduan) ?> pengaduan, <?= $jmlBaru ?> berstatus baru</span>
</div>

<?php if (!$pengaduan): ?>
  <div class="admin-card"><p style="color:var(--muted); text-align:center; padding:18px;">Belum ada pengaduan masuk.</p></div>
<?php endif; ?>

<?php foreach ($pengaduan as $p): ?>
<div class="admin-card">
  <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center; justify-content:space-between; margin-bottom:8px;">
    <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
      <strong style="font-size:15.5px; color:var(--navy-900);">#<?= (int)$p['id'] ?> — <?= e($p['judul']) ?></strong>
      <?php if (!empty($p['kode'])): ?><span class="badge"><?= e($p['kode']) ?></span><?php endif; ?>
      <?php
        $cls = match ($p['status']) { 'Selesai' => 'selesai', 'Diproses' => 'diproses', default => 'baru' };
      ?>
      <span class="status-pill <?= e($cls) ?>"><?= e($p['status']) ?></span>
    </div>
    <span class="form-note"><?= e(tanggal_id($p['tanggal'], true)) ?></span>
  </div>
  <p style="font-size:13.5px; color:var(--muted); margin-bottom:8px;">
    <?= icon('users', 14) ?> <?= e($p['nama']) ?> &nbsp;·&nbsp; <?= icon('phone', 14) ?> <?= e($p['telepon'] ?: '-') ?>
    <?php if ($p['lokasi']): ?> &nbsp;·&nbsp; <?= icon('map-pin', 14) ?> <?= e($p['lokasi']) ?><?php endif; ?>
  </p>
  <p style="color:var(--ink); white-space:pre-line; border-left:3px solid var(--line); padding-left:12px;"><?= e($p['isi']) ?></p>
  <?php if ($p['tanggapan']): ?>
    <p style="margin-top:10px; font-size:14px; background:var(--bg); border-radius:8px; padding:10px 14px;"><strong style="color:var(--navy-900);">Tanggapan:</strong> <?= e($p['tanggapan']) ?></p>
  <?php endif; ?>

  <form method="post" action="pengaduan.php?aksi=update" class="mt-16" style="display:flex; flex-wrap:wrap; gap:10px; align-items:flex-end;">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
    <div class="field" style="flex:0 0 150px;">
      <label>Status</label>
      <select name="status">
        <?php foreach ($statuses as $s): ?>
        <option value="<?= e($s) ?>" <?= $p['status'] === $s ? 'selected' : '' ?>><?= e($s) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="field" style="flex:1 1 300px;">
      <label>Tanggapan / Tindak Lanjut</label>
      <textarea name="tanggapan" rows="2" maxlength="2000" placeholder="Isi tanggapan atau catatan penanganan..."><?= e($p['tanggapan']) ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary btn-sm"><?= icon('check-circle', 16) ?> Simpan</button>
  </form>
  <form method="post" action="pengaduan.php?aksi=hapus&id=<?= (int)$p['id'] ?>&csrf=<?= e(csrf_token()) ?>" data-confirm="Hapus pengaduan #<?= (int)$p['id'] ?>?" class="mt-8">
    <button type="submit" class="btn btn-sm" style="border-color:#c0392b; color:#c0392b; background:#fff;"><?= icon('trash', 15) ?> Hapus</button>
  </form>
</div>
<?php endforeach; ?>

<?php require_once __DIR__ . '/_footer.php'; ?>
