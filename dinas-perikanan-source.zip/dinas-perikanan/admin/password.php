<?php
$activeAdmin = 'password';
$pageTitle = 'Ganti Password';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../lib/db.php';

$pdo = db();
$err = null;
$sukses = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $lama = (string)post('password_lama');
    $baru = (string)post('password_baru');
    $ulang = (string)post('password_ulang');

    $st = $pdo->prepare('SELECT * FROM admin WHERE id = ?');
    $st->execute([(int)$_SESSION['admin_id']]);
    $admin = $st->fetch();

    if (!$admin || !password_verify($lama, $admin['password'])) {
        $err = 'Password lama tidak sesuai.';
    } elseif (strlen($baru) < 8) {
        $err = 'Password baru minimal 8 karakter.';
    } elseif ($baru !== $ulang) {
        $err = 'Konfirmasi password baru tidak cocok.';
    } else {
        $st = $pdo->prepare('UPDATE admin SET password = ? WHERE id = ?');
        $st->execute([password_hash($baru, PASSWORD_DEFAULT), (int)$admin['id']]);
        $sukses = 'Password berhasil diganti. Gunakan password baru pada login berikutnya.';
    }
}
?>

<div class="admin-card" style="max-width:520px;">
  <h3 style="display:flex; align-items:center; gap:9px;"><?= icon('shield', 19) ?> Ubah Password Login</h3>
  <p style="color:var(--muted); font-size:13.5px; margin-top:4px;">Ganti password default secara berkala untuk menjaga keamanan panel admin.</p>

  <?php if ($sukses): ?>
    <div class="alert alert-success"><?= icon('check-circle', 20) ?> <span><?= e($sukses) ?></span></div>
  <?php elseif ($err): ?>
    <div class="alert alert-error"><?= icon('alert', 20) ?> <span><?= e($err) ?></span></div>
  <?php endif; ?>

  <form method="post" action="password.php" class="mt-16">
    <?= csrf_field() ?>
    <div class="field" style="margin-bottom:16px;">
      <label for="password_lama">Password Lama <span class="req">*</span></label>
      <input type="password" id="password_lama" name="password_lama" required autocomplete="current-password">
    </div>
    <div class="field" style="margin-bottom:16px;">
      <label for="password_baru">Password Baru <span class="req">*</span></label>
      <input type="password" id="password_baru" name="password_baru" required minlength="8" autocomplete="new-password">
      <span class="form-note">Minimal 8 karakter. Gunakan kombinasi huruf dan angka.</span>
    </div>
    <div class="field" style="margin-bottom:16px;">
      <label for="password_ulang">Ulangi Password Baru <span class="req">*</span></label>
      <input type="password" id="password_ulang" name="password_ulang" required minlength="8" autocomplete="new-password">
    </div>
    <button type="submit" class="btn btn-primary"><?= icon('shield', 17) ?> Simpan Password Baru</button>
  </form>
</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
