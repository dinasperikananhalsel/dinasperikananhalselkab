<?php
// Header bersama halaman admin (dengan sidebar).
ob_start(); // buffer output agar redirect() yang dipanggil setelah render tetap bisa mengirim header
session_start();
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/icons.php';
require_auth();

$activeAdmin = $activeAdmin ?? '';
$pageTitle = $pageTitle ?? 'Dashboard';
$adminNama = $_SESSION['admin_nama'] ?? 'Administrator';
$adminUser = $_SESSION['admin_user'] ?? 'admin';
$inisial = strtoupper(u8first($adminNama)) ?: 'A';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noindex">
<title><?= e($pageTitle) ?> — Admin</title>
<link rel="icon" type="image/png" href="../assets/img/favicon-64.png">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin-body">
<div class="admin-shell">

  <aside class="admin-side">
    <div class="side-brand">
      <img src="../assets/img/logo-daerah.png" alt="Lambang Kabupaten Halmahera Selatan">
      <div><strong>Admin <?= e(SITE_NAME) ?></strong><small>Kab. Halmahera Selatan</small></div>
    </div>
    <nav>
      <a class="<?= $activeAdmin === 'dashboard' ? 'active' : '' ?>" href="index.php"><?= icon('building', 18) ?> Dashboard</a>
      <a class="<?= $activeAdmin === 'berita' ? 'active' : '' ?>" href="berita.php"><?= icon('file-text', 18) ?> Berita</a>
      <a class="<?= $activeAdmin === 'statistik' ? 'active' : '' ?>" href="statistik.php"><?= icon('chart', 18) ?> Statistik</a>
      <a class="<?= $activeAdmin === 'aplikasi' ? 'active' : '' ?>" href="aplikasi.php"><?= icon('external', 18) ?> Portal Aplikasi</a>
      <a class="<?= $activeAdmin === 'layanan' ? 'active' : '' ?>" href="layanan.php"><?= icon('list', 18) ?> Layanan</a>
      <a class="<?= $activeAdmin === 'dokumen' ? 'active' : '' ?>" href="dokumen.php"><?= icon('folder', 18) ?> Dokumen</a>
      <a class="<?= $activeAdmin === 'galeri' ? 'active' : '' ?>" href="galeri.php"><?= icon('photo', 18) ?> Galeri</a>
      <a class="<?= $activeAdmin === 'pesan' ? 'active' : '' ?>" href="pesan.php"><?= icon('mail', 18) ?> Pesan</a>
      <a class="<?= $activeAdmin === 'pengaduan' ? 'active' : '' ?>" href="pengaduan.php"><?= icon('alert', 18) ?> Pengaduan</a>
      <a class="<?= $activeAdmin === 'password' ? 'active' : '' ?>" href="password.php"><?= icon('shield', 18) ?> Ganti Password</a>
      <a href="../index.php" target="_blank"><?= icon('external', 18) ?> Lihat Situs</a>
    </nav>
    <div class="side-foot">Login sebagai <strong style="color:#fff;"><?= e($adminUser) ?></strong><br><a href="logout.php" style="color:var(--gold);">Keluar</a></div>
  </aside>

  <div class="admin-main">
    <div class="admin-topbar">
      <h2><?= e($pageTitle) ?></h2>
      <div class="who">
        <span><?= e($adminNama) ?></span>
        <span class="avatar"><?= e($inisial) ?></span>
      </div>
    </div>
    <div class="admin-content">
      <?= flash_out() ?>
