<?php
$activeAdmin = 'pesan';
$pageTitle = 'Pesan Masuk';
require_once __DIR__ . '/_header.php';
require_once __DIR__ . '/../lib/db.php';

$pdo = db();
$aksi = (string)get('aksi', '');

if ($aksi === 'baca') {
    csrf_check_q();
    $pdo->prepare('UPDATE pesan SET dibaca = 1 WHERE id = ?')->execute([(int)get('id', 0)]);
    redirect('pesan.php');
}
if ($aksi === 'hapus') {
    csrf_check_q();
    $pdo->prepare('DELETE FROM pesan WHERE id = ?')->execute([(int)get('id', 0)]);
    flash('Pesan berhasil dihapus.');
    redirect('pesan.php');
}

$pesan = $pdo->query('SELECT * FROM pesan ORDER BY tanggal DESC')->fetchAll();
$belum = (int)$pdo->query('SELECT COUNT(*) FROM pesan WHERE dibaca = 0')->fetchColumn();
?>

<div class="admin-tools">
  <span class="form-note"><?= count($pesan) ?> pesan masuk, <?= $belum ?> belum dibaca</span>
</div>

<?php if (!$pesan): ?>
  <div class="admin-card"><p style="color:var(--muted); text-align:center; padding:18px;">Belum ada pesan masuk.</p></div>
<?php endif; ?>

<?php foreach ($pesan as $p): ?>
<div class="admin-card" style="<?= (int)$p['dibaca'] === 0 ? 'border-left:4px solid var(--gold);' : '' ?>">
  <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center; justify-content:space-between; margin-bottom:10px;">
    <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
      <strong style="font-size:15.5px; color:var(--navy-900);"><?= e($p['nama']) ?></strong>
      <?php if ((int)$p['dibaca'] === 0): ?><span class="status-pill baru">Belum dibaca</span><?php else: ?><span class="status-pill dibaca">Sudah dibaca</span><?php endif; ?>
    </div>
    <span class="form-note"><?= e(tanggal_id($p['tanggal'], true)) ?></span>
  </div>
  <p style="font-size:13.5px; color:var(--muted); margin-bottom:8px;">
    <?= icon('mail', 14) ?> <?= e($p['email'] ?: '-') ?> &nbsp;·&nbsp; <?= icon('phone', 14) ?> <?= e($p['telepon'] ?: '-') ?>
  </p>
  <?php if ($p['subjek']): ?><p style="font-weight:700; color:var(--navy-900); margin-bottom:6px;"><?= e($p['subjek']) ?></p><?php endif; ?>
  <p style="color:var(--ink); white-space:pre-line;"><?= e($p['isi']) ?></p>
  <div class="row-actions mt-16">
    <?php if ((int)$p['dibaca'] === 0): ?>
    <a href="pesan.php?aksi=baca&id=<?= (int)$p['id'] ?>&csrf=<?= e(csrf_token()) ?>" title="Tandai dibaca" style="width:auto; padding:0 12px;"><?= icon('check-circle', 15) ?> Tandai dibaca</a>
    <?php endif; ?>
    <form method="post" action="pesan.php?aksi=hapus&id=<?= (int)$p['id'] ?>&csrf=<?= e(csrf_token()) ?>" data-confirm="Hapus pesan ini?">
      <button type="submit" class="del" title="Hapus"><?= icon('trash', 15) ?></button>
    </form>
  </div>
</div>
<?php endforeach; ?>

<?php require_once __DIR__ . '/_footer.php'; ?>
