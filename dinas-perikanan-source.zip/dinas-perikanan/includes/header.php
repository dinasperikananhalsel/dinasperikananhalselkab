<?php
// Header bersama halaman publik.
// Set sebelum include: $pageTitle, $activeNav (opsional), $base (opsional, '' di root)
ob_start(); // buffer output agar redirect() yang dipanggil setelah render tetap bisa mengirim header
require_once __DIR__ . '/../lib/config.php';
require_once __DIR__ . '/../lib/helpers.php';
require_once __DIR__ . '/../lib/icons.php';

$base = $base ?? '';
$site = $base === '' ? '' : $base . '/';
$pageTitle = $pageTitle ?? '';
$activeNav = $activeNav ?? '';
$isHome = $activeNav === 'beranda';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?><?= $pageTitle !== '' ? ' — ' : '' ?><?= e(SITE_NAME . ' Kab. ' . KODE_WILAYAH) ?></title>
<meta name="description" content="<?= e(SITE_TAGLINE) ?>">
<link rel="icon" type="image/png" href="<?= $site ?>assets/img/favicon-64.png">
<link rel="stylesheet" href="<?= $site ?>assets/css/style.css">
</head>
<body>

<div class="topbar">
  <div class="container">
    <span class="topbar-item"><?= icon('map-pin', 14) ?><span><?= e(KODE_WILAYAH) ?>, Maluku Utara</span></span>
    <div class="topbar-right">
      <span class="topbar-item"><?= icon('phone', 14) ?><span><?= e(TELEPON) ?></span></span>
      <span class="topbar-item"><?= icon('mail', 14) ?><span><?= e(EMAIL_DINAS) ?></span></span>
      <span class="topbar-item"><?= icon('clock', 14) ?><span><?= e(JAM_LAYANAN) ?></span></span>
    </div>
  </div>
</div>

<header class="site-header">
  <div class="container header-main">
    <img class="header-logo" src="<?= $site ?>assets/img/logo-daerah.png" alt="Lambang Kabupaten Halmahera Selatan">
    <div class="header-titles">
      <div class="instansi"><?= e(INSTANSI) ?></div>
      <h1><?= e(SITE_NAME) ?></h1>
      <p><?= e(SITE_TAGLINE) ?></p>
    </div>
  </div>
</header>

<nav class="navbar">
  <div class="container nav-inner">
    <ul class="nav-links" id="navLinks">
      <li><a class="<?= $activeNav === 'beranda' ? 'active' : '' ?>" href="<?= $site ?>index.php"><?= icon('building', 17) ?> Beranda</a></li>
      <li><a class="<?= $activeNav === 'profil' ? 'active' : '' ?>" href="<?= $site ?>profil.php"><?= icon('users', 17) ?> Profil</a></li>
      <li><a class="<?= $activeNav === 'berita' ? 'active' : '' ?>" href="<?= $site ?>berita.php"><?= icon('file-text', 17) ?> Berita</a></li>
      <li><a class="<?= $activeNav === 'layanan' ? 'active' : '' ?>" href="<?= $site ?>layanan.php"><?= icon('list', 17) ?> Layanan</a></li>
      <li><a class="<?= $activeNav === 'statistik' ? 'active' : '' ?>" href="<?= $site ?>statistik.php"><?= icon('chart', 17) ?> Statistik</a></li>
      <li><a class="<?= $activeNav === 'portal' ? 'active' : '' ?>" href="<?= $site ?>portal-aplikasi.php"><?= icon('layers', 17) ?> Portal Aplikasi</a></li>
      <li><a class="<?= $activeNav === 'dokumen' ? 'active' : '' ?>" href="<?= $site ?>dokumen-publik.php"><?= icon('folder', 17) ?> Dokumen</a></li>
      <li><a class="<?= $activeNav === 'galeri' ? 'active' : '' ?>" href="<?= $site ?>galeri.php"><?= icon('photo', 17) ?> Galeri</a></li>
      <li><a class="<?= $activeNav === 'kontak' ? 'active' : '' ?>" href="<?= $site ?>kontak.php"><?= icon('mail', 17) ?> Kontak</a></li>
    </ul>
    <button class="nav-toggle" type="button" aria-label="Buka menu">☰ Menu</button>
  </div>
</nav>

<main>
<?php if (!$isHome): ?>
<div class="page-hero">
  <div class="container">
    <h1><?= e($pageTitle) ?></h1>
    <div class="crumbs">
      <a href="<?= $site ?>index.php">Beranda</a>
      <?= icon('chevron-down', 13) ?>
      <span><?= e($pageTitle) ?></span>
    </div>
  </div>
</div>
<?php endif; ?>
