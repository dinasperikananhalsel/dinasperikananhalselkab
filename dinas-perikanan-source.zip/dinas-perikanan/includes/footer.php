<?php
// Footer bersama halaman publik. $base harus sudah didefinisikan ('' di root).
$base = $base ?? '';
$site = $base === '' ? '' : $base . '/';
$tahun = date('Y');
?>
</main>

<footer class="footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <h4>Tentang</h4>
        <div class="about">
          <img src="<?= $site ?>assets/img/logo-daerah.png" alt="Lambang Kabupaten Halmahera Selatan">
          <p><?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?> merupakan perangkat daerah yang menyelenggarakan urusan pemerintahan di bidang kelautan dan perikanan, meliputi perikanan tangkap, budidaya, pengolahan, pengawasan, serta pemberdayaan masyarakat pesisir.</p>
        </div>
      </div>
      <div>
        <h4>Tautan</h4>
        <ul>
          <li><a href="<?= $site ?>index.php">Beranda</a></li>
          <li><a href="<?= $site ?>profil.php">Profil Dinas</a></li>
          <li><a href="<?= $site ?>berita.php">Berita &amp; Kegiatan</a></li>
          <li><a href="<?= $site ?>layanan.php">Layanan Publik</a></li>
          <li><a href="<?= $site ?>dokumen-publik.php">Dokumen Publik</a></li>
          <li><a href="<?= $site ?>galeri.php">Galeri Foto</a></li>
          <li><a href="<?= $site ?>statistik.php">Data &amp; Statistik</a></li>
          <li><a href="<?= $site ?>pengaduan.php">Layanan Pengaduan</a></li>
        </ul>
      </div>
      <div>
        <h4>Layanan</h4>
        <ul>
          <li><a href="<?= $site ?>layanan.php#sipi">Surat Izin Penangkapan Ikan</a></li>
          <li><a href="<?= $site ?>layanan.php#cpib">Sertifikasi Pembudidaya Ikan</a></li>
          <li><a href="<?= $site ?>layanan.php#asuransi">Asuransi Nelayan</a></li>
          <li><a href="<?= $site ?>layanan.php#data">Data &amp; Statistik Perikanan</a></li>
          <li><a href="<?= $site ?>kontak.php">Hubungi Kami</a></li>
        </ul>
      </div>
      <div>
        <h4>Kontak</h4>
        <ul class="f-contact">
          <li><?= icon('map-pin', 15) ?><span><?= e(ALAMAT_KANTOR) ?></span></li>
          <li><?= icon('phone', 15) ?><span><?= e(TELEPON) ?> &nbsp;|&nbsp; <?= e(WHATSAPP) ?></span></li>
          <li><?= icon('mail', 15) ?><span><?= e(EMAIL_DINAS) ?></span></li>
          <li><?= icon('clock', 15) ?><span><?= e(JAM_LAYANAN) ?></span></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <div class="container" style="display:flex;flex-wrap:wrap;gap:10px;justify-content:space-between;">
      <span>© <?= $tahun ?> <?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?> — <?= e(INSTANSI) ?></span>
      <span>Dikelola oleh Sekretariat Dinas Perikanan</span>
    </div>
    <p class="footer-credit">Foto latar Beranda (potensi perikanan) — Wikimedia Commons:
      <a href="https://commons.wikimedia.org/wiki/File:Fisherman_holding_skipjack_tuna_in_Buru_Maluku_(36226139054).jpg" target="_blank" rel="noopener">Nelayan &amp; cakalang</a> (Public domain, USAID Indonesia) ·
      <a href="https://commons.wikimedia.org/wiki/File:Perahu_Nelayan_Indonesia.jpg" target="_blank" rel="noopener">Perahu nelayan Indonesia</a> (CC BY-SA 4.0, Afifahdpl) ·
      <a href="https://commons.wikimedia.org/wiki/File:Seaweed_farming_-Nusa_Lembongan,_Bali-16Aug2009.jpg" target="_blank" rel="noopener">Budidaya rumput laut</a> (CC BY-SA 2.0, Jean-Marie Hullot)</p>
  </div>
</footer>

<script src="<?= $site ?>assets/js/main.js"></script>

<a class="wa-float" href="https://wa.me/6282345007980?text=Assalamualaikum%2C%20saya%20ingin%20bertanya%20mengenai%20layanan%20Dinas%20Perikanan" target="_blank" rel="noopener" aria-label="Chat WhatsApp Dinas Perikanan">
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
  </svg>
  <span class="wa-label">Chat WhatsApp</span>
</a>
</body>
</html>
