<?php
$base = '';
$pageTitle = 'Galeri';
$activeNav = 'galeri';
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/includes/header.php';

$pdo = db();
$foto = $pdo->query('SELECT * FROM galeri WHERE status = 1 ORDER BY tanggal DESC, urutan ASC')->fetchAll();
?>

<div class="section" style="padding-top:44px;">
  <div class="container">
    <div class="section-head">
      <span class="section-tag">Galeri</span>
      <h2 class="section-title">Galeri Foto Kegiatan</h2>
      <p class="section-sub">Dokumentasi kegiatan <?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?> — penangkapan, budidaya, pengolahan, penyuluhan, dan kegiatan lainnya. Klik foto untuk memperbesar.</p>
    </div>

    <?php if ($foto): ?>
    <div class="gal-grid">
      <?php foreach ($foto as $f): ?>
      <figure class="gal-item fade-in">
        <img src="<?= $site ?>galeri-foto.php?id=<?= (int)$f['id'] ?>" alt="<?= e($f['judul'] ?: 'Foto galeri') ?>" loading="lazy" data-full="<?= $site ?>galeri-foto.php?id=<?= (int)$f['id'] ?>">
        <?php if ($f['judul'] || $f['deskripsi']): ?>
        <figcaption>
          <strong><?= e($f['judul']) ?></strong>
          <?php if ($f['deskripsi']): ?><span><?= e(potong($f['deskripsi'], 90)) ?></span><?php endif; ?>
        </figcaption>
        <?php endif; ?>
      </figure>
      <?php endforeach; ?>
    </div>

    <div class="lightbox" id="lightbox" aria-hidden="true">
      <button type="button" class="lightbox-close" aria-label="Tutup"><?= icon('chevron-down', 22) ?></button>
      <img src="" alt="Foto galeri diperbesar">
      <div class="lightbox-caption"></div>
    </div>
    <?php else: ?>
      <div class="alert alert-info"><?= icon('photo', 18) ?> <span>Belum ada foto galeri. Foto dapat ditambahkan melalui panel admin.</span></div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
