<?php
$base = '';
$pageTitle = '';
$activeNav = 'beranda';
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/includes/header.php';

$pdo = db();

// Data untuk hero & statistik ringkas
$tahunTerbaru = (int)$pdo->query('SELECT MAX(tahun) FROM statistik')->fetchColumn() ?: 0;
$statTahun   = $pdo->prepare('SELECT * FROM statistik WHERE tahun = ?');
$statTahun->execute([$tahunTerbaru]);
$stat = $statTahun->fetch() ?: null;

$beritaBaru = $pdo->query('SELECT * FROM berita WHERE status = 1 ORDER BY tanggal DESC LIMIT 3')->fetchAll();
$layananPop = $pdo->query('SELECT * FROM layanan ORDER BY urutan ASC LIMIT 4')->fetchAll();
$statRingkas = $pdo->query('SELECT * FROM statistik ORDER BY tahun DESC LIMIT 3')->fetchAll();
$maxRingkas = 0;
foreach ($statRingkas as $r) {
    $maxRingkas = max($maxRingkas, $r['tangkap_ton'], $r['budidaya_ton']);
}

$aplikasi = $pdo->query('SELECT * FROM aplikasi WHERE status = 1 ORDER BY urutan ASC LIMIT 8')->fetchAll();
?>

<!-- ================= HERO ================= -->
<section class="hero" role="banner">
  <div class="hero-slide s1" aria-hidden="true"></div>
  <div class="hero-slide s2" aria-hidden="true"></div>
  <div class="hero-slide s3" aria-hidden="true"></div>
  <div class="hero-overlay" aria-hidden="true"></div>
  <div class="container hero-inner">
    <span class="hero-eyebrow"><?= icon('waves', 16) ?> <?= e(INSTANSI) ?></span>
    <h2>Mewujudkan Perikanan yang Berkelanjutan dan Masyarakat Nelayan yang Sejahtera</h2>
    <p class="lead">Selamat datang di situs resmi <?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?>. Kami hadir untuk memberikan informasi layanan, data, dan kebijakan pengelolaan kelautan dan perikanan yang transparan dan mudah diakses.</p>
    <div class="hero-actions">
      <a class="btn btn-gold" href="<?= $site ?>profil.php"><?= icon('users', 18) ?> Profil Dinas</a>
      <a class="btn btn-outline" href="<?= $site ?>layanan.php"><?= icon('list', 18) ?> Layanan Publik</a>
    </div>
    <div class="hero-stats">
      <div class="stat-chip">
        <div class="angka"><?= $stat ? angka($stat['tangkap_ton'] + $stat['budidaya_ton']) : '-' ?> <small style="font-size:13px">ton</small></div>
        <div class="label">Produksi perikanan <?= e($tahunTerbaru) ?></div>
      </div>
      <div class="stat-chip">
        <div class="angka"><?= $stat ? angka($stat['nilai_miliar']) : '-' ?> <small style="font-size:13px">M</small></div>
        <div class="label">Nilai produksi (Rp miliar)</div>
      </div>
      <div class="stat-chip">
        <div class="angka">± 12.400</div>
        <div class="label">Nelayan terdaftar</div>
      </div>
      <div class="stat-chip">
        <div class="angka">± 214</div>
        <div class="label">Kelompok usaha perikanan</div>
      </div>
    </div>
  </div>
  <svg class="hero-wave" viewBox="0 0 1440 60" preserveAspectRatio="none" fill="currentColor" aria-hidden="true">
    <path d="M0 40c120 22 280 30 480 12S840 12 960 20s300 20 480 0v40H0z"/>
  </svg>
</section>

<!-- ================= SAMBUTAN ================= -->
<section class="section">
  <div class="container">
    <div class="grid grid-2" style="align-items:center; gap:44px;">
      <div class="fade-in">
        <span class="section-tag">Sambutan</span>
        <h2 class="section-title">Sekapur Sirih dari <?= e(NAMA_KEPALA) ?></h2>
        <p style="color:var(--muted); margin-top:14px;">Assalamualaikum warahmatullahi wabarakatuh. Selamat datang di laman resmi <?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?>.</p>
        <p style="color:var(--muted); margin-top:10px;">Kabupaten Halmahera Selatan merupakan daerah kepulauan dengan potensi kelautan dan perikanan yang sangat besar. Dengan luas wilayah laut yang jauh lebih luas dibanding daratan, sektor perikanan menjadi salah satu tulang punggung perekonomian daerah dan sumber penghidupan bagi ribuan nelayan, pembudidaya, dan pengolah ikan.</p>
        <p style="color:var(--muted); margin-top:10px;">Melalui situs ini, kami berkomitmen memberikan pelayanan yang transparan, cepat, dan mudah diakses, serta menyajikan informasi yang akurat mengenai program, layanan, dan data perikanan daerah.</p>
        <p style="color:var(--muted); margin-top:10px;">Semoga kehadiran situs ini bermanfaat bagi seluruh masyarakat.</p>
        <div class="sambutan-sign">
          <img src="<?= $site ?>assets/img/kadis.jpg" alt="Idris Ali, Kepala Dinas Perikanan">
          <div>
            <strong><?= e(NAMA_KEPALA) ?></strong>
            <span>Kepala Dinas Perikanan<br><?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?></span>
          </div>
        </div>
      </div>
      <div>
        <div class="visi-card fade-in">
          <h3><?= icon('waves', 18) ?> Visi</h3>
          <p>“Mewujudkan Senyum Halmahera Selatan yang Adil, Maju dan Berkelanjutan Berbasis Agromaritim dalam Bingkai Saruma Penuh Berkah”</p>
        </div>
        <div class="misi-card mt-24 fade-in">
          <h3><?= icon('list', 18) ?> Misi</h3>
          <ol>
            <li>Transformasi Senyum Unggul Berdaya</li>
            <li>Transformasi Senyum Maju Berkelanjutan</li>
            <li>Transformasi Senyum Produktif Sejahtera</li>
            <li>Transformasi Senyum Prima Bernilai</li>
            <li>Transformasi Senyum Saruma Tangguh</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ================= PROGRAM ================= -->
<section class="section alt">
  <div class="container">
    <div class="section-head center">
      <span class="section-tag">Program Prioritas</span>
      <h2 class="section-title">Arah Kebijakan Pembangunan Perikanan</h2>
      <p class="section-sub">Program unggulan yang dijalankan <?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?> untuk mendorong pertumbuhan sektor kelautan dan perikanan.</p>
    </div>
    <div class="grid grid-4">
      <div class="card hover">
        <div class="card-icon"><?= icon('anchor', 26) ?></div>
        <h3>Penguatan Perikanan Tangkap</h3>
        <p>Penguatan armada, sarana prasarana, dan kelembagaan nelayan untuk meningkatkan produksi tangkap yang bertanggung jawab dan berkelanjutan.</p>
      </div>
      <div class="card hover">
        <div class="card-icon teal"><?= icon('fish', 26) ?></div>
        <h3>Pengembangan Budidaya</h3>
        <p>Pengembangan budidaya rumput laut, udang, dan ikan berbasis kawasan di wilayah pesisir dan kepulauan dengan pendampingan teknis.</p>
      </div>
      <div class="card hover">
        <div class="card-icon gold"><?= icon('megaphone', 26) ?></div>
        <h3>Gemarikan &amp; Gizi</h3>
        <p>Gerakan memasyarakatkan makan ikan untuk meningkatkan gizi masyarakat dan mendukung percepatan penurunan stunting.</p>
      </div>
      <div class="card hover">
        <div class="card-icon sky"><?= icon('award', 26) ?></div>
        <h3>Pengolahan &amp; Pemasaran</h3>
        <p>Fasilitasi sertifikasi mutu, pengolahan hasil perikanan, dan perluasan akses pasar produk unggulan daerah.</p>
      </div>
    </div>
  </div>
</section>

<!-- ================= BERITA ================= -->
<section class="section">
  <div class="container">
    <div class="section-head" style="display:flex; justify-content:space-between; align-items:flex-end; flex-wrap:wrap; gap:16px;">
      <div>
        <span class="section-tag">Berita &amp; Kegiatan</span>
        <h2 class="section-title">Informasi Terbaru</h2>
      </div>
      <a class="btn btn-outline-navy" href="<?= $site ?>berita.php">Semua Berita <?= icon('arrow-right', 17) ?></a>
    </div>

    <?php if ($beritaBaru): ?>
    <div class="grid grid-3">
      <?php foreach ($beritaBaru as $b):
          $w = warna_kategori($b['kategori']); ?>
      <article class="card news-card hover fade-in">
        <?php if (!empty($b['foto'])): ?>
          <img src="<?= $site ?>foto-berita.php?id=<?= (int)$b['id'] ?>" alt="<?= e($b['judul']) ?>" style="width:100%; height:150px; object-fit:cover;">
        <?php else: ?>
          <div class="news-thumb <?= e($w) ?>"><?= icon('fish', 58) ?></div>
        <?php endif; ?>
        <div class="news-body">
          <div class="news-meta">
            <span class="pill <?= e($w) ?>"><?= e($b['kategori']) ?></span>
            <span><?= icon('calendar', 14) ?> <?= e(tanggal_id($b['tanggal'])) ?></span>
          </div>
          <h3><a href="<?= $site ?>berita.php?id=<?= (int)$b['id'] ?>"><?= e($b['judul']) ?></a></h3>
          <p><?= e(potong($b['ringkasan'] ?: $b['isi'], 130)) ?></p>
          <a class="link-more" href="<?= $site ?>berita.php?id=<?= (int)$b['id'] ?>">Baca selengkapnya <?= icon('arrow-right', 15) ?></a>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
      <p style="color:var(--muted)">Belum ada berita.</p>
    <?php endif; ?>
  </div>
</section>

<!-- ================= LAYANAN ================= -->
<section class="section alt">
  <div class="container">
    <div class="section-head" style="display:flex; justify-content:space-between; align-items:flex-end; flex-wrap:wrap; gap:16px;">
      <div>
        <span class="section-tag">Layanan Publik</span>
        <h2 class="section-title">Layanan Unggulan Kami</h2>
      </div>
      <a class="btn btn-outline-navy" href="<?= $site ?>layanan.php">Semua Layanan <?= icon('arrow-right', 17) ?></a>
    </div>
    <div class="grid grid-4">
      <?php foreach ($layananPop as $l): ?>
      <div class="card service-card hover">
        <span class="service-num"><?= str_pad((string)$l['urutan'], 2, '0', STR_PAD_LEFT) ?></span>
        <h3><?= e($l['nama']) ?></h3>
        <p><?= e(potong($l['deskripsi'], 110)) ?></p>
        <a class="link-more" href="<?= $site ?>layanan.php#layanan-<?= (int)$l['id'] ?>">Detail layanan <?= icon('arrow-right', 15) ?></a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================= STATISTIK RINGKAS ================= -->
<section class="section">
  <div class="container">
    <div class="grid grid-2" style="align-items:center; gap:44px;">
      <div>
        <span class="section-tag">Data &amp; Statistik</span>
        <h2 class="section-title">Produksi Perikanan <?= e($tahunTerbaru) ?></h2>
        <p class="section-sub">Perkembangan produksi perikanan tangkap dan budidaya di Kabupaten Halmahera Selatan dalam tiga tahun terakhir. Data lengkap tersedia pada halaman statistik.</p>
        <div style="display:flex; gap:14px; flex-wrap:wrap; margin-top:22px;">
          <a class="btn btn-primary" href="<?= $site ?>statistik.php"><?= icon('chart', 18) ?> Lihat Statistik Lengkap</a>
        </div>
      </div>
      <div class="card chart-card">
        <h3>Produksi per tahun (ton)</h3>
        <div class="chart-sub">Perikanan tangkap vs budidaya</div>
        <div class="bars">
          <?php $rows = array_reverse($statRingkas); foreach ($rows as $r):
              $hT = round($r['tangkap_ton'] / $maxRingkas * 100);
              $hB = round($r['budidaya_ton'] / $maxRingkas * 100); ?>
          <div class="bar-group">
            <div class="bar-pair">
              <div class="bar tangkap" style="height:<?= max(3, $hT) ?>%"></div>
              <div class="bar budidaya" style="height:<?= max(3, $hB) ?>%"></div>
            </div>
            <div class="bar-x"><?= (int)$r['tahun'] ?></div>
          </div>
          <?php endforeach; ?>
        </div>
        <div class="legend">
          <span><i class="lg-tangkap"></i>Tangkap (<?= $stat ? angka($stat['tangkap_ton']) : '-' ?> ton)</span>
          <span><i class="lg-budidaya"></i>Budidaya (<?= $stat ? angka($stat['budidaya_ton']) : '-' ?> ton)</span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ================= PORTAL APLIKASI ================= -->
<section class="section alt" id="portal-aplikasi">
  <div class="container">
    <div class="section-head" style="display:flex; justify-content:space-between; align-items:flex-end; flex-wrap:wrap; gap:16px;">
      <div>
        <span class="section-tag">Portal Aplikasi Online</span>
        <h2 class="section-title">Aplikasi &amp; Layanan Digital</h2>
        <p class="section-sub">Akses langsung aplikasi layanan online yang digunakan dalam penyelenggaraan urusan kelautan dan perikanan.</p>
      </div>
      <a class="btn btn-outline-navy" href="<?= $site ?>portal-aplikasi.php">Semua Aplikasi <?= icon('arrow-right', 17) ?></a>
    </div>

    <?php if ($aplikasi): ?>
    <div class="grid grid-4">
      <?php foreach ($aplikasi as $a): ?>
      <a class="card hover app-card" href="<?= e($a['url']) ?>" target="_blank" rel="noopener">
        <div class="card-icon"><?= icon($a['ikon'], 26) ?></div>
        <h3><?= e($a['nama']) ?></h3>
        <p><?= e(potong($a['deskripsi'], 110)) ?></p>
        <span class="link-more">Buka Aplikasi <?= icon('external', 15) ?></span>
      </a>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
      <p style="color:var(--muted)">Belum ada aplikasi yang didaftarkan.</p>
    <?php endif; ?>
  </div>
</section>

<!-- ================= CTA ================= -->
<section class="section" style="padding-top:0;">
  <div class="container">
    <div class="cta-band">
      <div>
        <h3>Punya pertanyaan atau pengaduan?</h3>
        <p>Kami siap membantu. Sampaikan pertanyaan melalui halaman kontak atau gunakan layanan pengaduan masyarakat untuk melaporkan permasalahan di bidang kelautan dan perikanan.</p>
      </div>
      <div class="cta-actions">
        <a class="btn btn-gold" href="<?= $site ?>kontak.php"><?= icon('send', 18) ?> Hubungi Kami</a>
        <a class="btn btn-outline" href="<?= $site ?>pengaduan.php"><?= icon('alert', 18) ?> Ajukan Pengaduan</a>
      </div>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
