<?php
$base = '';
$pageTitle = 'Berita';
$activeNav = 'berita';
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/includes/header.php';

$pdo = db();
$kategori = trim((string)get('kategori', ''));
$perHalaman = 6;
$halaman = max(1, (int)get('halaman', 1));
$offset = ($halaman - 1) * $perHalaman;

// ---------- Detail artikel ----------
$detailId = (int)get('id', 0);
if ($detailId > 0) {
    $st = $pdo->prepare('SELECT * FROM berita WHERE id = ? AND status = 1');
    $st->execute([$detailId]);
    $artikel = $st->fetch();
    if ($artikel) {
        $pdo->prepare('UPDATE berita SET dilihat = dilihat + 1 WHERE id = ?')->execute([$detailId]);
        $lainnya = $pdo->prepare('SELECT * FROM berita WHERE status = 1 AND id != ? ORDER BY tanggal DESC LIMIT 3');
        $lainnya->execute([$detailId]);
        $lainnya = $lainnya->fetchAll();
        $w = warna_kategori($artikel['kategori']);
        ?>
        <div class="section" style="padding-top:44px;">
          <div class="container article">
            <span class="pill <?= e($w) ?>"><?= e($artikel['kategori']) ?></span>
            <h1 class="mt-16"><?= e($artikel['judul']) ?></h1>
            <div class="meta">
              <span><?= icon('calendar', 15) ?> <?= e(tanggal_id($artikel['tanggal'], true)) ?></span>
              <span><?= icon('users', 15) ?> <?= e($artikel['penulis']) ?></span>
              <span><?= icon('chart', 15) ?> <?= (int)$artikel['dilihat'] ?>x dilihat</span>
            </div>
            <?php if ($artikel['ringkasan']): ?>
              <p class="lead"><?= e($artikel['ringkasan']) ?></p>
            <?php endif; ?>
            <?php if (!empty($artikel['foto'])): ?>
              <img src="<?= $site ?>foto-berita.php?id=<?= (int)$artikel['id'] ?>" alt="<?= e($artikel['judul']) ?>" style="width:100%; max-height:420px; object-fit:cover; border-radius:12px; border:1px solid var(--line); box-shadow:var(--shadow); margin-bottom:24px;">
            <?php endif; ?>
            <div><?= paragraf($artikel['isi']) ?></div>

            <div class="divider"></div>
            <a class="btn btn-outline-navy" href="<?= $site ?>berita.php"><?= icon('arrow-right', 17, '') ?> Kembali ke Berita</a>

            <?php if ($lainnya): ?>
            <div class="mt-32">
              <h3 style="color:var(--navy-900); margin-bottom:18px;">Berita Lainnya</h3>
              <div class="grid grid-3">
                <?php foreach ($lainnya as $b): $w2 = warna_kategori($b['kategori']); ?>
                <article class="card news-card hover">
                  <?php if (!empty($b['foto'])): ?>
                    <img src="<?= $site ?>foto-berita.php?id=<?= (int)$b['id'] ?>" alt="<?= e($b['judul']) ?>" style="width:100%; height:120px; object-fit:cover;">
                  <?php else: ?>
                    <div class="news-thumb <?= e($w2) ?>" style="height:120px;"><?= icon('fish', 46) ?></div>
                  <?php endif; ?>
                  <div class="news-body">
                    <div class="news-meta"><span class="pill <?= e($w2) ?>"><?= e($b['kategori']) ?></span></div>
                    <h3 style="font-size:15.5px;"><a href="<?= $site ?>berita.php?id=<?= (int)$b['id'] ?>"><?= e(potong($b['judul'], 90)) ?></a></h3>
                    <p><?= e(tanggal_id($b['tanggal'])) ?></p>
                  </div>
                </article>
                <?php endforeach; ?>
              </div>
            </div>
            <?php endif; ?>
          </div>
        </div>
        <?php
        require_once __DIR__ . '/includes/footer.php';
        exit;
    }
}

// ---------- Daftar berita ----------
$kategoris = ['Kegiatan', 'Pengumuman', 'Program', 'Prestasi'];
if ($kategori !== '' && !in_array($kategori, $kategoris, true)) $kategori = '';

if ($kategori !== '') {
    $count = (int)$pdo->query('SELECT COUNT(*) FROM berita WHERE status = 1 AND kategori = ' . $pdo->quote($kategori))->fetchColumn();
    $st = $pdo->prepare('SELECT * FROM berita WHERE status = 1 AND kategori = ? ORDER BY tanggal DESC LIMIT ' . $perHalaman . ' OFFSET ' . $offset);
    $st->execute([$kategori]);
    $berita = $st->fetchAll();
} else {
    $count = (int)$pdo->query('SELECT COUNT(*) FROM berita WHERE status = 1')->fetchColumn();
    $berita = $pdo->query('SELECT * FROM berita WHERE status = 1 ORDER BY tanggal DESC LIMIT ' . $perHalaman . ' OFFSET ' . $offset)->fetchAll();
}
$totalHalaman = max(1, (int)ceil($count / $perHalaman));
?>

<div class="section" style="padding-top:44px;">
  <div class="container">
    <div class="section-head">
      <span class="section-tag">Berita &amp; Kegiatan</span>
      <h2 class="section-title">Informasi Terbaru <?= e(SITE_NAME) ?></h2>
      <p class="section-sub">Kumpulan berita, kegiatan, pengumuman, dan capaian <?= e(SITE_NAME . ' ' . KODE_WILAYAH) ?>.</p>
    </div>

    <div style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:28px;">
      <a class="btn btn-sm <?= $kategori === '' ? 'btn-primary' : 'btn-outline-navy' ?>" href="<?= $site ?>berita.php">Semua</a>
      <?php foreach ($kategoris as $k): ?>
      <a class="btn btn-sm <?= $kategori === $k ? 'btn-primary' : 'btn-outline-navy' ?>" href="<?= $site ?>berita.php?kategori=<?= e(urlencode($k)) ?>"><?= e($k) ?></a>
      <?php endforeach; ?>
    </div>

    <?php if ($berita): ?>
    <div class="grid grid-3">
      <?php foreach ($berita as $b): $w = warna_kategori($b['kategori']); ?>
      <article class="card news-card hover fade-in">
        <?php if (!empty($b['foto'])): ?>
          <img src="<?= $site ?>foto-berita.php?id=<?= (int)$b['id'] ?>" alt="<?= e($b['judul']) ?>" style="width:100%; height:150px; object-fit:cover;">
        <?php else: ?>
          <div class="news-thumb <?= e($w) ?>"><?= icon('fish', 56) ?></div>
        <?php endif; ?>
        <div class="news-body">
          <div class="news-meta">
            <span class="pill <?= e($w) ?>"><?= e($b['kategori']) ?></span>
            <span><?= icon('calendar', 14) ?> <?= e(tanggal_id($b['tanggal'])) ?></span>
          </div>
          <h3><a href="<?= $site ?>berita.php?id=<?= (int)$b['id'] ?>"><?= e($b['judul']) ?></a></h3>
          <p><?= e(potong($b['ringkasan'] ?: $b['isi'], 120)) ?></p>
          <a class="link-more" href="<?= $site ?>berita.php?id=<?= (int)$b['id'] ?>">Baca selengkapnya <?= icon('arrow-right', 15) ?></a>
        </div>
      </article>
      <?php endforeach; ?>
    </div>

    <?php if ($totalHalaman > 1): ?>
    <div class="pagination">
      <?php if ($halaman > 1): ?>
        <a href="<?= $site ?>berita.php?<?= $kategori !== '' ? 'kategori=' . e(urlencode($kategori)) . '&' : '' ?>halaman=<?= $halaman - 1 ?>">‹ Sebelumnya</a>
      <?php endif; ?>
      <?php for ($i = 1; $i <= $totalHalaman; $i++): ?>
        <?php if ($i === $halaman): ?>
          <span class="page-cur"><?= $i ?></span>
        <?php else: ?>
          <a href="<?= $site ?>berita.php?<?= $kategori !== '' ? 'kategori=' . e(urlencode($kategori)) . '&' : '' ?>halaman=<?= $i ?>"><?= $i ?></a>
        <?php endif; ?>
      <?php endfor; ?>
      <?php if ($halaman < $totalHalaman): ?>
        <a href="<?= $site ?>berita.php?<?= $kategori !== '' ? 'kategori=' . e(urlencode($kategori)) . '&' : '' ?>halaman=<?= $halaman + 1 ?>">Berikutnya ›</a>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php else: ?>
      <div class="alert alert-info"><?= icon('search', 18) ?> <span>Belum ada berita pada kategori ini.</span></div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
